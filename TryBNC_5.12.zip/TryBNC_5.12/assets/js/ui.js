﻿/**
 * Глобальная система уведомлений (Modern Quiet Luxury Toast)
 * Поддерживает: message, type (success, error, warning, info), options: { duration, closable, actions, title }
 */
window.showToast = function(message, type = 'info', options = {}) {
    if (!message) return;

    // Автоматическое создание контейнера, если его нет в DOM
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.className = 'toast-container';
        document.body.appendChild(container);
    }

    // Ограничение максимального количества одновременно видимых уведомлений
    const MAX_TOASTS = 4;
    const activeToasts = container.querySelectorAll('.toast:not(.toast-hiding)');
    if (activeToasts.length >= MAX_TOASTS) {
        const oldest = activeToasts[0];
        oldest.classList.add('toast-hiding');
        setTimeout(() => { if (oldest.parentElement) oldest.remove(); }, 320);
    }

    const {
        duration = 4500,
        closable = true,
        actions = [],
        title = null
    } = options;

    const validTypes = ['success', 'error', 'warning', 'info'];
    const safeType = validTypes.includes(type) ? type : 'info';

    const toast = document.createElement('div');
    toast.className = `toast toast-${safeType} ${safeType}${!title ? ' toast-single-text' : ''}`;
    toast.role = 'status';
    toast.setAttribute('aria-live', 'polite');

    // Современные SVG иконки
    const icons = {
        success: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>',
        error: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg>',
        warning: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
        info: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>'
    };
    const icon = icons[safeType] || icons.info;

    // Прогресс-бар
    const progressHtml = duration > 0 
        ? `<div class="toast-progress"><div class="toast-progress-fill" style="animation-duration: ${duration}ms;"></div></div>` 
        : '';

    // Заголовок
    const titleHtml = title ? `<div class="toast-title">${title}</div>` : '';

    // Кнопки действий
    const actionsHtml = actions.length > 0 
        ? `<div class="toast-actions">${actions.map(a => 
            `<button class="toast-action-btn" data-action="${a.label}">${a.label}</button>`
          ).join('')}</div>` 
        : '';

    // Кнопка закрытия
    const closeBtn = closable 
        ? `<button class="toast-close" aria-label="Закрыть уведомление"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg></button>`
        : '';

    toast.innerHTML = `
        <div class="toast-glow"></div>
        <div class="toast-indicator"></div>
        <div class="toast-icon">${icon}</div>
        <div class="toast-body">
            ${titleHtml}
            <div class="toast-message">${message}</div>
            ${actionsHtml}
        </div>
        ${closeBtn}
        ${progressHtml}
    `;

    container.appendChild(toast);

    // Тактильная отдача на мобильных устройствах
    if (window.navigator && window.navigator.vibrate) {
        try { window.navigator.vibrate(8); } catch (_) {}
    }

    // Логика таймера и паузы при наведении
    let dismissed = false;
    let remainingTime = duration;
    let startTime = Date.now();
    let timerId = null;

    const dismiss = () => {
        if (dismissed || !toast.parentElement) return;
        dismissed = true;
        if (timerId) clearTimeout(timerId);
        toast.classList.add('toast-hiding');
        setTimeout(() => {
            if (toast.parentElement) toast.remove();
        }, 320);
    };

    const startTimer = () => {
        if (duration <= 0 || dismissed) return;
        startTime = Date.now();
        timerId = setTimeout(dismiss, remainingTime);
    };

    const pauseTimer = () => {
        if (duration <= 0 || !timerId) return;
        clearTimeout(timerId);
        timerId = null;
        remainingTime -= (Date.now() - startTime);
        if (remainingTime < 300) remainingTime = 300;
    };

    // Пауза при наведении мыши
    toast.addEventListener('mouseenter', () => {
        pauseTimer();
        const fill = toast.querySelector('.toast-progress-fill');
        if (fill) fill.style.animationPlayState = 'paused';
    });

    toast.addEventListener('mouseleave', () => {
        if (!dismissed) {
            startTimer();
            const fill = toast.querySelector('.toast-progress-fill');
            if (fill) fill.style.animationPlayState = 'running';
        }
    });

    // Мобильный свайп вправо для закрытия
    let touchStartX = 0;
    let touchCurrentX = 0;
    let isSwiping = false;

    toast.addEventListener('touchstart', (e) => {
        if (e.touches.length === 1) {
            touchStartX = e.touches[0].clientX;
            isSwiping = true;
            pauseTimer();
        }
    }, { passive: true });

    toast.addEventListener('touchmove', (e) => {
        if (!isSwiping) return;
        touchCurrentX = e.touches[0].clientX - touchStartX;
        if (touchCurrentX > 0) {
            toast.style.transform = `translateX(${touchCurrentX}px)`;
            toast.style.opacity = `${Math.max(0, 1 - touchCurrentX / 220)}`;
        }
    }, { passive: true });

    toast.addEventListener('touchend', () => {
        if (!isSwiping) return;
        isSwiping = false;
        if (touchCurrentX > 75) {
            dismiss();
        } else {
            toast.style.transform = '';
            toast.style.opacity = '';
            if (!dismissed) startTimer();
        }
        touchStartX = 0;
        touchCurrentX = 0;
    });

    // Обработчики кнопок действий
    actions.forEach(action => {
        const btn = toast.querySelector(`[data-action="${action.label}"]`);
        if (btn) {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                if (typeof action.onClick === 'function') action.onClick();
                dismiss();
            });
        }
    });

    // Кнопка закрытия
    const closeBtnEl = toast.querySelector('.toast-close');
    if (closeBtnEl) {
        closeBtnEl.addEventListener('click', (e) => {
            e.stopPropagation();
            dismiss();
        });
    }

    // Клик по тосту (если нет действий)
    if (actions.length === 0) {
        toast.addEventListener('click', (e) => {
            if (e.target.closest('.toast-close') || e.target.closest('.toast-action-btn')) return;
            dismiss();
        });
    }

    // Запуск таймера
    startTimer();

    return { dismiss, toast };
};

// Удобные шорткаты
window.showToast.success = (message, options = {}) => window.showToast(message, 'success', options);
window.showToast.error = (message, options = {}) => window.showToast(message, 'error', options);
window.showToast.warning = (message, options = {}) => window.showToast(message, 'warning', options);
window.showToast.info = (message, options = {}) => window.showToast(message, 'info', options);
window.showToast.clear = () => {
    const container = document.getElementById('toast-container');
    if (!container) return;
    container.querySelectorAll('.toast:not(.toast-hiding)').forEach(t => {
        t.classList.add('toast-hiding');
        setTimeout(() => { if (t.parentElement) t.remove(); }, 320);
    });
};
window.showToast.dismissAll = window.showToast.clear;

/**
 * Функция для закрытия нового модального окна просмотра
 */
window.closeViewModal = function() {
    const modalContainer = document.getElementById('bookModal');
    if (!modalContainer) return;

    const overlay = modalContainer.querySelector('.animate-fade-in');
    if (!overlay || overlay.classList.contains('is-closing')) return;

    overlay.classList.add('is-closing');
    const panel = overlay.querySelector('.viewmodal-panel');
    if (panel) panel.classList.add('is-closing');
    const closeButton = overlay.querySelector('.viewmodal-close');
    if (closeButton) closeButton.classList.add('is-closing');

    const finishClose = () => {
        modalContainer.innerHTML = '';
        const anyModalOpen = document.querySelector('.modal.show:not(.is-closing)');
        const menuOpen = document.getElementById('navLinks')?.classList.contains('active');
        if (!anyModalOpen && !menuOpen) {
            document.body.classList.remove('modal-open');
            document.body.style.overflow = '';
            if (window.lenis) window.lenis.start();
        }
    };

    if (window.closeModalWithAnimation) {
        window.closeModalWithAnimation(modalContainer, finishClose);
    } else {
        setTimeout(() => {
            modalContainer.classList.remove('show');
            finishClose();
        }, 460);
    }
};


// Логика снега
let snowInterval;
let isSnowing = false;
const MAX_SNOWFLAKES = 50;

function createSnowflake() {
    if (document.querySelectorAll('.snowflake').length > MAX_SNOWFLAKES) return;
    
    const snowflake = document.createElement('div');
    snowflake.classList.add('snowflake');
    const depth = Math.random();
    const size = 3 + depth * 7 + 'px';
    const duration = 15 - depth * 7 + 's';
    const opacity = 0.3 + depth * 0.7;
    const wind = Math.random() * 60 - 10 + 'vw';
    snowflake.style.width = size; snowflake.style.height = size;
    snowflake.style.left = Math.random() * 120 - 20 + 'vw';
    snowflake.style.animationDuration = duration; snowflake.style.opacity = opacity;
    snowflake.style.setProperty('--wind-x', wind);
    document.body.appendChild(snowflake);
    
    // Используем событие окончания анимации вместо setTimeout для точности
    snowflake.addEventListener('animationend', () => snowflake.remove(), { once: true });
}

function setSnowState(active) {
    isSnowing = active;
    const snowToggles = document.querySelectorAll('.toggle-switch');
    
    snowToggles.forEach(btn => {
        if (isSnowing) btn.classList.add('active');
        else btn.classList.remove('active');
    });

    if (isSnowing) {
        document.body.setAttribute('data-snow', 'active');
        if (!snowInterval) snowInterval = setInterval(createSnowflake, 200);
    } else {
        document.body.removeAttribute('data-snow');
        clearInterval(snowInterval); snowInterval = null;
        document.querySelectorAll('.snowflake').forEach(el => el.remove());
    }
    localStorage.setItem('isSnowing', isSnowing);
}

/* ============================================================
   FAILSAFE: страница не должна оставаться невидимой / неотскролленной,
   если внешние скрипты (GSAP, Lenis, Supabase) не загрузились или зависли.
   CSS держит body и .reveal с opacity:0 только пока html не получит класс
   'site-ready'. Здесь мы гарантированно его ставим.
   ============================================================ */
(function () {
    var REVEAL_TIMEOUT = 2500; // мс — максимальное ожидание инициализации анимаций

    function markSiteReady() {
        var html = document.documentElement;
        // Снимаем стартовое скрытие как можно раньше — контент должен быть
        // виден сразу, а не ждать до 5 секунд, пока ответит Supabase.
        html.classList.remove('js-loading');
        if (html.classList.contains('site-ready')) return;
        html.classList.add('site-ready');
        document.body.style.opacity = '1';
        // Показываем reveal-блоки: если GSAP ещё не пришёл (или пришёл поздно),
        // IntersectionObserver сам снимет их по мере появления, но подстрахуемся.
        if (typeof window.gsap === 'undefined') {
            document.querySelectorAll('.reveal, .footer-container').forEach(function (el) {
                el.classList.add('reveal-visible');
            });
        }
    }

    // Вызываем сразу, как только DOM готов — не ждём таймаута.
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () { markSiteReady(); });
    } else {
        markSiteReady();
    }

    // Публичный хук: script.js вызывает его, когда контент готов
    window.markSiteReady = markSiteReady;

    // Жёсткий таймаут — что бы ни случилось с сетью, сайт станет видимым
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            setTimeout(markSiteReady, REVEAL_TIMEOUT);
        });
    } else {
        setTimeout(markSiteReady, REVEAL_TIMEOUT);
    }

    // Немедленно снимаем блокировку прокрутки, если она висит без причины
    window.addEventListener('load', function () {
        if (document.documentElement.classList.contains('lenis-stopped') &&
            !document.body.classList.contains('modal-open') &&
            !document.body.classList.contains('menu-open') &&
            !document.body.classList.contains('pd-open')) {
            document.documentElement.classList.remove('lenis-stopped');
        }
        if (window.lenis && typeof window.lenis.start === 'function') {
            try { window.lenis.start(); } catch (e) { }
        }
        if (typeof ScrollTrigger !== 'undefined' && ScrollTrigger.refresh) {
            ScrollTrigger.refresh();
        }
    });
})();

document.addEventListener('DOMContentLoaded', () => {
    // Инициализация снега
    if (localStorage.getItem('isSnowing') === 'true') setSnowState(true);

    // Создание и логика Scroll Progress Indicator
    // Отключён на страницах админ-панели (admin.html, login.html)
    const isAdminPage = /(?:^|\/)(admin|login)\.html$/i.test(window.location.pathname);

    const createScrollProgress = () => {
        const container = document.createElement('div');
        container.className = 'scroll-progress-container';
        const bar = document.createElement('div');
        bar.id = 'scrollProgress';
        bar.className = 'scroll-progress-bar';
        const percent = document.createElement('span');
        percent.className = 'scroll-progress-percentage';
        percent.textContent = '0%';
        container.appendChild(bar);
        container.appendChild(percent);
        document.body.appendChild(container);

        let scrollTimeout;
        let isDragging = false;

        const updateBar = (progress) => {
            if (!isDragging) {
                container.classList.add('scrolling');
                clearTimeout(scrollTimeout);
                scrollTimeout = setTimeout(() => container.classList.remove('scrolling'), 1000);
            }

            const p = Math.min(100, Math.max(0, Math.round(progress * 100)));
            bar.style.height = `${p}%`;
            percent.textContent = `${p}%`;
        };

        const handleDrag = (e, smooth = false) => {
            const rect = container.getBoundingClientRect();
            const y = e.clientY - rect.top;
            const progress = Math.min(1, Math.max(0, y / rect.height));
            const scrollTarget = progress * (document.documentElement.scrollHeight - window.innerHeight);

            if (window.lenis) {
                window.lenis.scrollTo(scrollTarget, { immediate: !smooth });
            } else {
                window.scrollTo({ top: scrollTarget, behavior: smooth ? 'smooth' : 'auto' });
            }
        };

        container.addEventListener('mousedown', (e) => {
            isDragging = true;
            container.classList.add('scrolling');
            document.body.style.cursor = 'grabbing'; // Меняем курсор на "захват"
            document.body.style.userSelect = 'none';
            handleDrag(e, true); // При клике скроллим плавно
        });

        // Поддержка касаний для управления ползунком на смартфонах
        container.addEventListener('touchstart', (e) => {
            isDragging = true;
            container.classList.add('scrolling');
            handleDrag(e.touches[0], true);
        }, { passive: false });

        window.addEventListener('touchmove', (e) => {
            if (isDragging) {
                handleDrag(e.touches[0], false);
                if (e.cancelable) e.preventDefault(); // Предотвращаем дергание страницы при перетаскивании
            }
        }, { passive: false });

        window.addEventListener('touchend', () => {
            if (isDragging) {
                isDragging = false;
                scrollTimeout = setTimeout(() => container.classList.remove('scrolling'), 1000);
            }
        });

        window.addEventListener('mousemove', (e) => {
            if (isDragging) handleDrag(e, false); // При перетаскивании скроллим мгновенно
        });

        window.addEventListener('mouseup', () => {
            if (isDragging) {
                isDragging = false;
                document.body.style.cursor = '';
                document.body.style.userSelect = '';
                scrollTimeout = setTimeout(() => container.classList.remove('scrolling'), 1000);
            }
        });

        if (window.lenis) {
            window.lenis.on('scroll', ({ progress }) => updateBar(progress));
        } else {
            window.addEventListener('scroll', () => {
                const progress = window.scrollY / (document.documentElement.scrollHeight - window.innerHeight);
                updateBar(progress);
            });
        }
    };

    if (!isAdminPage) createScrollProgress();

    // Переносим и объявляем функцию здесь, чтобы она была доступна везде внутри DOMContentLoaded
    function toggleMenu(forceClose = false) {
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const navLinks = document.getElementById('navLinks');
        if (!mobileMenuBtn || !navLinks) return;

        const isOpen = forceClose ? false : !navLinks.classList.contains('is-open');

        if (isOpen) {
            updateActiveLink();
            navLinks.classList.add('is-open');
            mobileMenuBtn.classList.add('active');
            document.body.classList.add('menu-open', 'modal-open');
            document.body.style.overflow = 'hidden';
            if (window.lenis) window.lenis.stop();

            // Анимация ссылок
            const links = navLinks.querySelectorAll('.fm-link');
            const footer = navLinks.querySelector('.fm-footer');
            gsap.fromTo(links,
                { y: 60, opacity: 0 },
                { y: 0, opacity: 1, stagger: 0.08, duration: 0.6, ease: 'power3.out', delay: 0.35 }
            );
            gsap.fromTo(footer,
                { y: 20, opacity: 0 },
                { y: 0, opacity: 1, duration: 0.5, ease: 'power2.out', delay: 0.65 }
            );

            closeSearchPanel();
        } else {
            // Быстрое закрытие
            const links = navLinks.querySelectorAll('.fm-link');
            const footer = navLinks.querySelector('.fm-footer');
            gsap.to([links, footer], { y: 20, opacity: 0, duration: 0.2, ease: 'power1.in', overwrite: true });

            mobileMenuBtn.classList.remove('active');
            document.body.classList.remove('menu-open', 'modal-open');
            navLinks.classList.remove('is-open');

            const anyModalOpen = document.querySelector('.modal.show, .header-search.active');
            if (!anyModalOpen) {
                document.body.style.overflow = '';
                if (window.lenis) window.lenis.start();
            }
        }

        mobileMenuBtn.setAttribute('aria-expanded', isOpen);
        navLinks.setAttribute('aria-hidden', !isOpen);
    }

    // Вспомогательная функция для обновления ссылок
    function updateActiveLink() {
        const navLinks = document.getElementById('navLinks');
        if (!navLinks) return;
        const currentPath = window.location.pathname.split('/').pop() || 'index.html';
        navLinks.querySelectorAll('.fm-link').forEach(link => {
            const linkPath = link.getAttribute('href');
            link.classList.toggle('nav-active', linkPath === currentPath);
        });
    }

    // Функция для закрытия панели поиска
    function closeSearchPanel() {
        const headerSearch = document.querySelector('.header-search');
        if (headerSearch && headerSearch.classList.contains('active')) {
            headerSearch.classList.remove('active');
            document.body.classList.remove('search-active');
        }
    }
    window.toggleMenu = toggleMenu; // Делаем доступной глобально на всякий случай
    
    const snowToggles = document.querySelectorAll('.toggle-switch');
    const snowModal = document.getElementById('snowModal');
    const closeSnow = document.getElementById('closeSnow');
    const header = document.querySelector('header');
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const navLinks = document.getElementById('navLinks');
    const searchInput = document.getElementById('searchInput');
    const mobileSearchBtn = document.getElementById('mobileSearchBtn');
    const headerSearch = document.querySelector('.header-search');
    const clearSearchBtn = document.getElementById('clearSearch');

    snowToggles.forEach(toggle => {
        toggle.addEventListener('click', (e) => {
            e.stopPropagation();
            setSnowState(!isSnowing);
        });
    });

    if (closeSnow && snowModal) {
        closeSnow.addEventListener('click', () => {
            if (window.closeModalWithAnimation) {
                window.closeModalWithAnimation(snowModal, () => {
                    const anyModalOpen = document.querySelector('.modal.show:not(.is-closing)');
                    if (!anyModalOpen) {
                        document.body.classList.remove('modal-open');
                        document.body.style.overflow = '';
                        if (window.lenis) window.lenis.start();
                    }
                });
            } else {
                snowModal.classList.remove('show');
            }
        });
    }

    if (mobileSearchBtn && headerSearch) {
        mobileSearchBtn.addEventListener('click', () => {
            headerSearch.classList.add('active');
            document.body.classList.add('search-active');
            document.body.style.overflow = 'hidden';
            searchInput?.focus({ preventScroll: true });
            if (navLinks && navLinks.classList.contains('is-open')) toggleMenu(true);
        });

        if (clearSearchBtn) {
            clearSearchBtn.addEventListener('click', () => {
                if (window.innerWidth <= 768 && !searchInput.value) {
                    headerSearch.classList.remove('active');
                    document.body.classList.remove('search-active');
                    document.body.style.overflow = '';
                    searchInput.blur();
                }
            });
        }
    }

    if (typeof ScrollTrigger !== 'undefined') {
        ScrollTrigger.create({
            start: "top -20",
            onUpdate: (self) => {
                header?.classList.toggle('header-scrolled', self.direction > 0 || self.scroll() > 20);
            }
        });
    }

    if (mobileMenuBtn && navLinks) {
        window.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && navLinks.classList.contains('is-open')) toggleMenu(true);
        });

        mobileMenuBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (window.navigator.vibrate) window.navigator.vibrate(10);
            toggleMenu();
        });

        navLinks.querySelectorAll('.fm-link').forEach(link => {
            link.addEventListener('click', () => toggleMenu(true));
        });

        const supportBtnMenu = document.getElementById('supportBtnMenu');
        if (supportBtnMenu) {
            supportBtnMenu.addEventListener('click', (e) => {
                e.preventDefault();
                toggleMenu(true);
                const supportModal = document.getElementById('supportModal');
                if (supportModal) {
                    if (window.cancelModalCloseAnimation) window.cancelModalCloseAnimation(supportModal);
                    supportModal.classList.add('show');
                    document.body.classList.add('modal-open');
                    document.body.style.overflow = 'hidden';
                    if (window.lenis) window.lenis.stop();
                }
            });
        }

        document.addEventListener('click', (e) => {
            if (navLinks.classList.contains('is-open') && !navLinks.contains(e.target) && !mobileMenuBtn.contains(e.target)) {
                toggleMenu(true);
            }
        });
    }

    // Мобильное меню и кебаб-меню
    document.querySelectorAll('.dropdown').forEach(dropdown => {
        const btn = dropdown.querySelector('.dropbtn');
        if (btn) {
            btn.addEventListener('click', (e) => {
                if (window.innerWidth <= 768 || dropdown.classList.contains('kebab-dropdown')) {
                    e.stopPropagation();
                    const wasOpen = dropdown.classList.contains('open');
                    document.querySelectorAll('.dropdown.open').forEach(d => d.classList.remove('open'));
                    if (!wasOpen) dropdown.classList.add('open');
                }
            });
        }
    });
    
    document.addEventListener('click', (e) => {
        document.querySelectorAll('.dropdown.open').forEach(dropdown => {
            if (!dropdown.contains(e.target)) dropdown.classList.remove('open');
        });
    });

    // Интерактивный Spotlight эффект для карточек хаба
    document.querySelectorAll('.hub-card').forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = ((e.clientX - rect.left) / rect.width) * 100;
            const y = ((e.clientY - rect.top) / rect.height) * 100;
            card.style.setProperty('--mouse-x', `${x}%`);
            card.style.setProperty('--mouse-y', `${y}%`);
        });
    });

    // Логика заставки (Splash Screen) - если она есть на странице
    const splash = document.getElementById('splashScreen');
    const enterBtn = document.getElementById('enterBtn');

    if (splash && enterBtn) {
        // Проверяем, показывали ли мы заставку в этой сессии
        if (sessionStorage.getItem('splashShown')) {
            splash.style.display = 'none';
        } else {
            enterBtn.addEventListener('click', () => {
                splash.classList.add('hidden');
                sessionStorage.setItem('splashShown', 'true');
            });
        }
    }

    observeElements(); // Инициализация анимации проявления элементов
});

window.scrollToFooter = function() {
    const footer = document.querySelector('footer');
    if (footer) {
        if (window.lenis) window.lenis.scrollTo(footer);
        else footer.scrollIntoView({ behavior: 'smooth' });
    }
};

/**
 * Анимация появления элементов при прокрутке (Awwwards style)
 */
function observeElements() {
    const reveals = document.querySelectorAll('.reveal, .footer-container');
    if (reveals.length === 0) return;

    let refreshTimeout;

    const observer = new IntersectionObserver((entries) => {
        let needsRefresh = false;
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('reveal-visible');
                observer.unobserve(entry.target); // Анимируем только один раз
                needsRefresh = true;
            }
        });

        // Группируем обновление расчетов в один вызов на кадр анимации
        if (needsRefresh && typeof ScrollTrigger !== 'undefined') {
            cancelAnimationFrame(refreshTimeout);
            refreshTimeout = requestAnimationFrame(() => {
                ScrollTrigger.refresh();
            });
        }
    }, { threshold: 0.15 });

    reveals.forEach(el => observer.observe(el));
}

window.setSnowState = setSnowState;