(function () {
    'use strict';

    var CONSENT_KEY = 'bnc_cookie_consent_v1';
    var analyticsLoaded = false;

    function readConsent() {
        try {
            var stored = localStorage.getItem(CONSENT_KEY);
            return stored ? JSON.parse(stored) : null;
        } catch (error) {
            console.error('Не удалось прочитать сохранённый выбор cookie:', error);
            return null;
        }
    }

    function loadAnalytics() {
        if (analyticsLoaded) return;
        analyticsLoaded = true;

        window.dataLayer = window.dataLayer || [];
        window.gtag = window.gtag || function () {
            window.dataLayer.push(arguments);
        };
        window.gtag('js', new Date());
        window.gtag('config', 'G-KN8WX084WY');

        var googleScript = document.createElement('script');
        googleScript.async = true;
        googleScript.src = 'https://www.googletagmanager.com/gtag/js?id=G-KN8WX084WY';
        googleScript.onerror = function () {
            console.error('Не удалось загрузить Google Analytics.');
        };
        document.head.appendChild(googleScript);

        window.ym = window.ym || function () {
            (window.ym.a = window.ym.a || []).push(arguments);
        };
        window.ym.l = Date.now();
        window.ym(109483108, 'init', {
            ssr: true,
            webvisor: true,
            clickmap: true,
            ecommerce: 'dataLayer',
            referrer: document.referrer,
            url: window.location.href,
            accurateTrackBounce: true,
            trackLinks: true
        });

        var metrikaScript = document.createElement('script');
        metrikaScript.async = true;
        metrikaScript.src = 'https://mc.yandex.ru/metrika/tag.js?id=109483108';
        metrikaScript.onerror = function () {
            console.error('Не удалось загрузить Яндекс.Метрику.');
        };
        document.head.appendChild(metrikaScript);
    }

    function saveConsent(analytics) {
        var consent = {
            necessary: true,
            analytics: analytics,
            updatedAt: new Date().toISOString()
        };

        try {
            localStorage.setItem(CONSENT_KEY, JSON.stringify(consent));
        } catch (error) {
            console.error('Не удалось сохранить выбор cookie:', error);
            return false;
        }

        if (analytics) loadAnalytics();
        return true;
    }

    function createBanner() {
        var banner = document.createElement('section');
        banner.className = 'cookie-consent';
        banner.setAttribute('role', 'dialog');
        banner.setAttribute('aria-label', 'Настройки файлов cookie');
        banner.setAttribute('aria-describedby', 'cookieConsentDescription');
        banner.innerHTML = [
            '<h2 class="cookie-consent__title">Файлы cookie</h2>',
            '<p class="cookie-consent__text" id="cookieConsentDescription">',
            'Нужное хранилище помогает входу и настройкам. Аналитика Google и Яндекс.Метрика (включая Вебвизор) — только с вашего согласия. ',
            '<a class="cookie-consent__link" href="privacy.html">Подробнее</a>.',
            '</p>',
            '<div class="cookie-consent__actions">',
            '<button class="cookie-consent__button cookie-consent__button--accept" type="button" data-consent="accept">Разрешить аналитику</button>',
            '<button class="cookie-consent__button" type="button" data-consent="reject">Только нужное</button>',
            '</div>',
            '<p class="cookie-consent__error" role="alert" hidden>Не удалось сохранить выбор в этом браузере. Проверьте настройки хранения данных и попробуйте ещё раз.</p>'
        ].join('');

        document.body.appendChild(banner);
        requestAnimationFrame(function () {
            banner.classList.add('is-visible');
        });

        banner.addEventListener('click', function (event) {
            var button = event.target.closest('[data-consent]');
            if (!button) return;

            var accepted = button.getAttribute('data-consent') === 'accept';
            var wasAnalyticsLoaded = analyticsLoaded;
            if (!saveConsent(accepted)) {
                banner.querySelector('.cookie-consent__error').hidden = false;
                return;
            }

            banner.classList.remove('is-visible');
            window.setTimeout(function () {
                banner.remove();
                if (!accepted && wasAnalyticsLoaded) window.location.reload();
            }, 240);
        });
    }

    window.openCookieSettings = function () {
        var existingBanner = document.querySelector('.cookie-consent');
        if (existingBanner) {
            existingBanner.classList.add('is-visible');
            return;
        }
        createBanner();
    };

    document.addEventListener('click', function (event) {
        if (event.target.closest('[data-cookie-settings]')) {
            window.openCookieSettings();
        }
    });

    var consent = readConsent();
    if (consent && consent.necessary === true) {
        if (consent.analytics === true) loadAnalytics();
    } else {
        createBanner();
    }
})();
