﻿/* ============================================================
   Личный кабинет (account.html).
   - переключение видов: overview / downloads / favorites / tickets / settings
   - локальная история загрузок и избранное (localStorage)
   - синхронизация данных пользователя (имя, email, аватар)
   Совместим с прежним API: openProfileDashboard / closeProfileDashboard /
   syncProfileDashboard (используются в auth.js и account-menu.js).
   ============================================================ */
(function () {
    'use strict';

    /* ---------- Хранилище истории и избранного ---------- */
    var HISTORY_KEY = 'bnc_download_history_v1';
    var FAV_KEY = 'bnc_favorites_v1';
    var TICKETS_KEY = 'bnc_tickets_v1';
    var HISTORY_LIMIT = 60;

    function readJSON(key, fallback) {
        try {
            var raw = localStorage.getItem(key);
            if (!raw) return fallback;
            var parsed = JSON.parse(raw);
            return Array.isArray(parsed) ? parsed : fallback;
        } catch (e) { return fallback; }
    }

    function writeJSON(key, value) {
        try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { }
    }

    function keyOf(item) {
        return (item && (item.url || item.id || item.title)) || '';
    }

    window.bncHistory = {
        all: function () { return readJSON(HISTORY_KEY, []); },
        add: function (item) {
            if (!item || !item.url) return;
            var list = readJSON(HISTORY_KEY, []).filter(function (x) { return keyOf(x) !== keyOf(item); });
            list.unshift({
                url: item.url,
                title: item.title || 'Файл',
                image: item.image || '',
                source: item.source || '',
                date: Date.now()
            });
            writeJSON(HISTORY_KEY, list.slice(0, HISTORY_LIMIT));
            window.dispatchEvent(new CustomEvent('bnc:history-changed'));
        },
        clear: function () {
            writeJSON(HISTORY_KEY, []);
            window.dispatchEvent(new CustomEvent('bnc:history-changed'));
        }
    };

    window.bncFavorites = {
        all: function () { return readJSON(FAV_KEY, []); },
        has: function (item) {
            return readJSON(FAV_KEY, []).some(function (x) { return keyOf(x) === keyOf(item); });
        },
        toggle: function (item) {
            var list = readJSON(FAV_KEY, []);
            var k = keyOf(item);
            var idx = list.findIndex(function (x) { return keyOf(x) === k; });
            if (idx >= 0) list.splice(idx, 1);
            else list.unshift({ url: item.url, title: item.title || 'Файл', image: item.image || '', date: Date.now() });
            writeJSON(FAV_KEY, list);
            window.dispatchEvent(new CustomEvent('bnc:favorites-changed'));
            return idx < 0;
        }
    };

    /* ---------- Тикеты (обращения в поддержку) ---------- */
    function nextTicketNumber() {
        var n = parseInt(localStorage.getItem('bnc_ticket_seq') || '0', 10) + 1;
        try { localStorage.setItem('bnc_ticket_seq', String(n)); } catch (e) { }
        return n;
    }

    window.bncTickets = {
        all: function () { return readJSON(TICKETS_KEY, []); },
        add: function (item) {
            if (!item || !item.message) return null;
            var list = readJSON(TICKETS_KEY, []);
            // Если сервер уже создал тикет и вернул id — используем его,
            // чтобы локальная запись и запись в БД были одним тикетом.
            var id = (item.id != null && item.id !== '')
                ? String(item.id)
                : String(nextTicketNumber()).padStart(4, '0');
            var ticket = {
                id: id,
                user_id: window.currentUser && window.currentUser.id || null,
                subject: item.subject || item.message.slice(0, 60),
                message: item.message,
                email: item.email || '',
                status: item.status || 'open', // open -> reviewed -> closed
                date: Date.now()
            };
            // Убираем возможный дубликат с тем же id, затем кладём в начало.
            list = list.filter(function (x) { return String(x.id) !== id; });
            list.unshift(ticket);
            writeJSON(TICKETS_KEY, list.slice(0, 40));
            window.dispatchEvent(new CustomEvent('bnc:tickets-changed'));
            return ticket;
        },
        setStatus: function (id, status) {
            var list = readJSON(TICKETS_KEY, []);
            var t = list.filter(function (x) { return String(x.id) === String(id); })[0];
            if (t) {
                t.status = status;
                writeJSON(TICKETS_KEY, list);
                window.dispatchEvent(new CustomEvent('bnc:tickets-changed'));
            }
        },
        // Тихие версии (без событий) — для синхронизации, чтобы не было циклов
        setStatusQuiet: function (id, status) {
            var list = readJSON(TICKETS_KEY, []);
            var t = list.filter(function (x) { return String(x.id) === String(id); })[0];
            if (t) { t.status = status; writeJSON(TICKETS_KEY, list); }
        },
        removeQuiet: function (id) {
            writeJSON(TICKETS_KEY, readJSON(TICKETS_KEY, []).filter(function (t) { return String(t.id) !== String(id); }));
        },
        upsert: function (ticket) {
            if (!ticket) return;
            var list = readJSON(TICKETS_KEY, []);
            var idx = list.findIndex(function (x) { return String(x.id) === String(ticket.id); });
            if (idx >= 0) list[idx] = Object.assign({}, list[idx], ticket);
            else list.unshift(ticket);
            list.sort(function (a, b) { return (b.date || 0) - (a.date || 0); });
            writeJSON(TICKETS_KEY, list.slice(0, 40));
        },
        remove: function (id) {
            writeJSON(TICKETS_KEY, readJSON(TICKETS_KEY, []).filter(function (t) { return t.id !== id; }));
            window.dispatchEvent(new CustomEvent('bnc:tickets-changed'));
        },
        clear: function () {
            writeJSON(TICKETS_KEY, []);
            window.dispatchEvent(new CustomEvent('bnc:tickets-changed'));
        },
        STATUS: {
            open: { label: 'Открыт', cls: 'open' },
            reviewed: { label: 'Рассмотрено', cls: 'reviewed' },
            closed: { label: 'Закрыт', cls: 'closed' }
        }
    };

    /* ---------- Утилиты ---------- */
    function esc(str) {
        var p = document.createElement('p');
        p.textContent = str == null ? '' : String(str);
        return p.innerHTML;
    }

    function relTime(ts) {
        if (!ts) return '';
        var diff = Math.floor((Date.now() - ts) / 1000);
        if (diff < 60) return 'только что';
        if (diff < 3600) return Math.floor(diff / 60) + ' мин назад';
        if (diff < 86400) return Math.floor(diff / 3600) + ' ч назад';
        if (diff < 604800) return Math.floor(diff / 86400) + ' дн назад';
        return new Date(ts).toLocaleDateString('ru-RU');
    }

    var dashboard = document.getElementById('accountLayout');
    var scrollArea = document.getElementById('pdScroll');
    var greeting = document.getElementById('pdGreeting');
    var chipName = document.getElementById('pdChipName');
    var chipInitials = document.getElementById('pdChipInitials');
    var chipAvatar = document.getElementById('pdChipAvatar');

    function prettyNameFromUser(user) {
        if (!user) return 'Гость';
        var customName = user.profile && user.profile.display_name;
        var raw = customName || (user.user_metadata && (user.user_metadata.full_name || user.user_metadata.name)) || '';
        var emailName = (user.email || '').split('@')[0];
        var display = raw || emailName || 'Пользователь';
        return customName ? customName : display.charAt(0).toUpperCase() + display.slice(1);
    }

    function initialsFromName(name) {
        return (String(name).replace(/[^\p{L}\p{N}]/gu, '').slice(0, 2) || '?').toUpperCase();
    }

    /* Наполнение данными пользователя */
    function syncProfileDashboard(user) {
        user = user || window.currentUser;
        var name = prettyNameFromUser(user);

        if (greeting) greeting.textContent = name;
        if (chipName) chipName.textContent = name;
        if (chipInitials) chipInitials.textContent = initialsFromName(name);
        if (nicknameInput && document.activeElement !== nicknameInput) {
            nicknameInput.value = (user && user.profile && user.profile.display_name) || '';
        }

        var avatarUrl = user && user.user_metadata &&
            (user.user_metadata.manual_avatar || user.user_metadata.avatar_url || user.user_metadata.picture);

        if (chipAvatar && chipInitials) {
            if (avatarUrl) {
                chipAvatar.src = avatarUrl;
                chipAvatar.style.display = 'block';
                chipInitials.style.display = 'none';
            } else {
                chipAvatar.style.display = 'none';
                chipInitials.style.display = 'inline-flex';
            }
        }

        // Статистика (время на сайте / загрузки) живёт в tracking.js.
        // На странице кабинета гарантируем, что она подтянется и не останется 0.
        if (dashboard && user && typeof window.initUserTimeTracking === 'function') {
            window.initUserTimeTracking(user);
        }
    }

    /* ---------- Переключение видов ---------- */
    var VIEW_TITLES = {
        overview: 'Обзор',
        downloads: 'Мои загрузки',
        favorites: 'Избранное',
        friends: 'Друзья',
        tickets: 'Мои тикеты',
        chat: 'Переписка с поддержкой',
        settings: 'Настройки'
    };

    function showView(name, opts) {
        if (!dashboard) return;
        if (!VIEW_TITLES[name]) name = 'overview';
        opts = opts || {};

        document.querySelectorAll('.pd-view[data-pd-panel]').forEach(function (panel) {
            panel.hidden = panel.getAttribute('data-pd-panel') !== name;
        });

        document.querySelectorAll('#pdNav .pd-nav-link[data-pd-view]').forEach(function (link) {
            link.classList.toggle('active', link.getAttribute('data-pd-view') === name);
        });

        var titleEl = document.getElementById('pdViewTitle');
        if (titleEl) titleEl.textContent = VIEW_TITLES[name];

        // Всегда подтягиваем свежие данные для текущего вида
        // (история/избранное могли измениться на других страницах).
        if (!opts.noRender && typeof renderAll === 'function') renderAll();
        if (name === 'friends') {
            showFriendBrowse();
            syncFriends();
        }
        else stopFriendChatPolling();

        if (scrollArea && !opts.keepScroll) scrollArea.scrollTop = 0;
        if (location.hash !== '#' + name) {
            try { history.replaceState(null, '', '#' + name); } catch (e) { }
        }
    }
    window.bncShowView = showView;

    /* ---------- Друзья и личная переписка ---------- */
    var activeFriendChat = null;
    var friendChatPollTimer = null;
    var friendRecords = [];
    var ticketsLoading = false;
    var ticketsLoadError = false;

    function friendListMessage(element, text) {
        if (element) element.innerHTML = '<div class="pd-friend-empty">' + esc(text) + '</div>';
    }

    function loadingMessage(text) {
        return '<div class="pd-loading-state" role="status" aria-live="polite"><i class="fas fa-circle-notch fa-spin" aria-hidden="true"></i><span>' + esc(text) + '</span></div>';
    }

    function stopFriendChatPolling() {
        if (friendChatPollTimer) {
            clearInterval(friendChatPollTimer);
            friendChatPollTimer = null;
        }
    }

    function showFriendBrowse() {
        stopFriendChatPolling();
        activeFriendChat = null;
        var browse = document.getElementById('pdFriendsBrowse');
        var panel = document.getElementById('pdFriendChat');
        if (browse) browse.hidden = false;
        if (panel) panel.hidden = true;
    }

    function friendRowHtml(friend) {
        return '<article class="pd-friend-row">' +
            '<span class="pd-friend-avatar"><i class="fas fa-user"></i></span>' +
            '<span class="pd-friend-name">' + esc(friend.display_name) + '</span>' +
            '<div class="pd-friend-actions">' +
                '<button class="pd-friend-action is-primary" type="button" data-friend-open="' + esc(friend.friend_id) + '" title="Написать" aria-label="Написать ' + esc(friend.display_name) + '">' +
                    '<i class="fas fa-message"></i><span>Написать</span>' +
                '</button>' +
                '<button class="pd-friend-action is-danger" type="button" data-friend-remove="' + esc(friend.friend_id) + '" title="Удалить из друзей" aria-label="Удалить ' + esc(friend.display_name) + ' из друзей">' +
                    '<i class="fas fa-user-minus"></i>' +
                '</button>' +
            '</div>' +
        '</article>';
    }

    function renderFriendRequests(requests) {
        var container = document.getElementById('pdFriendRequests');
        var incoming = requests.filter(function (request) { return request.direction === 'incoming'; });
        var outgoing = requests.filter(function (request) { return request.direction === 'outgoing'; });
        var pill = document.getElementById('pdFriendPill');
        if (pill) {
            pill.hidden = incoming.length === 0;
            pill.textContent = String(incoming.length);
        }
        if (!container) return;
        if (!requests.length) {
            friendListMessage(container, 'Новых заявок пока нет.');
            return;
        }
        container.innerHTML = incoming.map(function (request) {
            return '<article class="pd-friend-row">' +
                '<span class="pd-friend-avatar"><i class="fas fa-user-plus"></i></span>' +
                '<span class="pd-friend-name">' + esc(request.display_name) + '<small>Хочет добавить вас в друзья</small></span>' +
                '<div class="pd-friend-actions">' +
                    '<button class="pd-friend-action is-primary" type="button" data-friend-respond="' + esc(request.request_id) + '" data-accept="true"><i class="fas fa-check"></i><span>Принять</span></button>' +
                    '<button class="pd-friend-action is-danger" type="button" data-friend-respond="' + esc(request.request_id) + '" data-accept="false" aria-label="Отклонить заявку"><i class="fas fa-xmark"></i></button>' +
                '</div>' +
            '</article>';
        }).join('') + outgoing.map(function (request) {
            return '<article class="pd-friend-row is-pending">' +
                '<span class="pd-friend-avatar"><i class="fas fa-user-clock"></i></span>' +
                '<span class="pd-friend-name">' + esc(request.display_name) + '<small>Заявка отправлена · ожидает ответа</small></span>' +
                '<span class="pd-friend-pending">Ожидание</span>' +
            '</article>';
        }).join('');
    }

    async function syncFriends() {
        var friendsEl = document.getElementById('pdFriendsList');
        var requestsEl = document.getElementById('pdFriendRequests');
        var user = window.currentUser;
        if (!user || !user.id) {
            friendListMessage(friendsEl, 'Войдите в аккаунт, чтобы добавлять друзей.');
            friendListMessage(requestsEl, 'Заявки доступны после входа.');
            return;
        }

        if (friendsEl) friendsEl.innerHTML = loadingMessage('Загружаем друзей…');
        if (requestsEl) requestsEl.innerHTML = loadingMessage('Загружаем заявки…');

        try {
            var results = await Promise.all([
                supabaseClient.rpc('list_my_friends'),
                supabaseClient.rpc('list_friend_requests')
            ]);
            var friendsResult = results[0];
            var requestsResult = results[1];
            if (friendsResult.error) throw friendsResult.error;
            if (requestsResult.error) throw requestsResult.error;

            friendRecords = friendsResult.data || [];
            var requests = requestsResult.data || [];
            if (friendsEl) {
                friendsEl.innerHTML = friendRecords.length
                    ? friendRecords.map(friendRowHtml).join('')
                    : '<div class="pd-friend-empty">Пока нет друзей. Найдите человека по никнейму и отправьте заявку.</div>';
            }
            renderFriendRequests(requests);
        } catch (error) {
            console.error('Failed to load friends:', error);
            friendListMessage(friendsEl, 'Не удалось загрузить список друзей. Проверьте миграцию Supabase и попробуйте ещё раз.');
            friendListMessage(requestsEl, 'Не удалось загрузить заявки.');
            var pill = document.getElementById('pdFriendPill');
            if (pill) pill.hidden = true;
        }
    }

    function renderFriendSearchResults(users) {
        var container = document.getElementById('pdFriendSearchResults');
        if (!container) return;
        if (!users.length) {
            friendListMessage(container, 'Никнеймы не найдены. Пользователь должен сначала задать никнейм в настройках кабинета.');
            return;
        }
        container.innerHTML = users.map(function (user) {
            var alreadyFriend = friendRecords.some(function (friend) { return friend.friend_id === user.user_id; });
            return '<article class="pd-friend-row">' +
                '<span class="pd-friend-avatar"><i class="fas fa-user"></i></span>' +
                '<span class="pd-friend-name">' + esc(user.display_name) + '</span>' +
                (alreadyFriend
                    ? '<span class="pd-friend-pending"><i class="fas fa-user-check"></i> Уже в друзьях</span>'
                    : '<button class="pd-friend-action is-primary" type="button" data-friend-add="' + esc(user.user_id) + '" aria-label="Добавить ' + esc(user.display_name) + ' в друзья"><i class="fas fa-user-plus"></i><span>Добавить</span></button>') +
            '</article>';
        }).join('');
    }

    var friendSearchForm = document.getElementById('pdFriendSearchForm');
    if (friendSearchForm) {
        friendSearchForm.addEventListener('submit', async function (event) {
            event.preventDefault();
            var input = document.getElementById('pdFriendSearchInput');
            var query = input ? input.value.trim() : '';
            var container = document.getElementById('pdFriendSearchResults');
            if (query.length < 2) {
                friendListMessage(container, 'Введите минимум 2 символа никнейма.');
                if (input) input.focus();
                return;
            }
            if (!window.currentUser) {
                friendListMessage(container, 'Войдите в аккаунт, чтобы искать друзей.');
                return;
            }
            friendListMessage(container, 'Ищем пользователей…');
            try {
                var result = await supabaseClient.rpc('search_users_by_nickname', { p_query: query });
                if (result.error) throw result.error;
                renderFriendSearchResults(result.data || []);
            } catch (error) {
                console.error('Failed to search users:', error);
                friendListMessage(container, 'Поиск недоступен. Проверьте миграцию друзей в Supabase.');
            }
        });
    }

    async function openFriendChat(friendId) {
        var friend = friendRecords.filter(function (item) { return item.friend_id === friendId; })[0];
        if (!friend) return;
        activeFriendChat = friend;
        var browse = document.getElementById('pdFriendsBrowse');
        var panel = document.getElementById('pdFriendChat');
        var title = document.getElementById('pdFriendChatTitle');
        if (browse) browse.hidden = true;
        if (panel) panel.hidden = false;
        if (title) title.textContent = friend.display_name;
        await loadFriendMessages();
        stopFriendChatPolling();
        friendChatPollTimer = setInterval(function () {
            if (activeFriendChat && !document.hidden) loadFriendMessages();
        }, 5000);
    }

    async function loadFriendMessages() {
        if (!activeFriendChat) return;
        var container = document.getElementById('pdFriendChatMessages');
        if (!container) return;
        var result = await supabaseClient
            .from('friend_messages')
            .select('id, sender_id, body, created_at')
            .eq('friendship_id', activeFriendChat.friendship_id)
            .order('created_at', { ascending: true })
            .limit(200);
        if (result.error) {
            console.error('Failed to load friend messages:', result.error);
            friendListMessage(container, 'Не удалось загрузить переписку.');
            return;
        }
        var messages = result.data || [];
        if (!messages.length) {
            friendListMessage(container, 'Переписка пока пустая. Напишите первое сообщение!');
            return;
        }
        container.innerHTML = messages.map(function (message) {
            var mine = message.sender_id === window.currentUser.id;
            var time = message.created_at ? new Date(message.created_at).toLocaleString('ru-RU', {
                day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit'
            }) : '';
            return '<div class="pd-chat-msg ' + (mine ? 'is-me' : 'is-admin') + '">' +
                '<div class="pd-chat-bubble">' + esc(message.body) + '</div>' +
                '<div class="pd-chat-meta">' + (mine ? 'Вы' : esc(activeFriendChat.display_name)) + ' · ' + esc(time) + '</div>' +
            '</div>';
        }).join('');
        container.scrollTop = container.scrollHeight;
    }

    var friendChatBack = document.getElementById('pdFriendChatBack');
    if (friendChatBack) {
        friendChatBack.addEventListener('click', function () {
            showFriendBrowse();
        });
    }

    var friendChatForm = document.getElementById('pdFriendChatForm');
    if (friendChatForm) {
        friendChatForm.addEventListener('submit', async function (event) {
            event.preventDefault();
            if (!activeFriendChat || !window.currentUser) return;
            var input = document.getElementById('pdFriendChatInput');
            var send = document.getElementById('pdFriendChatSend');
            var body = input ? input.value.trim() : '';
            if (!body) return;
            if (send) send.disabled = true;
            try {
                var result = await supabaseClient.from('friend_messages').insert({
                    friendship_id: activeFriendChat.friendship_id,
                    sender_id: window.currentUser.id,
                    body: body
                });
                if (result.error) throw result.error;
                input.value = '';
                await loadFriendMessages();
            } catch (error) {
                console.error('Failed to send friend message:', error);
                if (window.showToast) window.showToast('Не удалось отправить сообщение. Проверьте соединение.', 'error');
            } finally {
                if (send) send.disabled = false;
            }
        });
    }

    document.addEventListener('click', async function (event) {
        var addButton = event.target.closest('[data-friend-add]');
        var respondButton = event.target.closest('[data-friend-respond]');
        var openButton = event.target.closest('[data-friend-open]');
        var removeButton = event.target.closest('[data-friend-remove]');
        try {
            if (addButton) {
                addButton.disabled = true;
                var sent = await supabaseClient.rpc('send_friend_request', {
                    p_receiver_id: addButton.getAttribute('data-friend-add')
                });
                if (sent.error) throw sent.error;
                if (window.showToast) window.showToast('Заявка отправлена.', 'success');
                await syncFriends();
                return;
            }
            if (respondButton) {
                respondButton.disabled = true;
                var response = await supabaseClient.rpc('respond_friend_request', {
                    p_request_id: respondButton.getAttribute('data-friend-respond'),
                    p_accept: respondButton.getAttribute('data-accept') === 'true'
                });
                if (response.error) throw response.error;
                if (window.showToast) window.showToast(respondButton.getAttribute('data-accept') === 'true' ? 'Заявка принята.' : 'Заявка отклонена.', 'success');
                await syncFriends();
                return;
            }
            if (openButton) {
                await openFriendChat(openButton.getAttribute('data-friend-open'));
                return;
            }
            if (removeButton) {
                var friendId = removeButton.getAttribute('data-friend-remove');
                var friend = friendRecords.filter(function (item) { return item.friend_id === friendId; })[0];
                if (!confirm('Удалить ' + (friend ? friend.display_name : 'этого пользователя') + ' из друзей и безвозвратно удалить всю переписку?')) return;
                removeButton.disabled = true;
                var removed = await supabaseClient.rpc('remove_friend', { p_friend_id: friendId });
                if (removed.error) throw removed.error;
                if (window.showToast) window.showToast('Пользователь удалён из друзей.', 'info');
                await syncFriends();
            }
        } catch (error) {
            console.error('Friend action failed:', error);
            if (window.showToast) {
                var message = error.message || '';
                if (message.includes('already friends')) message = 'Этот пользователь уже у вас в друзьях.';
                else if (message.includes('incoming request exists')) message = 'У вас уже есть входящая заявка от этого пользователя.';
                else if (message.includes('request already')) message = 'Заявка этому пользователю уже отправлена.';
                else message = 'Действие не выполнено. Проверьте миграцию Supabase и повторите попытку.';
                window.showToast(message, 'error');
            }
            await syncFriends();
        }
    });

    /* Делегированный клик: любые элементы с data-pd-view переключают вид */
    document.addEventListener('click', function (e) {
        var trigger = e.target.closest('[data-pd-view]');
        if (!trigger) return;
        if (!dashboard) return;
        e.preventDefault();
        showView(trigger.getAttribute('data-pd-view'));
    });

    /* Имя файла для отображения: из записи, иначе — из URL, иначе — «Файл». */
    function displayTitle(item) {
        var t = (item && item.title ? String(item.title) : '').trim();
        if (t && t !== 'Файл' && t !== 'Download' && t !== 'Скачать') return t;
        var url = (item && item.url) || '';
        try {
            var name = decodeURIComponent(url.split('?')[0].split('#')[0].split('/').pop() || '');
            if (name) return name.length > 48 ? name.slice(0, 45) + '…' : name;
        } catch (e) { }
        return 'Файл';
    }

    /* ---------- Рендер строк списка ---------- */
    function rowHtml(item, opts) {
        opts = opts || {};
        var isProtectedFile = typeof item.url === 'string' && item.url.indexOf('content/') === 0;
        var isImg = item.image && /^(https?:|data:|\.?\/?assets\/)/.test(item.image);
        var thumb = isImg
            ? '<img class="pd-row-thumb" src="' + esc(item.image) + '" alt="" loading="lazy" onerror="this.replaceWith(Object.assign(document.createElement(\'span\'),{className:\'pd-row-thumb\',innerHTML:\'<i class=\\\'fas fa-file\\\'></i>\'}))">'
            : '<span class="pd-row-thumb"><i class="fas fa-file"></i></span>';
        var actions = '';
        if (opts.favorite) {
            actions += '<button class="pd-row-btn is-active" data-fav="' + esc(item.url) + '" type="button" title="Убрать из избранного" aria-label="Убрать из избранного"><i class="fas fa-star"></i></button>';
        } else if (opts.favToggle) {
            var active = window.bncFavorites.has(item);
            actions += '<button class="pd-row-btn' + (active ? ' is-active' : '') + '" data-fav-toggle="' + esc(item.url) + '" type="button" title="В избранное" aria-label="В избранное"><i class="fas fa-star"></i></button>';
        }
        if (opts.remove) {
            actions += '<button class="pd-row-btn" data-remove="' + esc(item.url) + '" type="button" title="Удалить" aria-label="Удалить"><i class="fas fa-xmark"></i></button>';
        }
        return '<div class="pd-row">' + thumb +
            '<a class="pd-row-body" href="' + (isProtectedFile ? '#' : esc(item.url)) + '"' +
                (isProtectedFile ? ' data-protected-file="' + esc(item.url) + '"' : ' target="_blank" rel="noopener"') +
                ' title="' + esc(item.url) + '">' +
                '<span class="pd-row-title">' + esc(displayTitle(item)) + '</span>' +
                (opts.sub ? '<span class="pd-row-sub">' + esc(opts.sub) + '</span>' : '') +
            '</a>' +
            (actions ? '<div class="pd-row-actions">' + actions + '</div>' : '') +
        '</div>';
    }

    function emptyHtml(icon, text, linkHref, linkText) {
        return '<div class="pd-empty"><i class="fas ' + icon + '"></i><p>' + text + '</p>' +
            (linkHref ? '<a href="' + linkHref + '">' + linkText + '</a>' : '') + '</div>';
    }

    function renderDownloads() {
        var list = document.getElementById('pdDownloadsList');
        var recent = document.getElementById('pdRecentList');
        var countEl = document.getElementById('pdLocalDownloads');
        var items = window.bncHistory.all();

        if (countEl) countEl.textContent = String(items.length);

        if (list) {
            list.innerHTML = items.length
                ? items.map(function (it) { return rowHtml(it, { remove: true, favToggle: true, sub: relTime(it.date) }); }).join('')
                : emptyHtml('fa-clock-rotate-left', 'Здесь появятся файлы, которые вы скачали.', 'minecraft.html', 'Перейти в каталог');
        }

        if (recent) {
            recent.innerHTML = items.length
                ? items.slice(0, 4).map(function (it) { return rowHtml(it, { favToggle: true, sub: relTime(it.date) }); }).join('')
                : emptyHtml('fa-cloud-arrow-down', 'Вы пока ничего не скачивали.');
        }
    }

    function renderFavorites() {
        var list = document.getElementById('pdFavoritesList');
        if (!list) return;
        var items = window.bncFavorites.all();
        list.innerHTML = items.length
            ? items.map(function (it) { return rowHtml(it, { favorite: true, sub: relTime(it.date) }); }).join('')
            : emptyHtml('fa-star', 'Избранное пусто. Добавляйте файлы значком ★ — они появятся здесь.', 'utils.html', 'Смотреть утилиты');
    }

    function renderTickets() {
        var list = document.getElementById('pdTicketsList');
        var pill = document.getElementById('pdTicketPill');
        if (!list) return;
        // ЕДИНАЯ МОДЕЛЬ: статус приходит напрямую со сервера (таблица tickets) —
        // дополнительная карта статусов больше не нужна.
        var currentUserId = window.currentUser && window.currentUser.id;
        var tickets = currentUserId
            ? window.bncTickets.all().filter(function (ticket) { return ticket.user_id === currentUserId; })
            : [];
        var open = tickets.filter(function (t) { return t.status !== 'closed'; }).length;
        if (pill) {
            if (open > 0) { pill.hidden = false; pill.textContent = String(open); }
            else { pill.hidden = true; }
        }
        var STATUS = window.bncTickets.STATUS;
        var STATUS_ICON = { open: 'fa-circle-dot', reviewed: 'fa-eye', closed: 'fa-circle-check' };
        list.innerHTML = tickets.length
            ? tickets.map(function (t) {
                var st = STATUS[t.status] || STATUS.open;
                // Статус меняет только администратор в админ-панели —
                // посетителю он показывается как информационная плашка.
                var badge = '<span class="pd-badge ' + st.cls + '" title="Статус обращения"><i class="fas ' + (STATUS_ICON[t.status] || 'fa-circle-dot') + '"></i>' + st.label + '</span>';
                var sub = '№' + esc(t.id) + ' · ' + relTime(t.date) + (t.message ? ' · ' + esc(t.message.slice(0, 70)) : '');
                return '<div class="pd-row pd-row-ticket">' +
                    '<span class="pd-row-thumb"><i class="fas fa-headset"></i></span>' +
                    '<div class="pd-row-body">' +
                        '<span class="pd-row-title">' + esc(t.subject || t.message || 'Обращение') + '</span>' +
                        '<span class="pd-row-sub">' + sub + '</span>' +
                    '</div>' + badge +
                    '<div class="pd-row-actions">' +
                        '<button class="pd-row-btn" data-ticket-chat="' + esc(t.id) + '" type="button" title="Открыть переписку" aria-label="Открыть переписку"><i class="fas fa-comments"></i></button>' +
                        '<button class="pd-row-btn" data-ticket-remove="' + esc(t.id) + '" type="button" title="Удалить" aria-label="Удалить"><i class="fas fa-xmark"></i></button>' +
                    '</div>' +
                '</div>';
            }).join('')
            : ticketsLoading
                ? loadingMessage('Проверяем обращения в базе…')
                : ticketsLoadError
                    ? emptyHtml('fa-triangle-exclamation', 'Не удалось загрузить обращения. Проверьте подключение и попробуйте ещё раз.') +
                        '<button type="button" class="bnc-state-retry" onclick="window.syncProfileTickets()">Попробовать снова</button>'
                    : emptyHtml('fa-headset', 'У вас пока нет обращений. Если что-то не работает — напишите нам.');
    }

    /* Синхронизация тикетов с сервером.
       ЕДИНАЯ МОДЕЛЬ: читаем напрямую таблицу tickets —
       она уже привязана к пользователю, сопоставление по тексту не нужно. */
    async function syncTickets() {
        var user = window.currentUser;
        if (!user) return;

        ticketsLoading = true;
        ticketsLoadError = false;
        renderTickets();
        try {
            if (typeof supabaseClient === 'undefined') throw new Error('Supabase client is not available');
            var res = await supabaseClient
                .from('tickets')
                .select('id, user_id, subject, status, email, created_at, updated_at')
                .eq('user_id', user.id)
                .order('created_at', { ascending: false });

            if (res.error) throw res.error;
            if (!Array.isArray(res.data)) throw new Error('Unexpected tickets response');

            // Сервер — источник правды: заменяем локальный список на серверный.
            var remote = res.data;

            // Successful empty responses must also clear stale local tickets.
            var remoteIds = remote.map(function (m) { return String(m.id); });
            window.bncTickets.all().forEach(function (t) {
                if (remoteIds.indexOf(String(t.id)) === -1) window.bncTickets.removeQuiet(t.id);
            });

            // Добавляем/обновляем тикеты с сервера
            remote.forEach(function (m) {
                window.bncTickets.upsert({
                    id: String(m.id),
                    user_id: m.user_id,
                    subject: m.subject || 'Обращение',
                    message: m.subject || '',
                    email: m.email || '',
                    status: m.status || 'open',
                    date: m.created_at ? Date.parse(m.created_at) : Date.now()
                });
            });

            ticketsLoading = false;
            ticketsLoadError = false;
            renderTickets();
        } catch (error) {
            console.error('Failed to sync profile tickets:', error);
            ticketsLoading = false;
            ticketsLoadError = true;
            renderTickets();
        }
    }
    window.syncProfileTickets = syncTickets;

    /* ---------- Чат с поддержкой ---------- */
    var chatTicketId = null;
    var chatPollTimer = null;

    function chatEls() {
        return {
            list: document.getElementById('pdChatMessages'),
            title: document.getElementById('pdChatTitle'),
            status: document.getElementById('pdChatStatus'),
            form: document.getElementById('pdChatForm'),
            input: document.getElementById('pdChatInput'),
            send: document.getElementById('pdChatSend')
        };
    }

    function ticketById(id) {
        return window.bncTickets.all().filter(function (t) {
            return String(t.id) === String(id);
        })[0];
    }

    function renderChatMessages(rows) {
        var els = chatEls();
        if (!els.list) return;
        if (!rows || !rows.length) {
            els.list.innerHTML = '<div class="pd-chat-empty">Пока нет сообщений. Напишите первым — мы ответим.</div>';
            return;
        }
        els.list.innerHTML = rows.map(function (m) {
            var mine = !m.is_admin;
            var time = m.created_at ? new Date(m.created_at).toLocaleString('ru-RU') : '';
            return '<div class="pd-chat-msg ' + (mine ? 'is-me' : 'is-admin') + '">' +
                '<div class="pd-chat-bubble">' + esc(m.body) + '</div>' +
                '<div class="pd-chat-meta">' + (m.is_admin ? 'Поддержка' : 'Вы') + ' · ' + esc(time) + '</div>' +
            '</div>';
        }).join('');
        els.list.scrollTop = els.list.scrollHeight;
    }

    async function loadChat(ticketId) {
        var els = chatEls();
        if (!els.list) return;
        if (typeof supabaseClient === 'undefined') {
            els.list.innerHTML = '<div class="pd-chat-empty">Чат недоступен: нет соединения с сервером.</div>';
            return;
        }
        els.list.innerHTML = loadingMessage('Загружаем переписку…');
        try {
            var res = await supabaseClient
                .from('ticket_messages')
                .select('id, body, is_admin, created_at')
                .eq('ticket_id', ticketId)
                .order('created_at', { ascending: true });
            if (res.error) throw res.error;
            renderChatMessages(res.data || []);
        } catch (error) {
            console.error('Failed to load ticket conversation:', error);
            els.list.innerHTML = '<div class="pd-chat-empty">Не удалось загрузить переписку.</div>';
        }
    }

    function openChat(ticketId) {
        var t = ticketById(ticketId);
        var els = chatEls();
        if (els.title) els.title.textContent = t ? (t.subject || t.message || 'Обращение') : 'Обращение';
        if (els.status) {
            var st = window.bncTickets.STATUS[(t && t.status) || 'open'] || window.bncTickets.STATUS.open;
            els.status.innerHTML = '<span class="pd-badge ' + st.cls + '">' + st.label + '</span>';
        }
        if (els.input) els.input.value = '';

        // Все тикеты теперь живут на сервере (таблица tickets),
        // поэтому чат доступен всегда — проверять тип id не нужно.
        var f = document.getElementById('pdChatForm');
        if (f) f.style.display = 'flex';
        chatTicketId = String(ticketId);
        loadChat(chatTicketId);

        showView('chat');

        // Периодически подтягиваем новые ответы, пока чат открыт.
        if (chatPollTimer) clearInterval(chatPollTimer);
        chatPollTimer = setInterval(function () {
            if (chatTicketId && (location.hash === '#chat')) loadChat(chatTicketId);
        }, 15000);
    }
    window.bncOpenTicketChat = openChat;

    function closeChat() {
        if (chatPollTimer) { clearInterval(chatPollTimer); chatPollTimer = null; }
        chatTicketId = null;
    }

    async function sendChatMessage(e) {
        if (e) e.preventDefault();
        var els = chatEls();
        if (!els.input || !chatTicketId) return;
        var body = els.input.value.trim();
        if (!body) return;
        if (typeof supabaseClient === 'undefined') return;

        if (els.send) els.send.disabled = true;

        // sender_id и is_admin проставит ТРИГГЕР в БД по реальному uid —
        // здесь ничего угадывать не надо, поэтому отказать не может.
        var res = await supabaseClient
            .from('ticket_messages')
            .insert([{ ticket_id: String(chatTicketId), body: body }]);
        if (els.send) els.send.disabled = false;

        if (res.error) {
            if (window.showToast) window.showToast('Не удалось отправить: ' + res.error.message, 'error');
            return;
        }
        els.input.value = '';
        loadChat(chatTicketId);
    }

    function renderAll() {
        renderDownloads();
        renderFavorites();
        renderTickets();
        syncTickets();
    }

    /* Избранное / удаление из истории */
    document.addEventListener('click', function (e) {
        var protectedFile = e.target.closest('[data-protected-file]');
        if (protectedFile) {
            e.preventDefault();
            if (typeof window.handleDownloadClick === 'function') {
                window.handleDownloadClick(protectedFile.getAttribute('data-protected-file'), e, {
                    title: protectedFile.querySelector('.pd-row-title')?.textContent || 'Файл'
                });
            } else if (window.showToast) {
                window.showToast('Скачивание недоступно на этой странице.', 'error');
            }
            return;
        }

        var favBtn = e.target.closest('[data-fav-toggle]');
        if (favBtn) {
            e.preventDefault();
            var url = favBtn.getAttribute('data-fav-toggle');
            var item = window.bncHistory.all().filter(function (x) { return x.url === url; })[0] || { url: url, title: 'Файл' };
            var added = window.bncFavorites.toggle(item);
            if (window.showToast) window.showToast(added ? 'Добавлено в избранное' : 'Убрано из избранного', 'success');
            return;
        }

        var favRemove = e.target.closest('[data-fav]');
        if (favRemove) {
            e.preventDefault();
            window.bncFavorites.toggle({ url: favRemove.getAttribute('data-fav') });
            if (window.showToast) window.showToast('Убрано из избранного', 'info');
            return;
        }

        var removeBtn = e.target.closest('[data-remove]');
        var ticketRemove = e.target.closest('[data-ticket-remove]');
        var ticketChat = e.target.closest('[data-ticket-chat]');

        if (ticketChat) {
            e.preventDefault();
            openChat(ticketChat.getAttribute('data-ticket-chat'));
            return;
        }

        if (ticketRemove) {
            e.preventDefault();
            var rid = ticketRemove.getAttribute('data-ticket-remove');
            // Все тикеты теперь в таблице tickets. Удаляем и на сервере,
            // и локально (сообщения диалога уйдут каскадом по политике).
            if (typeof supabaseClient !== 'undefined') {
                supabaseClient.from('tickets').delete().eq('id', rid).then(function () { });
            }
            window.bncTickets.remove(rid);
            if (window.showToast) window.showToast('Обращение удалено', 'info');
            return;
        }

        if (removeBtn) {
            e.preventDefault();
            var rurl = removeBtn.getAttribute('data-remove');
            writeJSON(HISTORY_KEY, window.bncHistory.all().filter(function (x) { return x.url !== rurl; }));
            window.dispatchEvent(new CustomEvent('bnc:history-changed'));
        }
    });

    window.addEventListener('bnc:history-changed', renderAll);
    window.addEventListener('bnc:favorites-changed', renderAll);
    window.addEventListener('bnc:tickets-changed', renderAll);

    /* ---------- Элементы чата ---------- */
    var chatForm = document.getElementById('pdChatForm');
    if (chatForm) chatForm.addEventListener('submit', sendChatMessage);

    var chatBack = document.getElementById('pdChatBack');
    if (chatBack) chatBack.addEventListener('click', function () {
        closeChat();
        showView('tickets');
    });

    // Если пользователь ушёл с вида чата — останавливаем фоновое обновление.
    window.addEventListener('hashchange', function () {
        if (location.hash !== '#chat') closeChat();
    });

    /* ---------- Кнопки ---------- */
    var clearBtn = document.getElementById('pdClearHistory');
    if (clearBtn) {
        clearBtn.addEventListener('click', function () {
            if (!window.bncHistory.all().length) return;
            if (confirm('Очистить всю историю загрузок на этом устройстве?')) {
                window.bncHistory.clear();
                if (window.showToast) window.showToast('История очищена', 'info');
            }
        });
    }

    var newTicket = document.getElementById('pdNewTicket');
    if (newTicket) {
        newTicket.addEventListener('click', function () {
            var btn = document.getElementById('supportBtn');
            if (btn) { btn.click(); return; }
            if (typeof window.setupSupportModal === 'undefined' && window.showToast) window.showToast('Откройте раздел поддержки на главной', 'info');
        });
    }

    var nicknameForm = document.getElementById('pdNicknameForm');
    var nicknameInput = document.getElementById('pdNicknameInput');
    var nicknameSave = document.getElementById('pdNicknameSave');
    if (nicknameForm && nicknameInput) {
        nicknameForm.addEventListener('submit', async function (event) {
            event.preventDefault();
            var user = window.currentUser;
            if (!user || !user.id) {
                if (window.showToast) window.showToast('Войдите в аккаунт, чтобы изменить никнейм.', 'error');
                return;
            }

            var nickname = nicknameInput.value.trim();
            if (nickname && !/^[\p{L}\p{N}_ -]{2,24}$/u.test(nickname)) {
                if (window.showToast) window.showToast('Никнейм: от 2 до 24 символов — буквы, цифры, пробел, дефис или подчёркивание.', 'error');
                nicknameInput.focus();
                return;
            }

            if (nicknameSave) nicknameSave.disabled = true;
            try {
                var result = await supabaseClient
                    .from('profiles')
                    .upsert({ id: user.id, display_name: nickname || null }, { onConflict: 'id' });

                if (result.error) throw result.error;

                user.profile = user.profile || {};
                user.profile.display_name = nickname || null;
                nicknameInput.value = nickname;
                syncProfileDashboard(user);
                if (typeof window.checkUser === 'function') await window.checkUser(user);
                if (window.showToast) window.showToast(nickname ? 'Никнейм сохранён.' : 'Теперь отображается имя из Google.', 'success');
            } catch (error) {
                console.error('Failed to save profile nickname:', error);
                if (window.showToast) {
                    var message = error.code === '23505'
                        ? 'Этот никнейм уже занят. Выберите другой.'
                        : 'Не удалось сохранить никнейм. Проверьте подключение и миграцию профиля в Supabase.';
                    window.showToast(message, 'error');
                }
            } finally {
                if (nicknameSave) nicknameSave.disabled = false;
            }
        });

    }

    /* ---------- Совместимость со старым оверлеем ---------- */
    var overlay = document.getElementById('profileDashboard');

    function openProfileDashboard() {
        if (overlay) {
            syncProfileDashboard();
            overlay.classList.add('open');
            overlay.setAttribute('aria-hidden', 'false');
            document.body.classList.add('pd-open');
            if (window.lenis && window.lenis.stop) window.lenis.stop();
        } else if (!/account\.html$/.test(location.pathname)) {
            window.location.href = 'account.html';
        }
    }

    function closeProfileDashboard() {
        if (!overlay) return;
        overlay.classList.remove('open');
        overlay.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('pd-open');
        if (window.lenis && window.lenis.start) window.lenis.start();
    }

    /* Публичный API */
    window.openProfileDashboard = openProfileDashboard;
    window.closeProfileDashboard = closeProfileDashboard;
    window.syncProfileDashboard = syncProfileDashboard;

    /* ---------- Инициализация ---------- */
    function init() {
        if (dashboard) {
            renderAll();
            var initial = (location.hash || '').replace('#', '');
            // Чат нельзя восстановить без выбранного тикета — показываем тикеты.
            if (initial === 'chat') initial = 'tickets';
            showView(VIEW_TITLES[initial] ? initial : 'overview', { keepScroll: true });
        }
        syncProfileDashboard();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
