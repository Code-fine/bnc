/**
 * Мгновенный показ последних известных значений счётчиков.
 *
 * Подключается синхронно в <head>, поэтому срабатывает ДО первой отрисовки —
 * пользователь не видит мигающих нулей. Значения лежат в localStorage
 * (их пишет tracking.js / script.js при каждом изменении), а затем
 * tracking.js уточняет их из Supabase.
 *
 * Показываем кэш ТОЛЬКО для того пользователя, который его сохранил
 * (ключ bnc_tracked_user), чтобы чужие цифры не показывались.
 * Если данных ещё нет — ставим «—», а не «0».
 */
(function () {
    'use strict';

    function applyCachedStats() {
        var timeEl = document.getElementById('user-time');
        var dlEl = document.getElementById('user-downloads');
        if (!timeEl && !dlEl) return;

        var seconds = 0;
        var downloads = 0;
        var hasCache = false;
        try {
            seconds = parseInt(localStorage.getItem('bnc_last_seconds') || '0', 10) || 0;
            downloads = parseInt(localStorage.getItem('bnc_last_downloads') || '0', 10) || 0;
            hasCache = !!localStorage.getItem('bnc_tracked_user');
        } catch (e) { /* localStorage недоступен — показываем плейсхолдеры */ }

        // Пока нет подтверждённых данных — «—», чтобы не пугать нулями.
        if (timeEl) {
            if (hasCache && seconds > 0) {
                var hours = Math.floor(seconds / 3600);
                var minutes = Math.floor((seconds % 3600) / 60);
                timeEl.textContent = hours + ' ч. ' + minutes + ' мин.';
            } else {
                timeEl.textContent = '—';
            }
        }
        if (dlEl) {
            dlEl.textContent = (hasCache && downloads > 0) ? String(downloads) : '—';
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', applyCachedStats);
    } else {
        applyCachedStats();
    }
})();
