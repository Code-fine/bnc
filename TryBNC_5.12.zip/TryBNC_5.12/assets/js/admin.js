﻿/**
 * admin.js - Основная логика админ-панели BNC
 */

// --- Инициализация и проверка подключения к Supabase ---

// Конфигурация подключения к вашей базе данных
if (typeof supabase === 'undefined' && typeof window.supabase === 'undefined') {
    console.error("Критическая ошибка: библиотека Supabase JS не подключена в HTML!");
}

if (!window.supabaseClient) {
    window.supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
}
const supabaseClient = window.supabaseClient;

// --- Глобальное состояние и конфигурация ---
const adminState = {
    currentItem: null, // Хранит данные редактируемого элемента
    contentData: {},   // Кэш загруженного контента
    config: {
        allowedFileTypes: ['application/zip', 'application/x-rar-compressed', 'application/x-7z-compressed'],
        maxFileSize: 100 * 1024 * 1024, // 100 MB
        contentTypes: {
            'mods': 'Мод',
            'textures': 'Текстура',
            'shaders': 'Шейдер',
            'utils': 'Утилита',
            'maps': 'Карта',
            'minecraft_launchers': 'Лаунчер',
        },
        gameVersions: [ // Примерный список, можно расширить
            'Minecraft 1.21', 'Minecraft 1.20.4', 'Minecraft 1.19.2', 'Minecraft 1.18.1', 'Minecraft 1.16.5', 'Minecraft 1.12.2',
            'Stalker Anomaly', 'Stalker OGSR', 'Stalker OP-2.2'
        ],
        statuses: { 'draft': 'Черновик', 'published': 'Опубликован', 'review': 'На проверке' }
    }
};

// Helper function to safely get value from JSONB or string
function getSafeValue(field, lang = 'ru') {
    if (!field) return '';
    if (typeof field === 'object' && field !== null) {
        return field[lang] || '';
    }
    return field;
}

// Helper to render a single file entry HTML
const _renderSingleFileField = (file = {}, index) => {
    const uniqueId = `file_${index}_${Date.now()}`; // Ensure unique IDs for dynamic elements
    return `
        <div class="file-entry grid grid-cols-[1fr_auto] sm:grid-cols-[2fr_1fr_2fr_auto] items-center gap-3 p-3 bg-slate-800/50 rounded-lg border border-slate-700" data-id="${uniqueId}">
            <input type="text" name="file_name_${index}" placeholder="Название файла (RU)" class="form-input" value="${getSafeValue(file.name, 'ru')}" required>
            <input type="text" name="file_version_${index}" placeholder="Версия" class="form-input hidden sm:block" value="${file.version || ''}">
            <input type="text" name="file_url_${index}" placeholder="Ссылка или путь" class="form-input" value="${file.file_url || ''}" required>
            <button type="button" onclick="this.closest('.file-entry').remove()" class="p-2 rounded-lg text-slate-500 hover:bg-red-500/20 hover:text-red-400 transition-colors" title="Удалить файл" tabindex="-1">
                <i class="fas fa-trash-alt"></i>
            </button>
        </div>
    `;
};


// --- Управление контентом ---
async function renderContentManager() {
    const mainContent = document.getElementById('main-content');
    if (!mainContent) return;

    mainContent.innerHTML = `
        <div class="flex justify-between items-center mb-4 sm:mb-6">
            <h1 class="text-3xl font-bold">Управление контентом</h1>
        </div>
        <div id="content-list-container" class="space-y-4">
            <!-- Сюда будет рендериться список -->
            <div class="p-8 text-center text-gray-500">Загрузка контента...</div>
        </div>
    `;

    // Привязываем кнопку из шапки
    const addBtnHeader = document.getElementById('add-content-header-btn');
    if (addBtnHeader) addBtnHeader.onclick = () => renderContentForm(); // For new content

    await window.loadContent();
}

// Загрузка всего списка модов и утилит из Supabase на главную страницу админки
window.loadContent = async () => {
    const listContainer = document.getElementById('content-list-container');
    if (!listContainer) return;

    listContainer.innerHTML = `
        <div class="space-y-3" role="status" aria-live="polite">
            <div class="rounded-xl border border-slate-200 dark:border-slate-800 p-4 animate-pulse">
                <div class="flex items-center gap-3">
                    <div class="w-12 h-12 rounded-lg bg-slate-200 dark:bg-slate-700"></div>
                    <div class="flex-1 space-y-2">
                        <div class="h-3 w-1/4 rounded bg-slate-200 dark:bg-slate-700"></div>
                        <div class="h-4 w-1/2 rounded bg-slate-200 dark:bg-slate-700"></div>
                    </div>
                </div>
            </div>
            <div class="rounded-xl border border-slate-200 dark:border-slate-800 p-4 animate-pulse">
                <div class="flex items-center gap-3">
                    <div class="w-12 h-12 rounded-lg bg-slate-200 dark:bg-slate-700"></div>
                    <div class="flex-1 space-y-2">
                        <div class="h-3 w-1/4 rounded bg-slate-200 dark:bg-slate-700"></div>
                        <div class="h-4 w-1/2 rounded bg-slate-200 dark:bg-slate-700"></div>
                    </div>
                </div>
            </div>
            <p class="text-center text-sm text-slate-500 dark:text-slate-400">Загружаем данные из базы…</p>
        </div>`;
    const slowLoadTimer = setTimeout(() => {
        if (!listContainer.isConnected) return;
        listContainer.innerHTML = '<div class="rounded-xl border border-indigo-200 bg-indigo-50 p-6 text-center text-indigo-700 dark:border-indigo-900/60 dark:bg-indigo-950/30 dark:text-indigo-300" role="status" aria-live="polite"><i class="fas fa-arrows-rotate fa-spin mb-2 text-xl" aria-hidden="true"></i><p>База обновляется — загрузка контента занимает больше времени.</p></div>';
    }, 8000);

    try {
        const { data, error } = await supabaseClient
            .from('content')
            .select('*')
            .order('created_at', { ascending: false });

        if (error) throw error;

        if (!data || data.length === 0) {
            listContainer.innerHTML = '<div class="rounded-xl border border-dashed border-slate-300 dark:border-slate-700 p-8 text-center text-slate-500 dark:text-slate-400"><i class="fa-regular fa-folder-open mb-3 text-2xl" aria-hidden="true"></i><p>В базе пока нет контента.</p><p class="mt-1 text-sm">Создайте первую карточку, и она появится здесь.</p></div>';
            return;
        }

        let html = '';
        data.forEach(item => {
            const titleText = getSafeValue(item.title, 'ru') || 'Без названия';
            
            // --- ИСПРАВЛЕНИЕ: Безопасно извлекаем описание из объекта author ---
            const descriptionText = (typeof item.author === 'object' && item.author !== null) 
                ? (item.author.ru || item.author.en || '') 
                : (item.author || 'Нет описания');

            const isPublished = item.status === 'published';

            html += `
                <div class="flex flex-col md:flex-row items-start md:items-center justify-between bg-white dark:bg-[#1e293b] p-4 rounded-xl border border-slate-100 dark:border-slate-800/60 shadow-sm dark:shadow-md mb-3 gap-4">
                    <div class="flex items-center gap-3">
                        <img src="${item.image || 'assets/images/icon/icon1.png'}" alt="Обложка" class="w-12 h-12 rounded-lg object-cover flex-shrink-0">
                        <div>
                            <div class="flex items-center gap-2 mb-1">
                                <span id="badge-${item.id}" class="${isPublished ? 'bg-green-100 text-green-800 dark:bg-green-600 dark:text-white' : 'bg-orange-100 text-orange-800 dark:bg-orange-600 dark:text-white'} text-[10px] uppercase font-bold px-2 py-0.5 rounded">
                                    ${isPublished ? 'Опубликован' : 'Черновик'}
                                </span>
                                <span class="bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300 text-[10px] uppercase font-bold px-2 py-0.5 rounded">
                                    ${item.type || 'mod'}
                                </span>
                            </div>
                            <h3 class="text-slate-900 dark:text-white font-bold text-base leading-tight">${titleText}</h3>
                            <p class="text-slate-500 dark:text-slate-400 text-xs mt-1 max-w-md line-clamp-1">${descriptionText}</p>
                        </div>
                    </div>
                    
                    <div class="flex items-center gap-4 w-full md:w-auto justify-end">
                        <button onclick="window.openViewModal('${item.id}')" class="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-sky-400 w-9 h-9 flex items-center justify-center transition-colors" title="Просмотр"><i class="fa-solid fa-eye"></i></button>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" class="sr-only peer" ${isPublished ? 'checked' : ''} onchange="window.toggleContentStatus('${item.id}', this.checked)">
                            <div class="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                        </label>
                        
                        <button onclick="window.openEditModal('${item.id}')" class="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-indigo-400 w-9 h-9 flex items-center justify-center transition-colors" title="Редактировать"><i class="fa-solid fa-pen-to-square"></i></button>
                        <button onclick="window.duplicateContent('${item.id}')" class="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-purple-400 w-9 h-9 flex items-center justify-center transition-colors" title="Копировать"><i class="fa-solid fa-copy"></i></button>
                        <button onclick="window.deleteContent('${item.id}')" class="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-red-900/50 border border-slate-200 dark:border-slate-700 text-red-500 w-9 h-9 flex items-center justify-center transition-colors" title="Удалить"><i class="fa-solid fa-trash-can"></i></button>
                    </div>
                </div>
            `;
        });

        listContainer.innerHTML = html;

    } catch (err) {
        console.error('Failed to load admin content:', err);
        listContainer.innerHTML = '<div class="rounded-xl border border-red-200 bg-red-50 p-6 text-center text-red-600 dark:border-red-900/60 dark:bg-red-950/30 dark:text-red-300"><i class="fa-solid fa-triangle-exclamation mb-2 text-xl" aria-hidden="true"></i><p>Не удалось загрузить контент из базы.</p><p class="mt-1 text-sm">Проверьте подключение и попробуйте ещё раз.</p><button type="button" onclick="window.loadContent()" class="mt-4 rounded-lg bg-red-600 px-4 py-2 text-white hover:bg-red-700">Попробовать снова</button></div>';
    } finally {
        clearTimeout(slowLoadTimer);
    }
};

// Живое переключение статуса публикации тумблером прямо из списка
window.toggleContentStatus = async (contentId, isChecked) => {
    const targetStatus = isChecked ? 'published' : 'draft';
    const badge = document.getElementById(`badge-${contentId}`);

    try {
        const { error } = await supabaseClient
            .from('content')
            .update({ status: targetStatus })
            .eq('id', contentId);

    if (error) {
        throw error;
    }

        if (badge) {
            badge.innerText = isChecked ? 'Опубликован' : 'Черновик';
            badge.className = (isChecked ? 'bg-green-100 text-green-800 dark:bg-green-600 dark:text-white' : 'bg-orange-100 text-orange-800 dark:bg-orange-600 dark:text-white') + ' text-[10px] uppercase font-bold px-2 py-0.5 rounded';
        }
        console.log("Статус успешно обновлен!");
        if (window.showToast) window.showToast("Статус успешно обновлен!", "success");
    } catch (err) {
        if (window.showToast) window.showToast("Ошибка изменения статуса: " + err.message, "error");
        else alert("Ошибка изменения статуса: " + err.message);
        window.loadContent();
    }
};


// --- Форма и CRUD операции (renderContentForm now primarily builds the structure) ---
// Отрисовка модального окна и автоматическое наполнение инпутов данными
function renderContentForm(item = null) {
    const isEditing = item !== null;
    const modalContainer = document.getElementById('content-modal-container') || document.getElementById('modal-container');
    
    if (!modalContainer) {
        return console.error("Ошибка: На странице отсутствует контейнер для вывода модального окна!");
    }
    console.log("Реальные данные из базы:", item);
    
    // --- Извлечение данных (с проверкой на null для новых записей) ---
    const titleRU = isEditing ? (item.title?.ru || item.title || '') : '';
    const descRU = isEditing ? ((typeof item.author === 'object' && item.author !== null) ? (item.author.ru || item.author.en || '') : (item.author || '')) : '';

    const currentStatus = isEditing ? (item.status || 'draft') : 'draft';
    const currentType = isEditing ? (item.type || 'mods') : 'mods';
    
    // Предпочитаем исходную колонку files_list и поддерживаем files при наличии.
    let linksArray = [];
    if (item && item.files_list) {
        linksArray = typeof item.files_list === 'string' ? JSON.parse(item.files_list) : item.files_list;
    }
    if ((!Array.isArray(linksArray) || !linksArray.length) && item?.files) {
        linksArray = typeof item.files === 'string' ? JSON.parse(item.files) : item.files;
    }
    linksArray = Array.isArray(linksArray)
        ? linksArray.map(file => file && typeof file === 'object'
            ? { ...file, url: file.url || file.file_url || '' }
            : file)
        : [];
    // Если в базе пусто или это не массив, создаем одну пустую строчку
    if (!Array.isArray(linksArray) || linksArray.length === 0) {
        linksArray = [{ name: '', url: '' }];
    }

    // Генерируем HTML для полей ввода файлов
    let filesHTML = '';
    linksArray.forEach((link, idx) => {
        // --- ИСПРАВЛЕНИЕ 2: Подстановка старых данных в HTML ---
        // Исправлено: Безопасное извлечение имени файла из объекта link.name
        const linkName = (typeof link === 'object' && link !== null) ? (link.name?.ru || link.name || '') : '';
        
        const linkIcon = (typeof link === 'object' && link !== null) ? (link.icon || '') : '';

        filesHTML += `
            <div class="file-row grid grid-cols-1 md:grid-cols-[1fr_1fr_1fr_auto] gap-2 items-center bg-slate-900 p-2 rounded-lg border border-slate-700 mb-2" data-id="${idx}">
                <input type="text" class="file-name-input form-input" placeholder="Название файла" value="${linkName}" required>
                <div class="flex min-w-0 flex-col gap-2">
                    <input type="text" class="file-url-input form-input min-w-0" placeholder="Ссылка HTTP(S) или путь content/..." value="${link.url || ''}" required>
                    <div class="flex min-w-0 gap-2">
                        <input type="url" class="file-source-url form-input min-w-0" placeholder="Ссылка HTTP или HTTPS">
                        <button type="button" onclick="window.importPrivateContentFile(this)" class="shrink-0 rounded-lg bg-indigo-600 px-3 py-2 text-xs text-white hover:bg-indigo-500">По ссылке</button>
                    </div>
                    <label class="w-fit cursor-pointer rounded-lg bg-slate-800 px-3 py-2 text-xs text-slate-200 hover:bg-slate-700">
                        Загрузить с устройства
                        <input type="file" accept=".zip,.rar,.7z" class="hidden" onchange="window.uploadPrivateContentFile(this)">
                    </label>
                </div>
                <input type="text" class="file-icon-input form-input" placeholder="Иконка (URL, необязательно)" value="${linkIcon}">
                <button type="button" onclick="this.closest('.file-row').remove()" class="p-2 rounded-lg text-slate-500 hover:bg-red-500/20 hover:text-red-400 transition-colors" title="Удалить файл">
                    <i class="fas fa-trash-alt"></i>
                </button>
            </div>
        `;
    });

    modalContainer.innerHTML = `
        <div id="modal-overlay" class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-70 p-4 overflow-y-auto">
            <div id="content-modal" class="relative w-full max-w-2xl bg-[#0f172a] rounded-xl border border-slate-800 shadow-2xl p-6 text-slate-100 max-h-[90vh] flex flex-col">

                <div class="flex justify-between items-center mb-6 border-b border-slate-800 pb-3">
                    <h2 class="text-xl font-bold text-white">${isEditing ? 'Редактирование' : 'Новый контент'}</h2>
                    <button onclick="closeContentForm()" class="text-slate-400 hover:text-white text-2xl">&times;</button>
                </div>

                <div class="flex-1 overflow-y-auto pr-2">
                    <form id="edit-content-form" onsubmit="window.saveEditedContent(event, '${isEditing ? item.id : ''}')" class="space-y-4">
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-xs font-semibold text-slate-400 mb-1">Категория</label>
                                <select id="edit-type" class="form-select">
                                    ${Object.entries(adminState.config.contentTypes).map(([key, value]) => `<option value="${key}" ${currentType === key ? 'selected' : ''}>${value}</option>`).join('')}
                                </select>
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-slate-400 mb-1">Статус публикации</label>
                                <select id="edit-status" class="form-select">
                                    <option value="draft" ${currentStatus === 'draft' ? 'selected' : ''}>Черновик</option>
                                    <option value="published" ${currentStatus === 'published' ? 'selected' : ''}>Опубликован</option>
                                </select>
                            </div>
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-slate-400 mb-1">Название</label>
                            <input type="text" id="edit-title-ru" value="${titleRU}" class="form-input" required>
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-slate-400 mb-1">Описание</label>
                            <textarea id="edit-description-ru" class="form-input" rows="3" placeholder="Краткое описание карточки...">${descRU}</textarea>
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-slate-400 mb-1">Ссылка на обложку</label>
                            <input type="text" id="edit-image-url" value="${isEditing ? (item.image || '') : ''}" class="form-input" placeholder="https://example.com/image.png">
                        </div>

                        <div class="pt-2">
                            <label class="block text-sm font-bold text-white mb-2">Файлы для скачивания</label>
                            <p class="mb-2 text-xs text-slate-400">По ссылке можно импортировать публичный файл любого формата размером до 100 МБ.</p>
                            <div id="files-downloads-container">${filesHTML}</div>
                            <button type="button" onclick="window.addNewFileRow()" class="mt-2 text-xs text-indigo-400 hover:text-indigo-300 font-semibold">+ Добавить еще один файл</button>
                        </div>

                        <div id="form-error" class="text-red-500 text-sm hidden"></div>

                        <div class="flex justify-end gap-3 pt-4 border-t border-slate-800 mt-6">
                            <button type="button" onclick="window.closeContentForm()" class="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg text-sm transition">Отмена</button>
                            <button type="submit" id="save-btn" class="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm transition">Сохранить изменения</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    `;
}

// Добавление новой строки для утилиты / файла «на лету»
window.addNewFileRow = () => {
    const container = document.getElementById('files-downloads-container');
    if (!container) return;
    const div = document.createElement('div');
    div.className = 'file-row grid grid-cols-1 md:grid-cols-[1fr_1fr_1fr_auto] gap-2 items-center bg-slate-900 p-2 rounded-lg border border-slate-700 mb-2';
    div.innerHTML = `
        <input type="text" class="file-name-input form-input" placeholder="Название файла" required>
        <div class="flex min-w-0 flex-col gap-2">
            <input type="text" class="file-url-input form-input min-w-0" placeholder="Ссылка HTTP(S) или путь content/..." required>
            <div class="flex min-w-0 gap-2">
                <input type="url" class="file-source-url form-input min-w-0" placeholder="Ссылка HTTP или HTTPS">
                <button type="button" onclick="window.importPrivateContentFile(this)" class="shrink-0 rounded-lg bg-indigo-600 px-3 py-2 text-xs text-white hover:bg-indigo-500">По ссылке</button>
            </div>
            <label class="w-fit cursor-pointer rounded-lg bg-slate-800 px-3 py-2 text-xs text-slate-200 hover:bg-slate-700">
                Загрузить с устройства
                <input type="file" accept=".zip,.rar,.7z" class="hidden" onchange="window.uploadPrivateContentFile(this)">
            </label>
        </div>
        <input type="text" class="file-icon-input form-input" placeholder="Иконка (URL, необязательно)">
        <button type="button" onclick="this.closest('.file-row').remove()" class="p-2 rounded-lg text-slate-500 hover:bg-red-500/20 hover:text-red-400 transition-colors" title="Удалить файл">
            <i class="fas fa-trash-alt"></i>
        </button>
    `;
    container.appendChild(div);
};

window.uploadPrivateContentFile = async (input) => {
    const file = input.files && input.files[0];
    const row = input.closest('.file-row');
    const pathInput = row && row.querySelector('.file-url-input');
    if (!file || !pathInput) return;

    const extension = file.name.split('.').pop().toLowerCase();
    if (!['zip', 'rar', '7z'].includes(extension)) {
        input.value = '';
        if (window.showToast) window.showToast('Поддерживаются только файлы ZIP, RAR и 7Z.', 'error');
        return;
    }
    if (file.size > adminState.config.maxFileSize) {
        input.value = '';
        if (window.showToast) window.showToast('Размер файла превышает ограничение 100 МБ.', 'error');
        return;
    }

    const safeName = file.name.replace(/[^A-Za-z0-9._-]/g, '_').slice(-150);
    const storagePath = `content/${crypto.randomUUID()}/${safeName || `download.${extension}`}`;
    input.disabled = true;
    row.dataset.uploading = 'true';
    try {
        const { error } = await supabaseClient.storage
            .from('content-files')
            .upload(storagePath, file, {
                cacheControl: '3600',
                contentType: file.type || 'application/octet-stream',
                upsert: false
            });
        if (error) throw error;
        pathInput.value = storagePath;
        if (window.showToast) window.showToast('Файл загружен.', 'success');
    } catch (error) {
        console.error('Не удалось загрузить файл:', error);
        if (window.showToast) window.showToast(error.message || 'Не удалось загрузить файл.', 'error');
    } finally {
        input.disabled = false;
        input.value = '';
        delete row.dataset.uploading;
    }
};

window.importPrivateContentFile = async (button) => {
    const row = button.closest('.file-row');
    const sourceInput = row && row.querySelector('.file-source-url');
    const pathInput = row && row.querySelector('.file-url-input');
    const nameInput = row && row.querySelector('.file-name-input');
    const sourceUrl = sourceInput && sourceInput.value.trim();
    if (!row || !sourceInput || !pathInput || !nameInput || !sourceUrl) {
        if (window.showToast) window.showToast('Вставьте HTTP- или HTTPS-ссылку на файл.', 'error');
        return;
    }

    try {
        const url = new URL(sourceUrl);
        if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) {
            throw new Error('Укажите публичную HTTP- или HTTPS-ссылку.');
        }
        pathInput.value = url.toString();
        sourceInput.value = '';
        if (!nameInput.value.trim()) {
            nameInput.value = decodeURIComponent(url.pathname.split('/').pop() || 'Файл');
        }
        if (window.showToast) window.showToast('Ссылка на файл добавлена.', 'success');
    } catch (error) {
        console.warn('Не удалось добавить ссылку на файл:', error);
        if (window.showToast) window.showToast(error.message || 'Не удалось добавить ссылку.', 'error');
    }
};

window.saveEditedContent = async (event, itemId) => {
    event.preventDefault();
    const saveBtn = document.getElementById('save-btn');
    const errorDiv = document.getElementById('form-error');
    if (!saveBtn || !errorDiv) return;

    saveBtn.disabled = true;
    saveBtn.textContent = 'Сохранение...';
    errorDiv.classList.add('hidden', 'opacity-0');

    try {
        // Сбор данных из полей
        // Сбор массива файлов
        const filesContainer = document.getElementById('files-downloads-container');
        if (!filesContainer) throw new Error("Не найден контейнер с файлами.");
        
        const fileRows = filesContainer.querySelectorAll('.file-row');
        if (Array.from(fileRows).some(row => row.dataset.uploading === 'true')) {
            throw new Error("Дождитесь завершения загрузки файлов.");
        }
        const linksList = Array.from(fileRows).map(row => {
            const nameInput = row.querySelector('.file-name-input');
            const urlInput = row.querySelector('.file-url-input');
            const iconInput = row.querySelector('.file-icon-input');
            const fileObj = { name: nameInput.value, url: urlInput.value };
            // Иконку сохраняем только если она задана вручную
            if (iconInput && iconInput.value.trim()) fileObj.icon = iconInput.value.trim();
            return fileObj;
        }).filter(link => link.name && link.url); // Убираем пустые строки

        if (linksList.length === 0) {
            throw new Error("Добавьте хотя бы один файл для скачивания.");
        }
        if (linksList.some(link => {
            const isStoragePath = /^content\/[A-Za-z0-9][A-Za-z0-9._/-]{0,499}$/.test(link.url)
                && !link.url.includes('..') && !link.url.includes('//');
            if (isStoragePath) return false;
            try {
                const url = new URL(link.url);
                return !['http:', 'https:'].includes(url.protocol) || !!url.username || !!url.password;
            } catch {
                return true;
            }
        })) {
            throw new Error("Укажите корректную ссылку на файл или загрузите файл с устройства.");
        }

        // --- ИСПРАВЛЕНИЕ 3: Логика сохранения изменений ---
        const updatedPayload = {
            type: document.getElementById('edit-type').value,
            status: document.getElementById('edit-status').value,
            title: { ru: document.getElementById('edit-title-ru').value, en: "" },
            author: { ru: document.getElementById('edit-description-ru').value, en: "" },
            image: document.getElementById('edit-image-url').value.trim(),
            files_list: linksList
        };

        let result;
        if (itemId) {
            // Обновление существующей записи
            result = await supabaseClient.from('content').update(updatedPayload).eq('id', itemId);
        } else {
            // Создание новой записи
            result = await supabaseClient.from('content').insert([updatedPayload]);
        }

        if (result.error) {
            throw result.error;
        }

        closeContentForm();
        await window.loadContent(); // Перезагружаем список

    } catch (error) {
        console.error("Ошибка сохранения:", error);
        errorDiv.textContent = error.message;
        errorDiv.classList.remove('hidden');
        setTimeout(() => errorDiv.classList.add('opacity-100'), 10);
    } finally {
        saveBtn.disabled = false;
        saveBtn.textContent = 'Сохранить изменения';
    }
};

// --- Новая функция просмотра карточки с дизайном 2026 ---
window.openViewModal = async (contentId) => {
    // 1. Сохраняем рабочую логику запроса к базе
    const { data: item, error } = await supabaseClient
        .from('content')
        .select('*')
        .eq('id', contentId)
        .single();

    if (error || !item) {
        if (window.showToast) window.showToast("Ошибка загрузки", "error");
        else alert("Ошибка загрузки");
        return;
    }

    const titleRU = item.title?.ru || item.title || 'Без названия';
    
    // 2. Сохраняем логику парсинга массива файлов из колонки files
    let linksArray = [];
    if (item.files || item.files_list) {
        linksArray = typeof item.files === 'string' ? JSON.parse(item.files) : item.files;
    }
    if ((!Array.isArray(linksArray) || !linksArray.length) && Array.isArray(item.files_list)) {
        linksArray = item.files_list;
    }
    linksArray = Array.isArray(linksArray)
        ? linksArray.map(file => file && typeof file === 'object'
            ? { ...file, url: file.url || file.file_url || '' }
            : file)
        : [];
    if (!Array.isArray(linksArray)) linksArray = [];

    // 3. Сохраняем цикл генерации кнопок для скачивания (в новом дизайне 2026)
    let linksHTML = '';
    linksArray.forEach((link) => {
        const linkName = (typeof link === 'object' && link !== null) ? (link.name?.ru || link.name || 'Скачать файл') : 'Скачать файл';
        linksHTML += `
            <button type="button" class="admin-download-link flex items-center justify-between w-full p-4 rounded-xl border border-white/5 bg-white/[0.02] hover:bg-indigo-600/10 hover:border-indigo-500/30 transition-all duration-300 group cursor-pointer">
                <div class="flex items-center gap-3.5">
                    <div class="flex items-center justify-center w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 group-hover:bg-amber-500 group-hover:text-white transition-all duration-300 shadow-sm">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-5 h-5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M16.5 12 12 16.5m0 0L7.5 12m4.5 4.5V3" />
                        </svg>
                    </div>
                    <div class="text-left">
                        <p class="text-sm font-bold text-slate-200 group-hover:text-white transition-colors">${linkName}</p>
                        <p class="text-[11px] text-slate-400 tracking-wide">Безопасное скачивание файла</p>
                    </div>
                </div>
                <div class="text-slate-500 group-hover:text-amber-400 group-hover:translate-x-1 transition-all duration-300">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2.5" stroke="currentColor" class="w-4 h-4">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3" />
                    </svg>
                </div>
            </button>
        `;
    });

    // 4. Находим контейнер окон на сайте
    const modalContainer = document.getElementById('content-modal-container') || document.getElementById('modal-container');
    if (!modalContainer) return;
    
    // 5. Вставляем новый премиальный Glassmorphic HTML
    modalContainer.innerHTML = `
        <div id="modal-overlay" class="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 animate-fade-in" onclick="if (event.target === this) window.closeContentForm()">
            <div class="relative w-full max-w-lg bg-[#0b0f19]/90 backdrop-blur-2xl rounded-3xl border border-white/10 shadow-[0_0_50px_-12px_rgba(99,102,241,0.4)] pt-16 px-6 pb-6 text-slate-100 flex flex-col items-center overflow-hidden">
                
                <button onclick="window.closeContentForm()" class="absolute top-4 right-4 z-10 flex items-center justify-center w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white border border-white/5 transition-all duration-300">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2.5" stroke="currentColor" class="w-4 h-4">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" />
                    </svg>
                </button>

                <div class="w-full aspect-[16/10] rounded-2xl overflow-hidden border border-white/5 shadow-md relative">
                    <img src="${item.image || 'assets/images/icon/icon1.png'}" alt="${titleRU}" class="w-full h-full object-cover">
                    <div class="absolute inset-0 bg-gradient-to-t from-slate-950/40 to-transparent"></div>
                </div>

                <div class="w-full text-center">
                    <h2 class="text-2xl font-black tracking-tight text-white mt-5">${titleRU}</h2>
                </div>
                <div class="w-full space-y-2.5">${linksHTML}</div>
            </div>
        </div>
    `;
    modalContainer.querySelectorAll('.admin-download-link').forEach((button, index) => {
        button.addEventListener('click', async () => {
            const link = linksArray[index];
            const downloadWindow = window.open('about:blank', '_blank');
            if (downloadWindow) downloadWindow.opener = null;
            if (!downloadWindow) {
                if (window.showToast) window.showToast('Разрешите всплывающие окна, чтобы скачать файл.', 'error');
                return;
            }
            try {
                const { data, error } = await supabaseClient.storage
                    .from('content-files')
                    .createSignedUrl(link && link.url, 60, { download: true });
                if (error) throw error;
                if (!data?.signedUrl) throw new Error('Не удалось создать ссылку на файл.');
                downloadWindow.location.replace(data.signedUrl);
            } catch (error) {
                if (!downloadWindow.closed) downloadWindow.close();
                console.error('Не удалось скачать файл из админ-панели:', error);
                if (window.showToast) window.showToast(error.message || 'Не удалось скачать файл.', 'error');
            }
        });
    });
};
// --- Глобальная функция для открытия модального окна, принимает весь объект ---
// Открытие окна редактирования карточки контента (теперь по ID)
window.openEditModal = async (contentId) => {
    try {
        console.log("Загрузка карточки из Supabase, ID:", contentId);

        const { data, error } = await supabaseClient
            .from('content')
            .select('*')
            .eq('id', contentId)
            .single();

        if (error || !data) {
            if (window.showToast) window.showToast("Не удалось загрузить данные из базы: " + error?.message, "error");
            else alert("Не удалось загрузить данные из базы: " + error?.message);
            return;
        }

        renderContentForm(data);
    } catch (e) {
        console.error("Ошибка при открытии модального окна:", e);
        if (window.showToast) window.showToast("Произошла критическая ошибка при обработке данных.", "error");
        else alert("Произошла критическая ошибка при обработке данных.");
    }
};

// Открытие чистого окна создания нового контента
window.openCreateModal = () => {
    renderContentForm(null);
};

// Функция закрытия формы
window.closeContentForm = () => {
    const modalOverlay = document.getElementById('modal-overlay');
    if (modalOverlay) {
        // Добавляем класс для анимации исчезновения
        modalOverlay.classList.add('animate-fade-out');
        // Удаляем элемент из DOM после завершения анимации
        setTimeout(() => {
            modalOverlay.remove();
        }, 300);
    }
};

window.deleteContent = async (contentId) => {
    if (!confirm('Вы уверены, что хотите удалить этот элемент? Это действие необратимо.')) {
        return;
    }

    try {
        // 1. Получаем информацию о файлах и изображении перед удалением
        const { data: itemToDelete, error: fetchError } = await supabaseClient
            .from('content')
            .select('*')
            .eq('id', contentId)
            .single();

        if (fetchError) throw new Error(`Не удалось получить данные для удаления: ${fetchError.message}`);

        // 2. Удаляем связанные файлы из Storage
        const contentFiles = itemToDelete && (itemToDelete.files_list || itemToDelete.files);
        if (Array.isArray(contentFiles)) {
            const filesToRemove = contentFiles
                .map(file => file && (file.url || file.file_url))
                .filter(path => typeof path === 'string')
                .map(path => {
                    if (path.startsWith('content/')) return path;
                    if (!path.includes(SUPABASE_URL)) return null;
                    return new URL(path).pathname.split('/content-files/')[1] || null;
                })
                .filter(Boolean);

            if (filesToRemove.length > 0) {
                const { error: storageError } = await supabaseClient.storage.from('content-files').remove(filesToRemove);
                if (storageError) console.warn("Не удалось удалить связанные файлы:", storageError.message);
            }
        }

        // 3. Удаляем саму запись из таблицы
        const { error } = await supabaseClient.from('content').delete().eq('id', contentId);
        if (error) throw error;
        
        // Перезагружаем список, чтобы отразить удаление
        await window.loadContent();
        if (window.showToast) window.showToast("Карточка успешно удалена!", "success");

    } catch (err) {
        console.error("Delete error:", err);
        if (window.showToast) window.showToast(`Ошибка удаления: ${err.message}`, "error");
        else alert(`Ошибка удаления: ${err.message}`);
    }
}

// --- Функция дублирования контента ---
window.duplicateContent = async (contentId) => {
    if (!confirm('Вы уверены, что хотите создать копию этой карточки?')) {
        return;
    }

    try {
        // 1. Получаем оригинальную карточку
        const { data: originalItem, error: fetchError } = await supabaseClient
            .from('content')
            .select('*')
            .eq('id', contentId)
            .single();

        if (fetchError) throw new Error(`Не удалось получить данные для копирования: ${fetchError.message}`);

        // 2. Создаем новый объект на основе оригинала
        const newItem = { ...originalItem };
        delete newItem.id; // Удаляем ID, чтобы Supabase сгенерировал новый
        newItem.created_at = new Date().toISOString(); // Обновляем дату создания
        newItem.status = 'draft'; // Устанавливаем статус "Черновик"
        newItem.title.ru = `${getSafeValue(newItem.title, 'ru')} (Копия)`; // Добавляем "(Копия)" к названию
        // Если есть английское название, тоже добавляем
        if (newItem.title.en) newItem.title.en = `${getSafeValue(newItem.title, 'en')} (Copy)`;

        // 3. Вставляем новую запись в базу данных
        const { error: insertError } = await supabaseClient.from('content').insert([newItem]);
        if (insertError) throw insertError;

        await window.loadContent(); // Перезагружаем список, чтобы показать новую карточку
        window.showToast('Карточка успешно скопирована!', 'success');
    } catch (err) {
        console.error("Ошибка дублирования:", err);
        window.showToast(`Ошибка дублирования: ${err.message}`, 'error');
    }
};

// --- Управление брендированием ---
async function renderBrandingManager() {
    const mainContent = document.getElementById('main-content');
    mainContent.innerHTML = `<h1 class="text-2xl font-bold">Брендирование</h1><p>Этот раздел в разработке.</p>`;
}

// --- Просмотр сообщений поддержки ---
async function renderSupportView() {
    const mainContent = document.getElementById('main-content');
    if (!mainContent) return;

    mainContent.innerHTML = `
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-3xl font-bold">Сообщения поддержки</h1>
        </div>
        <div id="support-list" class="space-y-4">
            <div id="support-loading-state" class="rounded-xl border border-slate-200 bg-white p-8 text-center text-slate-500 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400" role="status" aria-live="polite">
                <i class="fas fa-circle-notch fa-spin mb-3 text-xl text-indigo-500" aria-hidden="true"></i>
                <p>Загружаем обращения из базы…</p>
            </div>
        </div>
    `;

    await fetchAndRenderSupportMessages();
}

async function fetchAndRenderSupportMessages() {
    const supportList = document.getElementById('support-list');
    if (!supportList) return;
    const slowLoadTimer = setTimeout(() => {
        const loadingState = document.getElementById('support-loading-state');
        if (!loadingState) return;
        supportList.innerHTML = '<div id="support-loading-state" class="rounded-xl border border-indigo-200 bg-indigo-50 p-8 text-center text-indigo-700 dark:border-indigo-900/60 dark:bg-indigo-950/30 dark:text-indigo-300" role="status" aria-live="polite"><i class="fas fa-arrows-rotate fa-spin mb-3 text-xl" aria-hidden="true"></i><p>База обновляется — обращения загружаются дольше обычного.</p><button type="button" onclick="fetchAndRenderSupportMessages()" class="mt-4 rounded-lg bg-indigo-600 px-4 py-2 text-white hover:bg-indigo-700">Попробовать снова</button></div>';
    }, 8000);

    try {
        // ЕДИНАЯ МОДЕЛЬ: тикеты — в таблице tickets.
        const { data, error } = await supabaseClient
            .from('tickets')
            .select('*')
            .order('created_at', { ascending: false });

        if (error) throw error;

        if (!data || data.length === 0) {
            supportList.innerHTML = '<div class="rounded-xl border border-dashed border-slate-300 bg-white p-8 text-center text-slate-500 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-400"><i class="fas fa-inbox mb-3 text-2xl" aria-hidden="true"></i><p>Новых обращений пока нет.</p></div>';
            return;
        }

        supportList.innerHTML = data.map(msg => createSupportMessageCard(msg)).join('');

        // Добавляем обработчики событий после рендеринга
        supportList.querySelectorAll('.delete-support-btn').forEach(btn => {
            btn.addEventListener('click', () => window.handleDeleteSupportMessage(btn.dataset.id));
        });

        // Смена статуса обращения (только админ)
        supportList.querySelectorAll('.support-status-btn').forEach(btn => {
            btn.addEventListener('click', () => window.handleSetTicketStatus(btn.dataset.id, btn.dataset.status));
        });

        // Раскрыть/скрыть переписку по тикету
        supportList.querySelectorAll('.admin-chat-toggle').forEach(btn => {
            btn.addEventListener('click', () => window.toggleAdminChat(btn.dataset.id));
        });

        // Отправка ответа администратора
        supportList.querySelectorAll('.admin-chat-form').forEach(form => {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                window.handleSendAdminReply(form.dataset.chatForm);
            });
        });

    } catch (err) {
        console.error("Error fetching support messages:", err);
        supportList.innerHTML = `<div class="p-8 text-center text-red-500 bg-red-100 rounded-xl">Ошибка загрузки: ${err.message}</div>`;
    } finally {
        clearTimeout(slowLoadTimer);
    }
}

function createSupportMessageCard(msg) {
    const created = msg.created_at ? new Date(msg.created_at).toLocaleString('ru-RU') : '';
    const updated = msg.updated_at ? new Date(msg.updated_at).toLocaleString('ru-RU') : created;
    const emailDisplay = msg.email ? `<a href="mailto:${msg.email}" class="text-primary hover:underline min-w-0 truncate block">${msg.email}</a>` : `<span class="text-gray-500">Анонимно</span>`;

    // Статус обращения. Менять его может только администратор (этот экран).
    const status = msg.status || 'open';
    const STATUSES = [
        { key: 'open', label: 'Открыт', color: '#f59e0b' },
        { key: 'reviewed', label: 'Рассмотрено', color: '#6366f1' },
        { key: 'closed', label: 'Закрыт', color: '#10b981' },
    ];
    const cur = STATUSES.find(s => s.key === status) || STATUSES[0];
    const statusButtons = STATUSES.map(s => `
        <button type="button" data-status="${s.key}" data-id="${msg.id}"
            class="support-status-btn px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${s.key === status ? 'text-white shadow' : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'}"
            style="${s.key === status ? 'background:' + s.color : 'background: rgba(148,163,184,0.15)'}">
            ${s.label}
        </button>`).join('');

    return `
        <div id="support-msg-${msg.id}" class="bg-white dark:bg-[#1e293b] shadow-md rounded-xl p-6 transition-all duration-300">
            <div class="flex justify-between items-start">
                <div class="flex-1 min-w-0">
                    <div class="flex items-center gap-4 mb-2 flex-wrap">
                        <span class="font-bold text-slate-800 dark:text-slate-200 min-w-0">${emailDisplay}</span>
                        <span class="text-xs text-slate-500">создан: ${created}</span>
                        <span class="text-xs text-slate-500">активность: ${updated}</span>
                        <span class="text-xs font-bold px-2 py-0.5 rounded-md" style="background:${cur.color}22; color:${cur.color}">${cur.label}</span>
                    </div>
                    <p class="text-slate-700 dark:text-slate-300 whitespace-pre-wrap mb-4">${msg.subject || 'Без темы'}</p>
                    <div class="flex items-center gap-2 flex-wrap">
                        <span class="text-xs text-slate-500 mr-1"><i class="fas fa-tag"></i> Статус:</span>
                        ${statusButtons}
                        <button type="button" data-id="${msg.id}" class="admin-chat-toggle ml-2 px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-sky-400 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors">
                            <i class="fas fa-comments"></i> Переписка
                        </button>
                    </div>

                    <!-- Чат с пользователем -->
                    <div class="admin-chat hidden mt-4 border-t border-slate-200 dark:border-slate-700 pt-4" data-chat-for="${msg.id}">
                        <div class="admin-chat-messages space-y-3 mb-3 max-h-72 overflow-y-auto" data-chat-messages="${msg.id}">
                            <div class="text-center text-slate-400 text-sm py-4">Загрузка переписки…</div>
                        </div>
                        <form class="admin-chat-form flex gap-2 items-end" data-chat-form="${msg.id}">
                            <textarea rows="2" maxlength="2000" placeholder="Ответить пользователю…"
                                class="flex-1 resize-none rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 text-sm px-3 py-2 outline-none focus:border-sky-500"
                                data-chat-input="${msg.id}"></textarea>
                            <button type="submit" class="px-4 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-600 text-white text-sm font-bold transition-colors">
                                <i class="fas fa-paper-plane"></i> Отправить
                            </button>
                        </form>
                    </div>
                </div>
                <button data-id="${msg.id}" class="delete-support-btn ml-4 text-gray-400 hover:text-red-500 transition-colors" title="Удалить сообщение">
                    <i class="fas fa-trash-alt"></i>
                </button>
            </div>
        </div>
    `;
}

window.handleDeleteSupportMessage = async function(messageId) {
    // Выводим стандартное подтверждение, чтобы не удалить случайно
    if (!confirm("Вы уверены, что хотите безвозвратно удалить этот тикет?")) return;

    try {
        // ЕДИНАЯ МОДЕЛЬ: тикет — в таблице tickets.
        const { error } = await supabaseClient.from('tickets').delete().eq('id', messageId);

        if (error) throw error;

        // Удаляем элемент со страницы для мгновенного отклика
        const elementToRemove = document.getElementById(`support-msg-${messageId}`);
        if (elementToRemove) elementToRemove.remove();
        if (window.showToast) window.showToast("Тикет удалён!", "success");

    } catch (err) {
        if (window.showToast) window.showToast("Ошибка удаления: " + err.message, "error");
        else alert("Ошибка удаления: " + err.message);
    }
}

// Смена статуса тикета (только для админ-панели)
window.handleSetTicketStatus = async function (messageId, status) {
    const LABELS = { open: 'Открыт', reviewed: 'Рассмотрено', closed: 'Закрыт' };
    try {
        const { error } = await supabaseClient
            .from('tickets')
            .update({ status: status, updated_at: new Date().toISOString() })
            .eq('id', messageId);

        if (error) throw error;

        if (window.showToast) window.showToast('Статус изменён: ' + (LABELS[status] || status), 'success');
        // Перерисовываем список, чтобы обновить активную кнопку
        await fetchAndRenderSupportMessages();
    } catch (err) {
        console.error('Ошибка смены статуса:', err);
        if (window.showToast) window.showToast('Не удалось изменить статус: ' + err.message, 'error');
        else alert('Не удалось изменить статус: ' + err.message);
    }
};

/* ============================================================
   ПЕРЕПИСКА ПО ТИКЕТУ (админ)
   ============================================================ */

// Открыть/закрыть блок переписки под тикетом.
window.toggleAdminChat = async function (ticketId) {
    const chat = document.querySelector('.admin-chat[data-chat-for="' + ticketId + '"]');
    if (!chat) return;

    const willShow = chat.classList.contains('hidden');
    chat.classList.toggle('hidden');
    if (willShow) await loadAdminChat(ticketId);
};

// Загрузить и отрисовать сообщения переписки.
window.loadAdminChat = async function (ticketId) {
    const box = document.querySelector('[data-chat-messages="' + ticketId + '"]');
    if (!box) return;

    const { data, error } = await supabaseClient
        .from('ticket_messages')
        .select('id, body, is_admin, created_at')
        .eq('ticket_id', ticketId)
        .order('created_at', { ascending: true });

    if (error) {
        box.innerHTML = '<div class="text-center text-red-500 text-sm py-4">Не удалось загрузить: ' + error.message + '</div>';
        return;
    }
    if (!data || data.length === 0) {
        box.innerHTML = '<div class="text-center text-slate-400 text-sm py-4">Переписки пока нет.</div>';
        return;
    }

    box.innerHTML = data.map(m => {
        const time = m.created_at ? new Date(m.created_at).toLocaleString('ru-RU') : '';
        const fromAdmin = !!m.is_admin;
        return '<div class="flex flex-col ' + (fromAdmin ? 'items-end' : 'items-start') + '">' +
            '<div class="max-w-[80%] px-3 py-2 rounded-2xl text-sm whitespace-pre-wrap break-words ' +
                (fromAdmin
                    ? 'bg-sky-500 text-white rounded-br-sm'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 rounded-bl-sm') +
            '">' + escapeHtml(m.body) + '</div>' +
            '<span class="text-[11px] text-slate-400 mt-1">' + (fromAdmin ? 'Вы (админ)' : 'Пользователь') + ' · ' + time + '</span>' +
        '</div>';
    }).join('');
    box.scrollTop = box.scrollHeight;
};

// Отправить ответ администратора.
window.handleSendAdminReply = async function (ticketId) {
    const input = document.querySelector('[data-chat-input="' + ticketId + '"]');
    if (!input) return;
    const body = input.value.trim();
    if (!body) return;

    const btn = document.querySelector('[data-chat-form="' + ticketId + '"] button[type="submit"]');
    if (btn) btn.disabled = true;

    // ЕДИНАЯ МОДЕЛЬ: sender_id и is_admin проставит ТРИГГЕР в БД
    // по реальному uid — здесь угадывать нечего, отказать не может.
    const { error } = await supabaseClient
        .from('ticket_messages')
        .insert([{ ticket_id: String(ticketId), body: body }]);

    if (btn) btn.disabled = false;

    if (error) {
        if (window.showToast) window.showToast('Ошибка отправки: ' + error.message, 'error');
        return;
    }

    input.value = '';
    // После ответа админа тикет переходит в «Рассмотрено», если ещё открыт.
    try {
        await supabaseClient
            .from('tickets')
            .update({ status: 'reviewed', updated_at: new Date().toISOString() })
            .eq('id', ticketId)
            .eq('status', 'open');
    } catch (e) { }

    await loadAdminChat(ticketId);
    if (window.showToast) window.showToast('Ответ отправлен', 'success');
    // Обновляем статусные плашки (может измениться на «Рассмотрено»).
    const statusBtn = document.querySelector('.support-status-btn[data-id="' + ticketId + '"][data-status="reviewed"]');
    if (statusBtn) statusBtn.click();
};

// Простой экранирующий помощник для вывода текста пользователя.
function escapeHtml(str) {
    const p = document.createElement('p');
    p.textContent = str == null ? '' : String(str);
    return p.innerHTML;
}

// --- Экспорт функций в глобальный объект для роутера ---
window.admin = {
    renderContentManager,
    renderBrandingManager,
    renderSupportView,
    renderContentForm, // For new content button
};

// Добавляем стили для новых элементов формы
const styleSheet = document.createElement("style");
styleSheet.type = "text/css";
styleSheet.innerText = `
    .form-input, .form-select { background-color: #1e293b; color: #f8fafc; border: 1px solid #334155; border-radius: 0.375rem; padding: 0.5rem 0.75rem; width: 100%; outline: none; font-size: 0.875rem; transition: border-color 0.2s; }
    .form-input:focus, .form-select:focus { border-color: #6366f1; }
    .animate-fade-out { animation: fadeOut 0.3s ease-out forwards; } @keyframes fadeOut { from { opacity: 1; } to { opacity: 0; } }
    .form-radio { color: #6366f1; background-color: #334155; border-color: #475569; }
`;
document.head.appendChild(styleSheet);

// Запуск при загрузке страницы
// Этот слушатель не нужен, так как router.js уже вызывает navigate() на DOMContentLoaded,
// а navigate() вызывает renderContentManager(), который в свою очередь вызывает loadContent().
// document.addEventListener('DOMContentLoaded', () => { window.loadContent(); });