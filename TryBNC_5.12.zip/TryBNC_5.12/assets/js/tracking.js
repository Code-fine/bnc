﻿let timeTrackerInterval = null;
let localTotalSeconds = 0;
let uiUpdateInterval = null;

// Текущий пользователь и учёт «непроведённых» секунд (буфер с последнего апдейта).
let trackedUserId = null;
let pendingSeconds = 0;
let lastTickAt = 0;
let isFlushing = false;

// Интервал записи в БД. 60с — компромисс между точностью и нагрузкой.
var TRACK_FLUSH_MS = 60000;

window.renderProfileStats = function(totalSeconds, totalDownloads, usePlaceholder) {
    // usePlaceholder=true — данных ещё нет (ни кэша, ни БД): показываем «—»,
    // чтобы пользователь не видел пугающих нулей.
    if (totalSeconds !== undefined) {
        const timeElement = document.getElementById('user-time');
        if (timeElement) {
            if (usePlaceholder && !totalSeconds) {
                timeElement.textContent = '—';
            } else {
                const hours = Math.floor(totalSeconds / 3600);
                const minutes = Math.floor((totalSeconds % 3600) / 60);
                timeElement.textContent = `${hours} ч. ${minutes} мин.`;
            }
        }
    }

    if (totalDownloads !== undefined) {
        const downloadElement = document.getElementById('user-downloads');
        if (downloadElement) {
            downloadElement.textContent = (usePlaceholder && !totalDownloads) ? '—' : String(totalDownloads);
        }
    }
};

/**
 * Надёжно увеличивает время пользователя АТОМАРНО (SQL: increment_seconds).
 * Если функции в БД нет — откатывается на резервный вариант (чтение+upsert),
 * но не чаще, чем реально нужно, чтобы не перезаписывать чужие изменения.
 */
async function flushPendingSeconds() {
    if (!trackedUserId || pendingSeconds <= 0 || isFlushing) return;
    const userId = trackedUserId;
    const delta = pendingSeconds;
    isFlushing = true;
    try {
        // Основной путь: атомарный инкремент в БД (см. supabase/schema.sql).
        const { data, error } = await supabaseClient.rpc('increment_seconds', { p_user_id: userId, p_delta: delta });
        if (!error && typeof data === 'number') {
            pendingSeconds -= delta;
            localTotalSeconds = data;
            renderProfileStats(data);
            try { localStorage.setItem('bnc_last_seconds', String(data)); } catch (e) { }
            return;
        }

        // Резервный путь: чтение текущего значения и upsert (+= delta).
        const { data: row } = await supabaseClient
            .from('profiles')
            .select('total_seconds')
            .eq('id', userId)
            .maybeSingle();
        const newSeconds = ((row && row.total_seconds) || 0) + delta;
        const { error: upErr } = await supabaseClient
            .from('profiles')
            .upsert({ id: userId, total_seconds: newSeconds }, { onConflict: 'id' });
        if (!upErr) {
            pendingSeconds -= delta;
            localTotalSeconds = newSeconds;
            renderProfileStats(newSeconds);
            try { localStorage.setItem('bnc_last_seconds', String(newSeconds)); } catch (e) { }
        }
    } catch (e) {
        // Сеть/сессия не готова — секунды останутся в буфере и уйдут при следующем тике.
    } finally {
        isFlushing = false;
    }
}

// Начисляем секунды только когда вкладка активна — иначе счётчик «лажал»,
// накручивая время за открытые в фоне страницы.
function accrueActiveTime() {
    const now = Date.now();
    if (lastTickAt && document.visibilityState !== 'hidden') {
        const delta = Math.min(Math.round((now - lastTickAt) / 1000), 90);
        if (delta > 0) {
            pendingSeconds += delta;
            localTotalSeconds += delta;
        }
    }
    lastTickAt = now;
}

function startTrackingTime(userId) {
    trackedUserId = userId;
    lastTickAt = Date.now();

    if (timeTrackerInterval) clearInterval(timeTrackerInterval);
    // Раз в секунду копим локально (мгновенный UI), раз в минуту — пишем в БД.
    timeTrackerInterval = setInterval(accrueActiveTime, 1000);

    if (uiUpdateInterval) clearInterval(uiUpdateInterval);
    uiUpdateInterval = setInterval(() => {
        if (document.visibilityState !== 'hidden') renderProfileStats(localTotalSeconds);
    }, 1000);

    if (window.__bncFlushTimer) clearInterval(window.__bncFlushTimer);
    window.__bncFlushTimer = setInterval(flushPendingSeconds, TRACK_FLUSH_MS);
}

function stopTrackingTime() {
    if (timeTrackerInterval) {
        clearInterval(timeTrackerInterval);
        timeTrackerInterval = null;
    }
    if (uiUpdateInterval) {
        clearInterval(uiUpdateInterval);
        uiUpdateInterval = null;
    }
    if (window.__bncFlushTimer) {
        clearInterval(window.__bncFlushTimer);
        window.__bncFlushTimer = null;
    }
    localTotalSeconds = 0;
    pendingSeconds = 0;
    trackedUserId = null;
    lastTickAt = 0;
}

async function initUserTimeTracking(user) {
    if (!user) {
        stopTrackingTime();
        return;
    }
    // Уже считаем время этого пользователя — просто продолжаем,
    // не перезапускаем таймеры и не сбрасываем буфер.
    if (trackedUserId === user.id && timeTrackerInterval) return;

    // 1) Сразу показываем последнее известное значение (чтобы не мелькал 0),
    //    пока идёт запрос к БД. Если кэша ещё нет — ставим плейсхолдер «—»,
    //    а не «0»: пугающие нули вместо реальных данных не показываем.
    const cachedSeconds = parseInt(localStorage.getItem('bnc_last_seconds') || '0', 10);
    const cachedDownloads = parseInt(localStorage.getItem('bnc_last_downloads') || '0', 10);
    renderProfileStats(cachedSeconds, cachedDownloads, true);

    let profile = null;
    let error = null;
    // До 3 попыток — сеть/сессия могут быть ещё не готовы при входе.
    for (let attempt = 0; attempt < 3 && !profile; attempt++) {
        const res = await supabaseClient
            .from('profiles')
            .select('total_seconds, total_downloads, email')
            .eq('id', user.id)
            .maybeSingle();
        error = res.error;
        profile = res.data;
        if (error || profile) break;
        await new Promise(r => setTimeout(r, 400));
    }

    if (error) {
        console.error("Ошибка доступа к профилю:", error);
        if (window.showToast) window.showToast('Не удалось загрузить статистику аккаунта. Проверьте подключение.', 'error');
        return;
    }

    // 2) Если строки профиля нет — создаём её, чтобы время/загрузки копились
    //    с первого же визита, а не оставались нулём.
    if (!profile) {
        const seed = {
            id: user.id,
            email: user.email || null,
            total_seconds: cachedSeconds || 0,
            total_downloads: cachedDownloads || 0
        };
        const { data: created, error: createError } = await supabaseClient
            .from('profiles')
            .upsert(seed, { onConflict: 'id' })
            .select('total_seconds, total_downloads, email')
            .maybeSingle();
        if (createError) {
            console.error("Не удалось создать профиль:", createError);
            if (window.showToast) window.showToast('Не удалось загрузить статистику аккаунта. Попробуйте позже.', 'error');
            return;
        }
        if (created) profile = created;
        else {
            console.error('Не удалось получить данные профиля после создания.');
            if (window.showToast) window.showToast('Не удалось загрузить статистику аккаунта. Попробуйте позже.', 'error');
            return;
        }
    }

    // 3) Итоговые значения: из БД, иначе из кэша.
    const seconds = (profile && profile.total_seconds != null ? profile.total_seconds : (cachedSeconds || 0));
    const downloads = (profile && profile.total_downloads != null ? profile.total_downloads : (cachedDownloads || 0));

    localTotalSeconds = seconds;
    renderProfileStats(seconds, downloads);
    try {
        localStorage.setItem('bnc_last_seconds', String(seconds));
        localStorage.setItem('bnc_last_downloads', String(downloads));
        localStorage.setItem('bnc_tracked_user', user.id);
    } catch (e) { }
    startTrackingTime(user.id);
}

window.initUserTimeTracking = initUserTimeTracking;
window.stopTrackingTime = stopTrackingTime;

// При уходе со страницы/сворачивании не теряем накопленные секунды.
document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') {
        accrueActiveTime();
        flushPendingSeconds();
    } else {
        lastTickAt = Date.now();
    }
});
window.addEventListener('pagehide', () => {
    accrueActiveTime();
    flushPendingSeconds();
});