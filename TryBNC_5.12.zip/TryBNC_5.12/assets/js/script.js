const bookGrid = document.getElementById('bookGrid');
const utilsGrid = document.getElementById('utilsGrid');
const searchInput = document.getElementById('searchInput'); // Может быть null на utils.html

let books = []; // Теперь это пустой массив, который заполнится из БД
// Ставим true сразу: до завершения загрузки контента сетка не должна
// показывать «ничего не найдено» или пустоту (иначе мелькает заглушка).
let isLoading = true;
let contentLoadError = null;
let siteInitializationFinished = false;
let currentCategory = 'all';

// Переменные для динамического SEO (Open Graph)
const ogTitleTag = document.querySelector('meta[property="og:title"]');
const defaultOgTitle = ogTitleTag ? ogTitleTag.getAttribute('content') : document.title;

/**
 * Функция для безопасной вставки текста (защита от XSS)
 */
function escapeHTML(str) {
    if (!str) return '';
    const p = document.createElement('p');
    p.textContent = str;
    return p.innerHTML;
}

function normalizeContentRecords(records) {
    return records.map(record => {
        let files = record.files_list;
        if (typeof files === 'string') {
            try {
                files = JSON.parse(files);
            } catch (error) {
                console.warn('Invalid content file list:', error);
                files = [];
            }
        }
        if (!Array.isArray(files) || files.length === 0) {
            files = record.files;
        }
        if (typeof files === 'string') {
            try {
                files = JSON.parse(files);
            } catch (error) {
                console.warn('Invalid legacy content file list:', error);
                files = [];
            }
        }
        return {
            ...record,
            files: Array.isArray(files)
                ? files.map(file => file && typeof file === 'object'
                    ? { ...file, url: file.url || file.file_url || '' }
                    : file)
                : []
        };
    });
}

/* Мгновенное появление карточек с анимацией — данные показываются сразу
   вместе с анимацией, без промежуточной «загрузки». */
function animateCardsIn() {
    const grid = bookGrid || utilsGrid;
    if (!grid) return;
    const cards = grid.querySelectorAll('.book-card, .util-card');
    if (!cards.length) return;

    if (typeof gsap !== 'undefined') {
        gsap.fromTo(cards,
            { opacity: 0, y: 40, scale: 0.95 },
            {
                opacity: 1, y: 0, scale: 1,
                duration: 0.6,
                ease: 'power3.out',
                stagger: { each: 0.08, from: 'start' },
                clearProps: 'transform,opacity',
                onComplete: () => {
                    if (typeof ScrollTrigger !== 'undefined') ScrollTrigger.refresh();
                }
            }
        );
    } else {
        // Без GSAP — просто показываем (базовая CSS-анимация появления)
        cards.forEach(c => { c.style.opacity = '1'; });
    }
}

function renderSkeletons() {
    const container = bookGrid || utilsGrid;
    if (!container) return;
    const isListView = container.classList.contains('list-view');
    const count = 6;

    let skeletonHtml = '';
    for (let i = 0; i < count; i++) {
        if (isListView) {
            skeletonHtml += `
                <div class="book-card skeleton-card" style="flex-direction: row; min-height: 120px; padding: 10px 20px; gap: 20px; align-items: stretch;">
                    <div class="skeleton" style="width: 120px; min-width: 120px; height: 100px; border-radius: 8px;"></div>
                    <div style="flex: 1; display: flex; flex-direction: column; justify-content: center; gap: 10px;">
                        <div class="skeleton" style="height: 20px; width: 40%;"></div>
                        <div class="skeleton" style="height: 14px; width: 30%;"></div>
                    </div>
                    <div style="display: flex; align-items: center;">
                        <div class="skeleton" style="height: 38px; width: 100px; border-radius: 20px;"></div>
                    </div>
                </div>`;
        } else {
            skeletonHtml += `
                <div class="skeleton-card">
                    <div class="skeleton" style="height: 160px; width: 100%; border-radius: 0;"></div>
                    <div style="padding: 20px; flex: 1; display: flex; flex-direction: column; gap: 12px;">
                        <div class="skeleton" style="height: 22px; width: 85%;"></div>
                        <div class="skeleton" style="height: 16px; width: 60%;"></div>
                        <div class="skeleton" style="height: 40px; width: 100%; margin-top: auto; border-radius: 20px;"></div>
                    </div>
                </div>`;
        }
    }
    container.innerHTML = skeletonHtml;
}

async function initBranding() {
    if (typeof supabaseClient === 'undefined') return;

    const { data, error } = await supabaseClient
        .from('branding_ads')
        .select('*')
        .single();

    if (!error && data && data.is_active) {
        document.body.classList.add('branding-active');

        // Логика для ПК
        document.body.style.backgroundImage = `url(${data.image_url})`;
        const brandLinks = ['brand-left-link', 'brand-right-link', 'brand-top-link'];
        brandLinks.forEach(id => {
            const el = document.getElementById(id);
            if (el) el.href = data.link_url;
        });

        // Логика для мобильных
        const mobileImg = document.getElementById('brand-mobile-img');
        const mobileLink = document.getElementById('brand-mobile-link');
        if (mobileImg) mobileImg.src = data.mobile_image_url || '';
        if (mobileLink) mobileLink.href = data.link_url;
    } else {
        const wrapper = document.getElementById('branding-wrapper');
        if (wrapper) wrapper.style.display = 'none';
    }
}

async function fetchContent() {
    if (typeof supabaseClient === 'undefined') {
        console.warn('Supabase not loaded, skipping content fetch');
        isLoading = false;
        contentLoadError = new Error('Не удалось подключиться к базе данных.');
        if (siteInitializationFinished) renderCurrentCatalog();
        return;
    }
    isLoading = true;
    contentLoadError = null;

    // Если мы в админке, очищаем кэш, чтобы всегда видеть свежие данные, включая черновики.
    // Это решает проблему, когда после админки на сайте показывались старые кэшированные данные.
    if (window.location.pathname.includes('admin.html')) {
        sessionStorage.removeItem('bnc_content_cache');
        console.log('Admin panel detected, cache cleared.');
    }

    // 1) СНАЧАЛА пробуем кэш. Если данные есть — показываем их мгновенно,
    //    без «подгрузки» и мелькания скелетонов.
    const cached = sessionStorage.getItem('bnc_content_cache');
    try {
        if (cached) {
            const parsed = JSON.parse(cached);
            if (Array.isArray(parsed) && parsed.length > 0) {
                books = normalizeContentRecords(parsed);
                isLoading = false;
                console.log("Данные загружены из кэша");
                return;
            }
        }
    } catch (e) {
        console.error("Ошибка парсинга кэша:", e);
        sessionStorage.removeItem('bnc_content_cache');
    }

    // 2) Кэша нет — показываем скелетоны только при действительно
    //    длинном запросе (>1.2с). Быстрая загрузка проходит без мигания
    //    «подгрузкой»: карточки сразу появляются с анимацией.
    const skeletonTimer = setTimeout(() => {
        if (isLoading) renderSkeletons();
    }, 1200);
    const slowLoadTimer = setTimeout(() => {
        if (isLoading) renderCatalogState(
            'fa-arrows-rotate',
            'База обновляется',
            'Загрузка каталога занимает больше времени. Можно подождать или попробовать ещё раз.',
            true
        );
    }, 8000);

    try {
        let query = supabaseClient
            .from('content')
            .select('*');

        // Если мы не в админке, запрашиваем только опубликованные записи
        if (!window.location.pathname.includes('admin.html')) {
            query = query.eq('status', 'published');
        }

        const { data, error } = await query.order('created_at', { ascending: false });
        if (error) throw error;

        books = Array.isArray(data) ? normalizeContentRecords(data) : [];

        // Сохраняем в кэш
        sessionStorage.setItem('bnc_content_cache', JSON.stringify(books));
        console.log("Данные загружены из Supabase и кэшированы");
    } catch (error) {
        contentLoadError = error;
        console.error('Error fetching content:', error);
        if (window.showToast) {
            const errMsg = window.translations?.[window.currentLang]?.err_network || "Network error";
            window.showToast(errMsg, 'error');
        }
    } finally {
        clearTimeout(skeletonTimer);
        clearTimeout(slowLoadTimer);
        isLoading = false;
        if (siteInitializationFinished) renderCurrentCatalog();
    }
}

function renderCurrentCatalog() {
    const path = window.location.pathname;
    if (path.includes('minecraft.html')) currentCategory = 'minecraft';
    else if (path.includes('utils.html')) currentCategory = 'utils';

    if (bookGrid) renderBooks(searchInput ? searchInput.value : '');
    if (utilsGrid) renderUtils(searchInput ? searchInput.value : '');
    if (searchInput && searchInput.value.trim()) updateSearchDropdown(searchInput.value);
    animateCardsIn();
}

function renderCatalogState(icon, title, message, retry) {
    const container = bookGrid || utilsGrid;
    if (!container) return;
    container.innerHTML = `
        <div class="bnc-data-state" role="status" aria-live="polite">
            <span class="bnc-data-state-icon"><i class="fas ${icon}" aria-hidden="true"></i></span>
            <strong>${escapeHTML(title)}</strong>
            <span>${escapeHTML(message)}</span>
            ${retry ? '<button type="button" class="bnc-state-retry" onclick="window.retryContentLoad()">Попробовать снова</button>' : ''}
        </div>
    `;
}

window.retryContentLoad = async function () {
    await fetchContent();
}

function renderBooks(filterText = '') {
    if (!bookGrid) return;

    const fragment = document.createDocumentFragment();
    const q = filterText.trim().toLowerCase();
    const filteredBooks = books.filter(book => {
        const matchesSearch = !q ||
            l(book.title).toLowerCase().includes(q) ||
            l(book.author).toLowerCase().includes(q) ||
            (book.description && l(book.description).toLowerCase().includes(q)) ||
            (Array.isArray(book.files) && book.files.some(f => l(f.name).toLowerCase().includes(q)));

        let matchesCategory = false;
        if (currentCategory === 'all' || currentCategory === 'minecraft') {
            matchesCategory = book.type !== 'utils';
        } else {
            matchesCategory = book.type === currentCategory;
        }

        return matchesSearch && matchesCategory;
    });

    const t = window.translations[window.currentLang];

    if (filteredBooks.length === 0) {
        // Пока данные ещё грузятся — НЕ показываем «ничего не найдено»,
        // иначе заголовок мелькает и пропадает. Пустое состояние только
        // после завершения загрузки и при реально пустом результате.
        if (isLoading) return;
        if (contentLoadError) {
            renderCatalogState(
                'fa-triangle-exclamation',
                'Не удалось загрузить каталог',
                'Проверьте подключение и попробуйте загрузить данные ещё раз.',
                true
            );
            return;
        }
        if (!books.length && !filterText.trim()) {
            renderCatalogState(
                'fa-box-open',
                'Каталог пока пуст',
                'База обновляется — новые материалы появятся здесь.'
            );
            return;
        }
        bookGrid.innerHTML = `<div class="no-results"><i class="fas fa-magnifying-glass" aria-hidden="true"></i><span>${t.nothing_found}</span></div>`;
        return;
    }

    filteredBooks.forEach(book => {
        const card = document.createElement('div');
        card.className = 'book-card';

        const title = l(book.title);
        const author = l(book.author);

        // Проверяем, есть ли картинка
        let coverHtml;
        if (book.image) {
            coverHtml = `<img src="${escapeHTML(book.image)}" alt="${escapeHTML(title)}" class="book-cover-img" loading="lazy" onerror="this.src='assets/images/icon/icon1.png'">`;
        } else {
            const initial = title.charAt(0);
            coverHtml = `<div class="book-cover" style="background-color: ${book.color};">${initial}</div>`;
        }

        const bookIndex = books.indexOf(book);

        card.innerHTML = `
            ${coverHtml}
            <div class="book-info">
                <div class="book-text-content">
                    <div class="book-title">${escapeHTML(title)}</div>
                    <div class="book-author">${escapeHTML(author)}</div>
                </div>
                <button class="book-open-btn" onclick="window.openViewModal('${book.id}')">${t.open}</button>
            </div>
        `;
        fragment.appendChild(card);
    });

    bookGrid.innerHTML = '';
    bookGrid.appendChild(fragment);
    // Обновляем ScrollTrigger, так как высота страницы изменилась после рендеринга
    if (typeof ScrollTrigger !== 'undefined') {
        // Используем debounce для рефреша, чтобы не тормозить UI
        requestAnimationFrame(() => ScrollTrigger.refresh());
    }
}

function openDownloadAuth(mode) {
    const modal = document.getElementById('authModal');
    const loginButton = document.getElementById('headerLoginBtn');
    const loginBox = document.getElementById('login-box');
    const registerBox = document.getElementById('register-box');

    if (!modal) {
        try {
            localStorage.setItem('openAuthModal', 'true');
            localStorage.setItem('openAuthMode', mode);
        } catch (error) {
            console.error('Unable to save the requested authentication view:', error);
        }
        if (loginButton) loginButton.click();
        else window.location.href = 'index.html';
        return;
    }

    if (loginButton) loginButton.click();
    else {
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
        document.body.classList.add('modal-open');
        if (window.lenis) window.lenis.stop();
    }

    if (loginBox && registerBox) {
        loginBox.style.display = mode === 'register' ? 'none' : 'block';
        registerBox.style.display = mode === 'register' ? 'block' : 'none';
    }
}

function openGuestDownloadModal() {
    return new Promise(resolve => {
        const modal = document.createElement('div');
        modal.className = 'bnc-download-modal';
        modal.id = 'bncDownloadModal';
        modal.innerHTML = `
            <section class="bnc-download-dialog" role="dialog" aria-modal="true" aria-labelledby="bncDownloadTitle" aria-describedby="bncDownloadDescription">
                <button class="bnc-download-close" type="button" aria-label="Закрыть окно"><i class="fas fa-xmark" aria-hidden="true"></i></button>
                <div class="bnc-download-icon"><i class="fas fa-cloud-arrow-down" aria-hidden="true"></i></div>
                <p class="bnc-download-eyebrow">Подготовка файла</p>
                <h2 id="bncDownloadTitle">Загрузка начнётся через</h2>
                <div class="bnc-download-timer" aria-live="polite">60 <span>сек</span></div>
                <p class="bnc-download-description" id="bncDownloadDescription">Пожалуйста, подождите, пока завершится обратный отсчёт.</p>
                <button class="bnc-download-confirm" type="button" hidden>Скачать файл</button>
                <div class="bnc-download-account">
                    <strong>Хотите скачивать без ожидания?</strong>
                    <p>Зарегистрируйтесь или войдите в аккаунт — в следующий раз файлы будут доступны сразу.</p>
                    <div class="bnc-download-account-actions">
                        <button type="button" data-download-auth="register">Зарегистрироваться</button>
                        <button type="button" data-download-auth="login">Войти в аккаунт</button>
                    </div>
                </div>
            </section>
        `;

        const trigger = document.activeElement;
        const timer = modal.querySelector('.bnc-download-timer');
        const description = modal.querySelector('.bnc-download-description');
        const confirmButton = modal.querySelector('.bnc-download-confirm');
        const countdownEndsAt = Date.now() + 60000;
        let secondsLeft = 60;
        let intervalId = null;
        let settled = false;

        function finish(confirmed, keepPageLocked, downloadWindow = null) {
            if (settled) return;
            settled = true;
            if (intervalId) clearInterval(intervalId);
            modal.remove();
            if (!keepPageLocked && !document.querySelector('.modal.show:not(.is-closing)')) {
                document.body.style.overflow = '';
                document.body.classList.remove('modal-open');
                if (window.lenis) window.lenis.start();
            }
            if (trigger && typeof trigger.focus === 'function' && trigger.isConnected) trigger.focus();
            document.removeEventListener('keydown', handleKeydown);
            resolve({ confirmed, downloadWindow });
        }

        function handleKeydown(event) {
            if (event.key === 'Escape') finish(false, false);
        }

        modal.querySelector('.bnc-download-close').addEventListener('click', () => finish(false, false));
        modal.addEventListener('click', event => {
            if (event.target === modal) finish(false, false);
        });
        modal.querySelectorAll('[data-download-auth]').forEach(button => {
            button.addEventListener('click', () => {
                const mode = button.dataset.downloadAuth;
                finish(false, true);
                openDownloadAuth(mode);
            });
        });
        confirmButton.addEventListener('click', () => {
            const downloadWindow = window.open('about:blank', '_blank');
            if (downloadWindow) downloadWindow.opener = null;
            finish(Boolean(downloadWindow), false, downloadWindow);
            if (!downloadWindow) {
                window.showToast('Разрешите всплывающие окна, чтобы скачать файл.', 'error');
                return;
            }
        });
        document.addEventListener('keydown', handleKeydown);

        document.body.appendChild(modal);
        modal.querySelector('.bnc-download-close').focus();
        document.body.style.overflow = 'hidden';
        document.body.classList.add('modal-open');
        if (window.lenis) window.lenis.stop();
        requestAnimationFrame(() => modal.classList.add('is-open'));

        intervalId = setInterval(() => {
            secondsLeft = Math.max(0, Math.ceil((countdownEndsAt - Date.now()) / 1000));
            timer.innerHTML = `${secondsLeft} <span>сек</span>`;

            if (secondsLeft === 0) {
                clearInterval(intervalId);
                intervalId = null;
                modal.querySelector('#bncDownloadTitle').textContent = 'Файл готов к загрузке';
                description.textContent = 'Нажмите кнопку ниже, чтобы начать скачивание.';
                confirmButton.hidden = false;
                confirmButton.focus();
            }
        }, 1000);
    });
}

window.handleDownloadClick = async function (url, e, meta) {
    if (e) e.preventDefault();

    const trigger = e?.target?.closest('button, a') || e?.currentTarget || null;
    if (meta?.external) {
        window.open(url, '_blank', 'noopener,noreferrer');
        return;
    }
    const isStoragePath = typeof url === 'string'
        && /^content\/[A-Za-z0-9][A-Za-z0-9._/-]{0,499}$/.test(url)
        && !url.includes('..') && !url.includes('//');
    let isLegacyUrl = false;
    if (typeof url === 'string' && url.length <= 2048) {
        try {
            const legacyUrl = new URL(url);
            isLegacyUrl = ['http:', 'https:'].includes(legacyUrl.protocol)
                && !legacyUrl.username && !legacyUrl.password;
        } catch (error) {
            isLegacyUrl = false;
        }
    }
    if (!isStoragePath && !isLegacyUrl) {
        window.showToast('Ссылка на файл некорректна. Обратитесь к администратору сайта.', 'error');
        return;
    }

    const isGuest = !window.currentUser;
    const originalContent = trigger ? trigger.innerHTML : '';
    const originalPointerEvents = trigger ? trigger.style.pointerEvents : '';
    const wasDisabled = trigger && 'disabled' in trigger ? trigger.disabled : false;
    let downloadWindow = null;

    if (trigger && trigger.dataset.downloadCountdown === 'active') return;
    if (isGuest && document.getElementById('bncDownloadModal')) return;

    if (trigger) {
        trigger.dataset.downloadCountdown = 'active';
        trigger.style.pointerEvents = 'none';
        if ('disabled' in trigger) trigger.disabled = true;
    }

    if (isGuest) {
        const confirmation = await openGuestDownloadModal();
        if (!confirmation.confirmed) {
            if (trigger) {
                trigger.innerHTML = originalContent;
                trigger.style.pointerEvents = originalPointerEvents;
                if ('disabled' in trigger) trigger.disabled = wasDisabled;
                delete trigger.dataset.downloadCountdown;
            }
            return;
        }
        downloadWindow = confirmation.downloadWindow;
    } else {
        downloadWindow = window.open('about:blank', '_blank');
        if (downloadWindow) downloadWindow.opener = null;
        if (!downloadWindow) {
            window.showToast('Разрешите всплывающие окна, чтобы скачать файл.', 'error');
            if (trigger) {
                trigger.style.pointerEvents = originalPointerEvents;
                if ('disabled' in trigger) trigger.disabled = wasDisabled;
                delete trigger.dataset.downloadCountdown;
            }
            return;
        }
    }

    try {
        const downloadUrl = isStoragePath
            ? supabaseClient.storage.from('content-files').getPublicUrl(url, { download: true }).data.publicUrl
            : url;
        downloadWindow.location.replace(downloadUrl);
    } catch (error) {
        if (downloadWindow && !downloadWindow.closed) downloadWindow.close();
        console.error('Download preparation failed:', error);
        window.showToast(error.message || 'Не удалось скачать файл. Попробуйте ещё раз.', 'error');
        if (trigger) {
            trigger.style.pointerEvents = originalPointerEvents;
            if ('disabled' in trigger) trigger.disabled = wasDisabled;
            delete trigger.dataset.downloadCountdown;
        }
        return;
    }

    if (trigger) {
        trigger.style.pointerEvents = originalPointerEvents;
        if ('disabled' in trigger) trigger.disabled = wasDisabled;
        delete trigger.dataset.downloadCountdown;
        trigger.classList.add('download-success');
        setTimeout(() => trigger.classList.remove('download-success'), 2000);
    }

    // 2. Пишем запись в локальную историю загрузок (для личного кабинета)
    if (window.bncHistory && typeof window.bncHistory.add === 'function') {
        window.bncHistory.add({
            url: url,
            title: (meta && meta.title) || (e && e.target && e.target.dataset && e.target.dataset.title) || 'Файл',
            image: (meta && meta.image) || '',
            source: (meta && meta.source) || document.title
        });
    }

    // 3. Если пользователь авторизован, увеличиваем его личный счётчик загрузок.
    if (window.currentUser) {
        if (typeof supabaseClient !== 'undefined') {
            // Атомарный инкремент в БД (см. supabase/schema.sql).
            const { data: newCount, error } = await supabaseClient.rpc('increment_downloads');

            if (!error && typeof newCount === 'number') {
                if (typeof renderProfileStats === 'function') renderProfileStats(undefined, newCount);
                // Кэшируем, чтобы кабинет не показывал ложный 0 при перезагрузке
                try { localStorage.setItem('bnc_last_downloads', String(newCount)); } catch (err) { }
            } else {
                // Функции нет или вернула не число — считаем через чтение+upsert.
                let next = parseInt(localStorage.getItem('bnc_last_downloads') || '0', 10) + 1;
                try {
                    const { data: row } = await supabaseClient
                        .from('profiles')
                        .select('total_downloads')
                        .eq('id', window.currentUser.id)
                        .maybeSingle();
                    next = ((row && row.total_downloads) || 0) + 1;
                    const { error: upErr } = await supabaseClient
                        .from('profiles')
                        .upsert({ id: window.currentUser.id, total_downloads: next }, { onConflict: 'id' });
                    if (upErr) console.warn('Не удалось сохранить счётчик загрузок:', upErr.message);
                } catch (err) {
                    console.warn('Не удалось сохранить счётчик загрузок:', err);
                }
                try { localStorage.setItem('bnc_last_downloads', String(next)); } catch (err) { }
                if (typeof renderProfileStats === 'function') renderProfileStats(undefined, next);
            }
        }
    }
};

// Логика поиска в хедере
const clearSearchBtn = document.getElementById('clearSearch');

// Дебаунс для оптимизации поиска (уменьшает количество перерисовок)
function debounce(func, wait) {
    let timeout;
    return function (...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
    };
}

const performSearch = (val) => {
    if (typeof renderBooks === 'function' && document.getElementById('bookGrid')) {
        renderBooks(val);
    }
    if (typeof renderUtils === 'function' && document.getElementById('utilsGrid')) {
        renderUtils(val);
    }
    updateSearchDropdown(val);
};

const debouncedSearch = debounce(performSearch, 300);

if (searchInput) {
    const handleInput = (e) => {
        const val = e.target.value.trim();
        if (clearSearchBtn) clearSearchBtn.style.display = val ? 'flex' : 'none';
        debouncedSearch(val);
    };

    searchInput.addEventListener('input', handleInput);
    searchInput.addEventListener('focus', (e) => {
        updateSearchDropdown(e.target.value);
    });

    // Навигация по результатам поиска с клавиатуры
    searchInput.addEventListener('keydown', (e) => {
        const dropdown = document.getElementById('searchDropdown');
        if (!dropdown || dropdown.style.display === 'none') return;

        const items = dropdown.querySelectorAll('.search-result-item');
        if (items.length === 0) return;

        let activeIndex = Array.from(items).findIndex(item => item.classList.contains('active-kb'));

        if (e.key === 'ArrowDown') {
            e.preventDefault();
            if (activeIndex !== -1) items[activeIndex].classList.remove('active-kb');
            activeIndex = (activeIndex + 1) % items.length;
            items[activeIndex].classList.add('active-kb');
            items[activeIndex].scrollIntoView({ block: 'nearest' });
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            if (activeIndex !== -1) items[activeIndex].classList.remove('active-kb');
            activeIndex = (activeIndex + -1 + items.length) % items.length;
            items[activeIndex].classList.add('active-kb');
            items[activeIndex].scrollIntoView({ block: 'nearest' });
        } else if (e.key === 'Enter' && activeIndex !== -1) {
            items[activeIndex].click();
        }
    });

    if (clearSearchBtn) {
        clearSearchBtn.addEventListener('click', () => {
            searchInput.value = '';
            renderBooks?.('');
            renderUtils?.('');
            clearSearchBtn.style.display = 'none';
            const dropdown = document.getElementById('searchDropdown');
            if (dropdown) dropdown.style.display = 'none';
            searchInput.focus();
        });
    }
}

// Закрытие дропдауна поиска при клике вне
document.addEventListener('click', (e) => {
    const dropdown = document.getElementById('searchDropdown');
    const searchContainer = document.querySelector('.header-search');
    if (dropdown && searchContainer && !searchContainer.contains(e.target)) {
        dropdown.style.display = 'none';
    }
});

function highlightText(text, query) {
    if (!query.trim()) return escapeHTML(text);
    const escapedText = escapeHTML(text);
    const escapedQuery = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`(${escapedQuery})`, 'gi');
    // Работаем с уже экранированным текстом
    return escapedText.replace(regex, '<mark class="search-highlight">$1</mark>');
}

function updateSearchDropdown(val) {
    const dropdown = document.getElementById('searchDropdown');
    if (!dropdown) return;
    if (!val.trim()) {
        dropdown.style.display = 'none';
        return;
    }
    const t = window.translations[window.currentLang];

    const results = [];
    const query = val.toLowerCase();

    books.forEach((book, bookIndex) => {
        const bookTitle = escapeHTML(l(book.title));
        const bookAuthor = escapeHTML(l(book.author));

        // 1. Проверяем категории (заголовки групп)
        if (bookTitle.toLowerCase().includes(query) || bookAuthor.toLowerCase().includes(query)) {
            let catImg = book.image || 'assets/images/icon/icon1.png';
            // Если это категория утилит и там стоит логотип сайта - заменяем на нейтральную иконку папки
            if (book.type === 'utils' && catImg.includes('icon1.png')) {
                catImg = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9IiM2MzY2ZjEiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj48cGF0aCBkPSJNMjIgMTlYOWEyIDIgMCAwIDAtMi0yaC02LjE3bC0yLTEuMjYtMi0xLjI0SDRhMiAyIDAgMCAwLTIgMnYxMGEyIDIgMCAwIDAgMiAyaDE2YTIgMiAwIDAgMCAyLTJ6Ii8+PC9zdmc+';
            }

            results.push({
                type: 'category',
                index: bookIndex,
                title: bookTitle,
                subtitle: bookAuthor,
                image: catImg
            });
        }

        // 2. Проверяем отдельные программы внутри категорий
        if (book.files) {
            book.files.forEach((file) => {
                const fileName = escapeHTML(l(file.name));
                if (fileName.toLowerCase().includes(query)) {
                    // Автоматический подбор иконки программы (резолвер + ручная иконка из БД)
                    const iconSrc = (window.BNCIcons && window.BNCIcons.resolveProgramIcon)
                        ? window.BNCIcons.resolveProgramIcon(file)
                        : (file.icon || 'assets/images/icon/icon1.png');

                    results.push({
                        type: 'file',
                        title: fileName,
                        subtitle: bookTitle,
                        image: iconSrc,
                        url: file.url
                    });
                }
            });
        }
    });

    const finalResults = results.slice(0, 8); // Лимит результатов в поиске

    if (finalResults.length === 0) {
        if (contentLoadError) {
            dropdown.innerHTML = `<div class="search-empty-state" role="status"><span class="search-empty-icon"><i class="fas fa-triangle-exclamation" aria-hidden="true"></i></span><span class="search-empty-title">Не удалось загрузить каталог</span><span class="search-empty-hint">Проверьте подключение и попробуйте ещё раз</span><button type="button" class="bnc-state-retry" onclick="window.retryContentLoad()">Повторить</button></div>`;
            dropdown.style.display = 'block';
            return;
        }
        if (isLoading) {
            dropdown.innerHTML = `<div class="search-empty-state" role="status"><span class="search-empty-icon"><i class="fas fa-arrows-rotate fa-spin" aria-hidden="true"></i></span><span class="search-empty-title">База обновляется</span><span class="search-empty-hint">Подождите, каталог загружается</span></div>`;
            dropdown.style.display = 'block';
            return;
        }
        dropdown.innerHTML = `<div style="padding: 15px; text-align: center; color: #94a3b8; font-size: 0.9rem;">${t.nothing_found}</div>`;
    } else {
        dropdown.innerHTML = finalResults.map(res => {
            const showSubtitle = res.subtitle.toLowerCase() !== 'ninite';
            const clickAction = res.type === 'category' ? `handleSearchDropdownClick(${res.index})` : `window.open('${res.url}', '_blank')`;
            return `
                <div class="search-result-item" onclick="${clickAction}">
                    <img src="${res.image}" style="width: 36px; height: 36px; border-radius: 4px; object-fit: cover;" onerror="this.src='data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9IiM5NGEzYjgiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj48cmVjdCB4PSIyIiB5PSIyIiB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHJ4PSI1Ii8+PHBhdGggZD0iTTEyIDh2OG0tNC00aDgiLz48L3N2Zz4='">
                    <div style="flex: 1; overflow: hidden;">
                        <div style="font-weight: 700; font-size: 0.9rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${highlightText(res.title, val)}</div>
                        ${showSubtitle ? `<div style="font-size: 0.75rem; color: #94a3b8; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${highlightText(res.subtitle, val)}</div>` : ''}
                    </div>
                </div>
            `;
        }).join('');
    }
    dropdown.style.display = 'block';
}

window.handleSearchDropdownClick = function (index) {
    const dropdown = document.getElementById('searchDropdown');
    if (dropdown) dropdown.style.display = 'none';
    document.getElementById('searchInput')?.blur(); // Скрываем клавиатуру при переходе к результату
    const book = books[index];
    if (book.type === 'utils') {
        window.location.href = 'utils.html';
    } else if (window.location.pathname.includes('minecraft.html')) {
        openBookModal(index);
    } else {
        localStorage.setItem('autoOpenBook', index);
        window.location.href = 'minecraft.html';
    }
};

// Логика категорий
document.querySelectorAll('.category-btn').forEach(btn => {
    if (btn.tagName === 'BUTTON') { // Игнорируем ссылки (<a>)
        btn.addEventListener('click', () => {
            document.querySelectorAll('.category-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            currentCategory = btn.dataset.filter;
            renderBooks(searchInput ? searchInput.value : '');
        });
    }
});

// Логика подкатегорий (в выпадающем меню фильтров)
document.querySelectorAll('.filter-item').forEach(item => {
    item.addEventListener('click', (e) => {
        e.preventDefault();
        // Сбрасываем активный класс у основных кнопок
        document.querySelectorAll('.category-btn').forEach(b => b.classList.remove('active'));
        // Добавляем активный класс кнопке Minecraft (так как это подкатегория)
        document.getElementById('btn-minecraft').classList.add('active');

        currentCategory = item.dataset.filter;
        renderBooks(searchInput ? searchInput.value : '');
    });
});

// Логика выпадающего меню (Категории)
document.querySelectorAll('.menu-item').forEach(item => {
    item.addEventListener('click', (e) => {
        e.preventDefault(); // Предотвращаем переход по ссылке

        // Убираем активный класс у всех пунктов и добавляем нажатому
        document.querySelectorAll('.menu-item').forEach(i => i.classList.remove('active'));
        item.classList.add('active');

        // Фильтруем книги
        currentCategory = item.dataset.filter;
        renderBooks(searchInput ? searchInput.value : '');

        // Закрываем меню на мобильных устройствах (если это не родительский пункт с подменю)
        if (window.innerWidth <= 768) {
            const hasSubmenu = item.nextElementSibling && item.nextElementSibling.classList.contains('nested-dropdown-content');
            if (!hasSubmenu) {
                const dropdown = document.querySelector('.dropdown');
                if (dropdown) dropdown.classList.remove('open');
            }
        }
    });
});

// Первоначальная отрисовка
if (bookGrid) {
    if (searchInput) searchInput.value = '';
    // Если мы на странице Minecraft, устанавливаем фильтр по умолчанию на всё игровое
    if (window.location.pathname.includes('minecraft.html')) {
        currentCategory = 'minecraft';
    }
    renderBooks();

    // Эффект свечения при движении мыши над карточками
    bookGrid.addEventListener('mousemove', (e) => {
        const card = e.target.closest('.book-card');
        if (!card) return;

        const rect = card.getBoundingClientRect();
        const x = ((e.clientX - rect.left) / rect.width) * 100;
        const y = ((e.clientY - rect.top) / rect.height) * 100;

        card.style.setProperty('--mouse-x', `${x}%`);
        card.style.setProperty('--mouse-y', `${y}%`);
    });
}

// Логика переключения вида (Сетка / Список)
const gridViewBtn = document.getElementById('gridViewBtn');
const listViewBtn = document.getElementById('listViewBtn');

function setView(view, animate = true) {
    if (!bookGrid || !gridViewBtn || !listViewBtn) return;
    const execute = () => {
        if (view === 'list') {
            bookGrid.classList.add('list-view');
            listViewBtn.classList.add('active');
            gridViewBtn.classList.remove('active');
        } else {
            bookGrid.classList.remove('list-view');
            gridViewBtn.classList.add('active');
            listViewBtn.classList.remove('active');
        }
        localStorage.setItem('viewMode', view);
    };

    if (animate) {
        bookGrid.classList.add('switching');
        setTimeout(() => {
            execute();
            bookGrid.classList.remove('switching');
        }, 300);
    } else {
        execute();
    }
}

// Проверка авто-открытия книги после перехода
const autoOpenIndex = localStorage.getItem('autoOpenBook');
if (autoOpenIndex !== null && document.getElementById('bookGrid')) {
    localStorage.removeItem('autoOpenBook');
    setTimeout(() => openBookModal(parseInt(autoOpenIndex)), 100);
}
if (gridViewBtn && listViewBtn) {
    gridViewBtn.addEventListener('click', () => setView('grid'));
    listViewBtn.addEventListener('click', () => setView('list'));
}

if (localStorage.getItem('viewMode') === 'list') {
    setView('list', false);
}

// Переход на главную при клике на логотип или заголовок
const logoLink = document.querySelector('header h1');
if (logoLink) {
    logoLink.style.cursor = 'pointer';
    logoLink.addEventListener('click', (e) => {
        if (window.location.pathname.endsWith('index.html') || window.location.pathname === '/') {
            e.preventDefault();
            if (searchInput) searchInput.value = '';
            currentCategory = 'all';
            document.querySelectorAll('.category-btn').forEach(b => b.classList.remove('active'));
            if (bookGrid) renderBooks('');
            if (window.lenis) window.lenis.scrollTo(0);
            else window.scrollTo({ top: 0, behavior: 'smooth' });
        } else {
            window.location.href = 'index.html';
        }
    });
}

// Логика модального окна
const modal = document.getElementById('bookModal');
const modalContent = document.getElementById('modalBookInfo');
const closeModalSpan = document.querySelector('.close-modal');
const supportModal = document.getElementById('supportModal');
const MODAL_CLOSE_DURATION = 460;
const modalCloseTimers = new WeakMap();
let currentBookIndex = -1;
let currentSlideIndex = 0;

window.cancelModalCloseAnimation = function (modalElement) {
    if (!modalElement) return;
    const closeTimer = modalCloseTimers.get(modalElement);
    if (closeTimer) clearTimeout(closeTimer);
    modalCloseTimers.delete(modalElement);
    modalElement.classList.remove('is-closing');
};

window.closeModalWithAnimation = function (modalElement, onClosed) {
    if (!modalElement || !modalElement.classList.contains('show') || modalElement.classList.contains('is-closing')) return;

    modalElement.classList.add('is-closing');
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const closeDuration = reducedMotion
        ? (modalElement.id === 'bookModal' ? 220 : 0)
        : MODAL_CLOSE_DURATION;
    const closeTimer = setTimeout(() => {
        modalElement.classList.remove('show', 'is-closing');
        modalCloseTimers.delete(modalElement);
        if (onClosed) onClosed();
    }, closeDuration);
    modalCloseTimers.set(modalElement, closeTimer);
};

function restorePageAfterModalClose() {
    const menuOpen = document.getElementById('navLinks')?.classList.contains('active');
    const anyModalOpen = document.querySelector('.modal.show:not(.is-closing)');
    if (!menuOpen && !anyModalOpen) {
        document.body.classList.remove('modal-open');
        document.body.style.overflow = '';
        if (window.lenis) window.lenis.start();
    }
}

// Функция переключения слайдов
window.changeSlide = function (n) {
    const slides = document.querySelectorAll('.slider-slide');
    if (slides.length === 0) return;

    slides[currentSlideIndex].classList.remove('active');
    currentSlideIndex = (currentSlideIndex + n + slides.length) % slides.length;
    slides[currentSlideIndex].classList.add('active');
}

window.loadVideo = function (container, videoUrl) {
    container.innerHTML = `<div class="video-container" style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; border-radius: 8px;">
        <iframe src="${videoUrl}?autoplay=1" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: 0;" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>`;
    container.removeAttribute('onclick');
    container.style.cursor = 'default';
}

window.openBookModal = function (index) {
    currentBookIndex = index;
    const t = window.translations[window.currentLang];
    const book = books[index];
    if (!book) return;

    const title = l(book.title);
    const author = l(book.author);

    // Динамически обновляем SEO заголовок для соцсетей
    if (ogTitleTag) ogTitleTag.setAttribute('content', `${title} — BNC`);

    // Генерируем кнопки скачивания
    let buttonsHtml = '';
    if (book.files && book.files.length > 0) {
        book.files.forEach((file, fileIndex) => {
            // Автоматический подбор иконки программы (резолвер + ручная иконка из БД)
            const fileIconSrc = (window.BNCIcons && window.BNCIcons.resolveProgramIcon)
                ? window.BNCIcons.resolveProgramIcon(file)
                : file.icon;
            const iconHtml = fileIconSrc
                ? `<img src="${fileIconSrc}" style="width: 24px; height: 24px; margin-right: 8px; border-radius: 4px; object-fit: cover;" loading="lazy">`
                : '';

            buttonsHtml += `
            <div class="modal-file-item modern-file-item">
                <a href="javascript:void(0)" onclick="handleDownloadClick('${file.url || file.file_url || ''}', event, { title: ${JSON.stringify(l(file.name))}, image: ${JSON.stringify(file.icon || '')} })" class="modal-file-link modern-file-link">
                    <div class="modern-file-icon">${iconHtml || `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-5 h-5"><path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M16.5 12 12 16.5m0 0L7.5 12m4.5 4.5V3" /></svg>`}</div>
                    <div class="modern-file-info">
                        <span class="modern-file-name">${l(file.name)}</span>
                        <span class="modern-file-status">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-3.5 h-3.5">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm3.857-9.809a.75.75 0 0 0-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 1 0-1.06 1.061l2.5 2.5a.75.75 0 0 0 1.137-.089l4-5.5Z" clip-rule="evenodd" />
                            </svg>
                            <span>Проверено</span>
                        </span>
                    </div>
                    <div class="modern-file-arrow">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-4 h-4">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3" />
                        </svg>
                    </div>
                </a>
                <button onclick="openInstruction(${index}, ${fileIndex})" class="modal-info-btn modern-info-btn" title="${t.instruction_title}">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
                </button>
            </div>`;
        });
    } else if (book.video) {
        buttonsHtml = `
        <div style="display: flex; align-items: center; justify-content: center; gap: 10px; margin-bottom: 15px;">
            <a href="javascript:void(0)" onclick="handleDownloadClick('${book.video}', event, { external: true })" class="download-btn" style="margin: 0; flex: 1; background-color: #e74c3c;">${t.watch}</a>
        </div>`;
    } else {
        buttonsHtml = `<p style="color: #7f8c8d; margin-top: 20px;">${t.files_unavailable}</p>`;
    }

    // Генерируем обложку или слайдер
    let coverHtml;

    if (book.video) {
        coverHtml = `<div class="video-placeholder" style="cursor: default;">
            <img src="${book.image}" alt="${title}">
        </div>`;
    } else if (book.images && book.images.length > 0) {
        // Логика слайдера
        const slidesHtml = book.images.map((img, i) =>
            `<img src="${img}" class="slider-slide ${i === 0 ? 'active' : ''}" alt="Slide ${i + 1}">`
        ).join('');

        coverHtml = `
            <div class="slider-container">
                ${slidesHtml}
                <button class="slider-btn prev" onclick="changeSlide(-1)">&#10094;</button>
                <button class="slider-btn next" onclick="changeSlide(1)">&#10095;</button>
            </div>`;
        currentSlideIndex = 0;
    } else {
        // Стандартная обложка
        const initial = title.charAt(0);
        if (book.image) {
            coverHtml = `<img src="${book.image}" class="book-detail-cover-img" alt="${title}" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex'">
                          <div class="book-detail-cover" style="background-color: ${book.color}; display: none;">${initial}</div>`;
        } else {
            coverHtml = `<div class="book-detail-cover" style="background-color: ${book.color};">${initial}</div>`;
        }
    }

    modalContent.innerHTML = `
        <div class="modal-grid modern-modal-grid">
            <div class="modal-cover-container modern-cover-container">${coverHtml}</div>
            <div class="modal-info-container modern-info-container">
                <h2 id="modalBookTitle" class="modern-modal-title">${title}</h2>
                <p class="modal-author modern-modal-author">${author}</p>
                <div class="modal-files-list modern-files-list">${buttonsHtml}</div>
            </div>
        </div>
    `;

    window.cancelModalCloseAnimation(modal);
    modal.classList.add('show');
    document.body.style.overflow = 'hidden';
    document.body.classList.add('modal-open');
    if (window.lenis) window.lenis.stop();
}

// --- Новая функция просмотра карточки с дизайном 2026 ---
window.openViewModal = async (contentId) => {
    // 1. Запрос к базе данных для получения данных элемента
    const { data: item, error } = await supabaseClient
        .from('content')
        .select('*')
        .eq('id', contentId)
        .single();

    if (error || !item) {
        const msg = window.translations[window.currentLang]?.err_unknown || "Ошибка загрузки";
        return window.showToast(msg, 'error');
    }

    const titleRU = item.title?.ru || item.title || 'Без названия';
    
    // 2. Парсинг массива файлов, поддерживая старую колонку files_list
    let linksArray = [];
    if (item.files_list) {
        linksArray = typeof item.files_list === 'string' ? JSON.parse(item.files_list) : item.files_list;
    }
    if ((!Array.isArray(linksArray) || !linksArray.length) && item.files) {
        linksArray = typeof item.files === 'string' ? JSON.parse(item.files) : item.files;
    }
    linksArray = Array.isArray(linksArray)
        ? linksArray.map(link => link && typeof link === 'object'
            ? { ...link, url: link.url || link.file_url || '' }
            : link)
        : [];
    if (!Array.isArray(linksArray)) linksArray = [];

    // 3. Генерация кнопок для скачивания в новом дизайне
    let linksHTML = '';
    linksArray.forEach((link) => {
        const linkName = (typeof link === 'object' && link !== null) ? (link.name?.ru || link.name || 'Скачать файл') : 'Скачать файл';
        linksHTML += `
            <div class="viewmodal-download-row">
                <div class="viewmodal-download-info">
                    <p class="viewmodal-download-name">${escapeHTML(linkName)}</p>
                    <p class="viewmodal-download-status">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" width="14" height="14">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm3.857-9.809a.75.75 0 0 0-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 1 0-1.06 1.061l2.5 2.5a.75.75 0 0 0 1.137-.089l4-5.5Z" clip-rule="evenodd" />
                        </svg>
                        <span>Проверено VirusTotal</span>
                    </p>
                </div>
                <button type="button" class="viewmodal-download-btn" aria-label="Скачать ${escapeHTML(linkName)}" title="Скачать">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" width="20" height="20" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M16.5 12 12 16.5m0 0L7.5 12m4.5 4.5V3" />
                    </svg>
                </button>
            </div>
        `;
    });

    // 4. Вставка HTML в контейнер модальных окон
    const modalContainer = document.getElementById('bookModal'); // Используем существующий контейнер
    if (!modalContainer) return;
    
    modalContainer.innerHTML = `
        <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xl p-4 animate-fade-in" onclick="if (event.target === this) window.closeViewModal()">
            <div class="viewmodal-shell">
                <button onclick="window.closeViewModal()" class="viewmodal-close" aria-label="Закрыть окно">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2.5" stroke="currentColor" class="w-5 h-5"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" /></svg>
                </button>

                <div class="viewmodal-panel">
                    <div class="viewmodal-cover">
                        <img src="${item.image || 'assets/images/icon/icon1.png'}" alt="${titleRU}">
                        <div aria-hidden="true"></div>
                    </div>

                    <div class="viewmodal-heading">
                        <h2>${titleRU}</h2>
                    </div>
                    <div class="viewmodal-files">${linksHTML}</div>
                </div>
            </div>
        </div>
    `;
    modalContainer.querySelectorAll('.viewmodal-download-btn').forEach((button, index) => {
        const link = linksArray[index];
        const url = link && typeof link === 'object' ? link.url || link.file_url : '';
        const linkName = link && typeof link === 'object'
            ? (link.name?.ru || link.name || 'Скачать файл')
            : 'Скачать файл';
        button.addEventListener('click', (event) => handleDownloadClick(url, event, { title: linkName }));
    });
    window.cancelModalCloseAnimation(modalContainer);
    modalContainer.classList.add('show');
    document.body.classList.add('modal-open');
    if (window.lenis) window.lenis.stop();
};
function closeBookModal() {
    if (!modal) return;
    window.closeModalWithAnimation(modal, () => {
        if (ogTitleTag) ogTitleTag.setAttribute('content', defaultOgTitle);
        restorePageAfterModalClose();
    });
}

function closeSupportModal() {
    const supportModal = document.getElementById('supportModal');
    window.closeModalWithAnimation(supportModal, restorePageAfterModalClose);
}

if (closeModalSpan) {
    closeModalSpan.onclick = closeBookModal;
}

window.onclick = function (event) {
    if (modal && event.target == modal) closeBookModal();
    const supportModal = document.getElementById('supportModal');
    if (supportModal && event.target == supportModal) closeSupportModal();
}

window.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
        if (instructionModal && instructionModal.classList.contains('show')) {
            closeInstructionModal();
        } else if (document.getElementById('supportModal')?.classList.contains('show')) {
            closeSupportModal();
        } else if (modal?.querySelector('.viewmodal-panel')) {
            window.closeViewModal();
        } else {
            closeBookModal();
        }
    } else if (modal && modal.classList.contains('show')) {
        if (event.key === 'ArrowLeft') {
            let newIndex = currentBookIndex - 1;
            if (newIndex < 0) newIndex = books.length - 1; // Зацикливание: переход к последней
            openBookModal(newIndex);
        } else if (event.key === 'ArrowRight') {
            let newIndex = currentBookIndex + 1;
            if (newIndex >= books.length) newIndex = 0; // Зацикливание: переход к первой
            openBookModal(newIndex);
        }
    }
});

// Логика окна инструкции
const instructionModal = document.getElementById('instructionModal');
const closeInstructionSpan = document.querySelector('.close-instruction');

window.openInstruction = function (bookIndex, fileIndex) {
    const t = window.translations[window.currentLang];
    const file = books[bookIndex]?.files?.[fileIndex];
    if (!file) return;

    const rawText = l(file.instruction) || t.instruction_not_found;

    const formattedHtml = rawText.split('\n').map(line => {
        line = line.trim();
        if (!line) return '';

        // Функция для обработки текста внутри элементов
        const processText = (text) => {
            let processed = escapeHTML(text);
            // Поддержка жирного текста: **текст** -> <strong>текст</strong>
            processed = processed.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
            // Подсветка путей и файлов
            return window.formatPaths(processed);
        };

        // Списки (начинаются с -)
        if (line.startsWith('-')) {
            return `<div class="instruction-list-item">
                        <span class="bullet">•</span>
                        <span>${processText(line.replace(/^-+\s*/, ''))}</span>
                    </div>`;
        }

        // Заголовки (начинаются с #)
        if (line.startsWith('#')) {
            return `<h3 class="instruction-header">${processText(line.replace(/^#\s*/, ''))}</h3>`;
        }

        // Примечания (начинаются с !)
        if (line.startsWith('!')) {
            return `<div class="instruction-note">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 8px;"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
                        <span>${processText(line.replace(/^!\s*/, ''))}</span>
                    </div>`;
        }

        return `<p class="instruction-paragraph">${processText(line)}</p>`;
    }).join('');

    document.getElementById('instructionText').innerHTML = formattedHtml;

    // Добавляем обработку клика для копирования кода
    document.querySelectorAll('.instruction-code').forEach(el => {
        el.onclick = (e) => {
            e.stopPropagation();
            navigator.clipboard.writeText(el.innerText);
            window.showToast(window.currentLang === 'ru' ? 'Путь скопирован!' : 'Path copied!', 'success');
        };
    });

    const downloadBtn = document.getElementById('instructionDownloadBtn');
    downloadBtn.onclick = (e) => handleDownloadClick(file.url, e);
    // Убеждаемся, что кнопка видна (так как мы могли скрыть её в downloadSelected)
    document.getElementById('instructionDownloadBtn').style.display = '';

    window.cancelModalCloseAnimation(instructionModal);
    instructionModal.classList.add('show');
    document.body.style.overflow = 'hidden';
    document.body.classList.add('modal-open');
    if (window.lenis) window.lenis.stop();
}

// Вспомогательная функция для подсветки путей
window.formatPaths = function (text) {
    // Улучшенная регулярка: теперь понимает %appdata%, пути Windows и файлы
    const pathRegex = /([A-Z]:\\[^<\s]+|%[A-Z0-9_]+%|(?:"|').+?(?:"|')|[\w\-\.\/]+\.(?:exe|jar|zip|rar|json|toml|mcpack|mcaddon|mcworld))/gi;
    return text.replace(pathRegex, '<span class="instruction-code" title="Нажмите, чтобы скопировать">$1</span>');
};

if (closeInstructionSpan) {
    closeInstructionSpan.onclick = function () {
        closeInstructionModal();
    }
}

function closeInstructionModal() {
    window.closeModalWithAnimation(instructionModal, restorePageAfterModalClose);
}

window.addEventListener('click', (event) => {
    if (event.target == instructionModal) {
        closeInstructionModal();
    }
});

// --- AI REPORT LOGIC ---
window.openAiReport = async function (reportType = 'shaders') {
    const modal = document.getElementById('aiReportModal');
    const output = document.getElementById('ai-terminal-output');
    if (!modal || !output) return;

    const currentYear = new Date().getFullYear() + 1;
    window.cancelModalCloseAnimation(modal);
    modal.classList.add('show');
    document.body.classList.add('modal-open');
    output.innerHTML = '';

    const addLine = (text, delay = 0, isLink = false, shaderIndex = null) => {
        return new Promise(res => {
            setTimeout(() => {
                const span = document.createElement('span');
                span.className = 'terminal-line';
                if (isLink) {
                    span.innerHTML = `> RECOMMENDED: <span class="shader-item-link" onclick="openBookModal(${shaderIndex})">${text}</span>`;
                } else {
                    span.textContent = `> ${text}`;
                }
                output.appendChild(span);
                res();
            }, delay);
        });
    };

    await addLine("INITIALIZING ANALYTIC CORE...", 100);
    await addLine("CRAWLING GLOBAL REPOSITORIES...", 400);
    await addLine(`ANALYZING TRENDS FOR ${currentYear} SEASON...`, 600);

    // Выбираем данные в зависимости от типа
    const category = reportType === 'shaders' ? 'shaders' : 'textures';
    const filteredList = books.filter(b => b.type === category).slice(0, 10);

    if (filteredList.length === 0) {
        await addLine("ERROR: NO DATA FOUND IN 'SHADERS' CATEGORY.", 800);
    } else {
        await addLine(`ANALYSIS COMPLETE. FOUND ${filteredList.length} HIGH-RANK UNITS.`, 800);
        for (let i = 0; i < filteredList.length; i++) {
            const bookIndex = books.indexOf(filteredList[i]);
            await addLine(`${i + 1}. ${l(filteredList[i].title)}`, 150, true, bookIndex);
        }
        await addLine(`DATA SYNCHRONIZED WITH BNC CORE v2.6`, 500);
    }
};

window.closeAiReport = function () {
    const modal = document.getElementById('aiReportModal');
    if (modal) {
        window.closeModalWithAnimation(modal, restorePageAfterModalClose);
    }
};

// --- ЛОГИКА МОДАЛЬНОГО ОКНА ПОДДЕРЖКИ ---
function setupSupportModal() {
    const supportModal = document.getElementById('supportModal');
    if (!supportModal) return;

    const supportForm = document.getElementById('todo-form');
    const supportEmailInput = document.getElementById('support-email');
    const supportMessageTextarea = document.getElementById('todo-input');
    const submitButton = supportForm?.querySelector('.btn-submit-support');
    const formBody = document.getElementById('support-form-body');
    const successMessage = document.getElementById('support-success-message');
    const closeBtn = document.getElementById('closeSupport');

    // Открытие модального окна
    document.querySelectorAll('#supportBtn, #supportBtnMenu').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            window.cancelModalCloseAnimation(supportModal);
            supportModal.classList.add('show');
            supportModal.querySelector('.support-modal-content')?.classList.remove('ticket-sent');
            document.body.classList.add('modal-open');
            document.body.style.overflow = 'hidden';
            // При открытии всегда показываем форму и скрываем сообщение об успехе
            if (formBody) formBody.style.display = 'block';
            if (successMessage) successMessage.style.display = 'none';
            if (supportForm) supportForm.reset();
            if (window.lenis) window.lenis.stop();
        });
    });

    // Отправка формы
    if (supportForm && submitButton) {
        supportForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = supportEmailInput.value.trim();
            const message = supportMessageTextarea.value.trim();
            const t = window.translations[window.currentLang];

            if (!message) {
                window.showToast(t.support_message_required || "Пожалуйста, введите ваше сообщение.", 'error');
                supportMessageTextarea.focus();
                return;
            }

            submitButton.disabled = true;
            submitButton.classList.add('loading');
            submitButton.innerHTML = `<span class="spinner"></span>${t.sending_message || "Отправка..."}`;

            const currentUser = window.currentUser;
            const contactEmail = email || (currentUser && currentUser.email) || null;
            let remoteTicketId = null;
            let error = null;
            try {
                const { data: ticket, error: ticketError } = await supabaseClient
                    .from('tickets')
                    .insert({
                        user_id: currentUser?.id || null,
                        email: contactEmail,
                        subject: message.slice(0, 80),
                        status: 'open'
                    })
                    .select('id')
                    .single();
                if (ticketError) throw ticketError;
                if (!ticket || !ticket.id) throw new Error('База данных не вернула номер обращения.');
                remoteTicketId = String(ticket.id);

                const { error: messageError } = await supabaseClient
                    .from('ticket_messages')
                    .insert({ ticket_id: remoteTicketId, body: message });
                if (messageError) throw messageError;
            } catch (requestError) {
                console.error('Не удалось отправить обращение:', requestError);
                error = requestError instanceof Error
                    ? requestError
                    : new Error(requestError?.message || 'Не удалось отправить обращение.');
            }

            submitButton.disabled = false;
            submitButton.classList.remove('loading');
            submitButton.innerHTML = t.support_button_text || "Отправить сообщение";

            if (error) window.showToast(t.support_send_error || `Ошибка: ${error.message}`, 'error');
            else {
                // Локальный кэш для мгновенного отображения в кабинете.
                let ticket = null;
                if (window.bncTickets) {
                    ticket = window.bncTickets.add({
                        id: remoteTicketId || undefined,
                        subject: message.slice(0, 60),
                        message: message,
                        email: contactEmail || ''
                    });
                }
                // Показываем номер тикета в сообщении об успехе
                const numEl = document.getElementById('ticket-number');
                if (numEl && ticket && ticket.id) numEl.textContent = '#' + ticket.id;
                // Скрываем форму и показываем сообщение об успехе
                if (formBody) formBody.style.display = 'none';
                if (successMessage) {
                    supportModal.querySelector('.support-modal-content')?.classList.add('ticket-sent');
                    successMessage.style.display = 'block';
                    // Перезапускаем анимацию появления
                    successMessage.classList.remove('is-shown');
                    void successMessage.offsetWidth;
                    successMessage.classList.add('is-shown');

                    const countdownSpan = document.getElementById('countdown-timer');
                    const progressEl = document.getElementById('support-countdown-bar');
                    if (countdownSpan) {
                        const TOTAL = 10;
                        let seconds = TOTAL;
                        countdownSpan.textContent = seconds;
                        if (progressEl) progressEl.style.width = '0%';

                        if (window.__supportCountdown) clearInterval(window.__supportCountdown);
                        window.__supportCountdown = setInterval(() => {
                            seconds--;
                            countdownSpan.textContent = Math.max(seconds, 0);
                            if (progressEl) progressEl.style.width = Math.min((TOTAL - seconds) / TOTAL * 100, 100) + '%';
                            if (seconds <= 0) {
                                clearInterval(window.__supportCountdown);
                                closeSupportModal();
                            }
                        }, 1000);
                    }
                }
            }
        });
    }
}

// --- ЛОГИКА МОДАЛЬНОГО ОКНА ПОДДЕРЖКИ ---
function setupDonateModal() {
    const donateModal = document.getElementById('donateModal');
    if (!donateModal) return;

    const openBtns = document.querySelectorAll('#footer-donate-link, #donateBtnMenu');
    const closeBtn = document.getElementById('closeDonate');

    const openModal = (e) => {
        e.preventDefault();
        window.cancelModalCloseAnimation(donateModal);
        donateModal.classList.add('show');
        document.body.classList.add('modal-open');
        document.body.style.overflow = 'hidden';
        if (window.lenis) window.lenis.stop();
    };

    const closeModal = () => {
        window.closeModalWithAnimation(donateModal, restorePageAfterModalClose);
    };

    openBtns.forEach(btn => btn.addEventListener('click', openModal));
    if (closeBtn) closeBtn.addEventListener('click', closeModal);
}
// --- ЛОГИКА СТРАНИЦЫ УТИЛИТ (utils.html) ---
window.renderUtils = function (filterText = '') {
    if (!utilsGrid) return;
    // Пока данные грузятся и утилит ещё нет — не трогаем сетку,
    // чтобы не мигало «пусто» и не сбивалась анимация появления.
    if (isLoading && !books.length) return;
    const fragment = document.createDocumentFragment();

    // Фильтруем только опубликованные утилиты и по тексту поиска
    const utilBooks = books.filter(b => 
        b.type === 'utils' && 
        (l(b.title).toLowerCase().includes(filterText.toLowerCase()))
    );

    if (!utilBooks.length) {
        if (isLoading) return;
        if (contentLoadError) {
            renderCatalogState(
                'fa-triangle-exclamation',
                'Не удалось загрузить утилиты',
                'Проверьте подключение и попробуйте загрузить данные ещё раз.',
                true
            );
        } else if (!books.some(book => book.type === 'utils') && !filterText.trim()) {
            renderCatalogState(
                'fa-box-open',
                'Утилиты пока не добавлены',
                'База обновляется — новые материалы появятся здесь.'
            );
        } else {
            renderCatalogState('fa-magnifying-glass', 'Ничего не найдено', 'Попробуйте изменить поисковый запрос.');
        }
        return;
    }

    utilBooks.forEach(book => {
        // Создаем блок категории
        const catBlock = document.createElement('div');
        catBlock.className = 'category-block';

        const catTitle = document.createElement('div');
        catTitle.className = 'utils-category-title';
        catTitle.textContent = l(book.title);
        catBlock.appendChild(catTitle);

        // Карточки файлов
        const INITIAL_LIMIT = 9;
        const hasMore = book.files.length > INITIAL_LIMIT;

        book.files.forEach((file, index) => {
            const card = document.createElement('div');
            card.className = 'util-card';
            const utilTitle = l(file.name).replace('Скачать ', '').replace('Download ', '');

            // Автоматический подбор иконки программы (резолвер + ручная иконка из БД)
            const genericAppIcon = (window.BNCIcons && window.BNCIcons.GENERIC_APP_ICON)
                || 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9IiM5NGEzYjgiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj48cmVjdCB4PSIyIiB5PSIyIiB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHJ4PSI1Ii8+PHBhdGggZD0iTTEyIDh2OG0tNC00aDgiLz48L3N2Zz4=';

            const iconSrc = (window.BNCIcons && window.BNCIcons.resolveProgramIcon)
                ? window.BNCIcons.resolveProgramIcon(file)
                : (file.icon || genericAppIcon);

            card.innerHTML = `
                <img src="${iconSrc}" class="util-icon" alt="icon" onerror="this.src='${genericAppIcon}'" loading="lazy">
                <div class="util-info">
                    <div class="util-name">${utilTitle}</div>
                </div>
                <button type="button" class="util-download-btn" title="${l({ ru: 'Скачать', en: 'Download' })}" aria-label="${l({ ru: 'Скачать', en: 'Download' })} ${escapeHTML(utilTitle)}">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                </button>
            `;
            card.querySelector('.util-download-btn').addEventListener('click', (event) => {
                handleDownloadClick(file.url, event, { title: utilTitle, image: file.icon || '' });
            });

            if (index >= INITIAL_LIMIT) {
                card.style.display = 'none';
                card.classList.add('hidden-card');
            }

            catBlock.appendChild(card);
        });

        if (hasMore) {
            const btnContainer = document.createElement('div');
            btnContainer.style.width = '100%';
            btnContainer.style.display = 'flex';
            btnContainer.style.justifyContent = 'center';
            btnContainer.style.marginTop = '15px';

            const btn = document.createElement('button');
            btn.className = 'btn';
            btn.style.background = 'transparent';
            btn.textContent = l({ ru: 'Показать больше', en: 'Show more' });

            btn.onclick = () => {
                const isExpanded = btn.classList.contains('expanded');
                const hiddenCards = catBlock.querySelectorAll('.hidden-card');

                hiddenCards.forEach(c => c.style.display = isExpanded ? 'none' : '');
                btn.textContent = isExpanded ? l({ ru: 'Показать больше', en: 'Show more' }) : l({ ru: 'Скрыть', en: 'Show less' });
                btn.classList.toggle('expanded');
            };

            btnContainer.appendChild(btn);
            catBlock.appendChild(btnContainer);
        }

        fragment.appendChild(catBlock);
    });

    utilsGrid.innerHTML = '';
    utilsGrid.appendChild(fragment);
    // Обновляем ScrollTrigger для корректной работы Lenis и анимаций
    if (typeof ScrollTrigger !== 'undefined') requestAnimationFrame(() => ScrollTrigger.refresh());
}

// --- Прелоадер и Кинетическая типографика ---

// --- Premium Bento Animations ---
/* Появление Bento при скролле вниз и вверх (направление учитывается).
   Анимируется .bento-shell, а триггером служит статичный .bento-card —
   поэтому трансформации не сбивают расчёт позиций ScrollTrigger. */
let bentoInited = false;

function animateBentoCounter(el, delay = 0) {
    const target = parseInt(el.dataset.count || '0', 10);
    const suffix = el.dataset.suffix || '';
    if (el._countTween) el._countTween.kill();
    if (typeof gsap === 'undefined') {
        el.textContent = target + suffix;
        return;
    }
    const state = { v: 0 };
    el.textContent = '0' + suffix;
    el._countTween = gsap.to(state, {
        v: target,
        duration: 1.6,
        delay,
        ease: 'power4.out',
        onUpdate: () => { el.textContent = Math.round(state.v) + suffix; }
    });
}

function resetBentoCounter(el) {
    if (el._countTween) el._countTween.kill();
    el.textContent = '0' + (el.dataset.suffix || '');
}

function initBentoCounters() {
    const cards = document.querySelectorAll('.bento-card');
    if (!cards.length || bentoInited) return;
    bentoInited = true;

    const hasGsap = typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined';

    if (!hasGsap) {
        cards.forEach((card) => {
            card.classList.add('is-in');
            card.querySelectorAll('.bento-counter').forEach((el) => {
                el.textContent = (el.dataset.count || '0') + (el.dataset.suffix || '');
            });
        });
        return;
    }

    gsap.registerPlugin(ScrollTrigger);

    cards.forEach((card) => {
        const shell = card.querySelector('.bento-shell') || card;
        const parts = shell.querySelectorAll('.bento-head, .bento-figure, .bento-title, .bento-text, .bento-visual');
        const counters = shell.querySelectorAll('.bento-counter');
        let shown = false;

        // Карточка справа в ряду стартует чуть позже — эффект «волны».
        const stagger = () => {
            const row = Array.from(cards).filter(c => Math.abs(c.offsetTop - card.offsetTop) < 4);
            return Math.max(row.indexOf(card), 0) * 0.12;
        };

        const hiddenState = (dir) => ({
            autoAlpha: 0,
            y: 38 * dir,
            rotationX: -5 * dir,
            scale: 0.98,
            transformOrigin: dir > 0 ? '50% 100%' : '50% 0%'
        });

        gsap.set(shell, { ...hiddenState(1), transformPerspective: 1400, force3D: true });
        gsap.set(parts, { autoAlpha: 0, y: 26 });
        counters.forEach(resetBentoCounter);

        const show = (dir) => {
            if (shown) return;
            shown = true;
            const delay = stagger();
            gsap.killTweensOf(shell);
            gsap.killTweensOf(parts);
            if (parseFloat(gsap.getProperty(shell, 'opacity')) < 0.05) gsap.set(shell, hiddenState(dir));
            gsap.to(shell, {
                autoAlpha: 1, y: 0, rotationX: 0, scale: 1,
                duration: 0.7, delay, ease: 'power3.out', force3D: true
            });
            gsap.to(parts, {
                autoAlpha: 1, y: 0,
                duration: 0.55, delay: delay + 0.12, ease: 'power2.out',
                stagger: 0.035
            });
            card.classList.add('is-in');
            counters.forEach(el => animateBentoCounter(el, delay + 0.25));
        };

        const trigger = ScrollTrigger.create({
            trigger: card,
            start: 'top 90%',
            end: 'bottom 10%',
            onEnter: () => show(1),       // скролл вниз — снизу
            onEnterBack: () => show(-1),  // скролл вверх — сверху
            onRefresh: (self) => {
                const top = card.getBoundingClientRect().top;
                if (self.isActive || top <= window.innerHeight * 0.9) show(1);
            }
        });
        // При быстрой прокрутке во время загрузки триггер может быть уже
        // пройден до первого обновления ScrollTrigger. Такие карточки сразу
        // становятся видимыми и больше не скрываются при выходе из viewport.
        if (trigger.progress > 0 || card.getBoundingClientRect().top <= window.innerHeight * 0.9) {
            show(1);
        }

        // Свет по рамке и блик за курсором — только для мыши (без наклона: он отрывал поверхность от рамки)
        if (window.matchMedia('(hover: hover) and (pointer: fine)').matches) {
            let rect = null;
            card.addEventListener('pointerenter', () => { rect = card.getBoundingClientRect(); });
            card.addEventListener('pointermove', (e) => {
                if (!rect) rect = card.getBoundingClientRect();
                card.style.setProperty('--mx', ((e.clientX - rect.left) / rect.width * 100).toFixed(1) + '%');
                card.style.setProperty('--my', ((e.clientY - rect.top) / rect.height * 100).toFixed(1) + '%');
            });
            card.addEventListener('pointerleave', () => { rect = null; });
        }
    });
}

function initLuxuryLogic() {
    initBentoCounters();

    const updateThemeIcon = (isDark) => {
        const sunPaths = document.querySelectorAll('#theme-icon .sun-path');
        const moonPath = document.querySelector('#theme-icon .moon-path');
        if (sunPaths.length > 0 && moonPath) {
            sunPaths.forEach(p => p.style.display = isDark ? 'none' : 'block');
            moonPath.style.display = isDark ? 'block' : 'none';
        }
    };

    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            document.body.classList.toggle('dark-theme');
            const isDark = document.body.classList.contains('dark-theme');
            localStorage.setItem('theme', isDark ? 'dark-theme' : 'light');
            updateThemeIcon(isDark);
        });
        // Проверка сохраненной темы. По умолчанию тема темная.
        // Убираем класс dark-theme, только если пользователь явно выбрал светлую.
        if (localStorage.getItem('theme') === 'light') {
            document.body.classList.remove('dark-theme');
        }
        // Обновляем иконку при загрузке.
        updateThemeIcon(document.body.classList.contains('dark-theme'));
    }

    // Прогресс-бар
    const progressBar = document.querySelector('.progress-bar');
    if (progressBar) {
        let progressTicking = false;
        window.addEventListener('scroll', () => {
            if (progressTicking) return;
            progressTicking = true;
            requestAnimationFrame(() => {
                progressTicking = false;
                const height = document.documentElement.scrollHeight - window.innerHeight;
                const scrolled = height > 0 ? (window.scrollY / height) * 100 : 0;
                progressBar.style.width = Math.min(scrolled, 100) + '%';
            });
        }, { passive: true });
    }

    // Анимации Bento управляются собственной CSS-логикой каскадного
    // появления + счётчиками (initBentoCounters). Тяжёлый 3D-эффект убран —
    // он искажал крупные цифры и конфликтовал с плавным появлением карточек.

    // 2. FAQ Аккордеон
    const faqItems = document.querySelectorAll('.faq-item');
    if (faqItems.length > 0) {
        faqItems.forEach(item => {
            const q = item.querySelector('.faq-question');
            q.addEventListener('click', () => {
                const isOpen = item.classList.contains('open');
                faqItems.forEach(i => i.classList.remove('open')); // Закрыть остальные
                if (!isOpen) item.classList.add('open');
                const icon = q.querySelector('i');
                if (icon) icon.style.transform = item.classList.contains('open') ? 'rotate(180deg)' : 'rotate(0deg)';
            });
        });
    }

    // 3. PIN-секция — новая карточка открывается «шторкой» снизу (непрозрачная,
    //    без наложения текстов), предыдущие уходят в глубину стопки.
    const pinContainer = document.querySelector('.pin-container');
    const layers = gsap.utils.toArray('.pin-layer');
    const sidebarTitles = gsap.utils.toArray('.pin-sidebar-title');
    const progressFills = gsap.utils.toArray('.pin-progress-fill');

    if (pinContainer && layers.length > 0 && typeof ScrollTrigger !== 'undefined') {
        const N = layers.length;
        const HOLD = 0.45;          // пауза на каждой карточке
        const STEP = 1 + HOLD;      // длина одного шага таймлайна

        const shades = layers.map((layer, i) => {
            layer.style.zIndex = i + 1;
            let shade = layer.querySelector('.pin-shade');
            if (!shade) {
                shade = document.createElement('div');
                shade.className = 'pin-shade';
                layer.appendChild(shade);
            }
            return shade;
        });
        const marks = layers.map((layer) => layer.querySelector('.pin-watermark'));
        // одинаковая высота карточек — иначе короткие прячутся за длинной и стопка «теряет» слои
        const equalizeLayers = () => {
            layers.forEach((l) => { l.style.minHeight = ''; });
            const hMax = Math.max(...layers.map((l) => l.offsetHeight));
            layers.forEach((l) => { l.style.minHeight = hMax + 'px'; });
        };
        equalizeLayers();
        ScrollTrigger.addEventListener('refreshInit', equalizeLayers);
        const contentOf = (layer) => layer.querySelectorAll('.meta, h3, p, .pin-features, .detail-list');
        const PEEK = window.innerWidth <= 900 ? 13 : 24;  // насколько старые карточки выглядывают сверху
        const partsOf = (title) => title ? title.querySelectorAll('.pin-num, .pin-label, .pin-progress-bar') : null;

        gsap.set(layers, { transformPerspective: 1400, transformOrigin: '50% 0%', autoAlpha: 1 });
        gsap.set(layers[0], { '--reveal': 1, y: 0 });
        gsap.set(layers.slice(1), { '--reveal': 0, y: 70 });
        gsap.set(shades, { opacity: 0 });
        layers.slice(1).forEach((l) => gsap.set(contentOf(l), { y: 44, opacity: 0.3 }));
        gsap.set(marks.slice(1).filter(Boolean), { yPercent: 35, opacity: 0 });

        sidebarTitles.forEach((title, i) => {
            gsap.set(title, { opacity: 1 });
            gsap.set(partsOf(title), i === 0 ? { yPercent: 0, opacity: 1 } : { yPercent: 60, opacity: 0 });
        });
        gsap.set(progressFills, { scaleX: 0, transformOrigin: '0% 50%' });

        const pinTl = gsap.timeline({
            defaults: { ease: 'none' },
            scrollTrigger: {
                trigger: pinContainer,
                start: 'top top',
                end: () => '+=' + window.innerHeight * (N - 1) * 1.2,
                scrub: true,
                pin: true,
                pinSpacing: true,
                anticipatePin: 1,
                invalidateOnRefresh: true
            }
        });

        for (let i = 1; i < N; i++) {
            const t = (i - 1) * STEP + HOLD;

            // Входящая карточка: шторка снизу вверх + подъём, затем текст по строкам
            pinTl.fromTo(layers[i],
                { '--reveal': 0, y: 70 },
                { '--reveal': 1, y: 0, duration: 1, ease: 'power3.inOut' }, t)
                 .to(contentOf(layers[i]), { y: 0, opacity: 1, duration: 0.8, stagger: 0.06, ease: 'power2.out' }, t + 0.1);
            if (marks[i]) pinTl.to(marks[i], { yPercent: 0, opacity: 1, duration: 1, ease: 'power2.out' }, t + 0.2);
            if (marks[i - 1]) pinTl.to(marks[i - 1], { yPercent: -30, opacity: 0, duration: 0.8, ease: 'power2.in' }, t);

            // Предыдущие карточки уходят назад и выглядывают сверху
            for (let j = 0; j < i; j++) {
                const depth = i - j;
                pinTl.to(layers[j], {
                    y: -PEEK * depth,
                    scale: 1 - 0.05 * depth,
                    rotationX: 4 * Math.min(depth, 2),
                    autoAlpha: 1,
                    duration: 1, ease: 'power2.inOut'
                }, t).to(shades[j], {
                    opacity: Math.min(0.22 * depth, 0.6),
                    duration: 1, ease: 'power2.inOut'
                }, t);
            }

            // Сайдбар: «барабан» — старый номер уезжает вверх, новый приезжает снизу
            const prevParts = partsOf(sidebarTitles[i - 1]);
            const nextParts = partsOf(sidebarTitles[i]);
            if (prevParts) pinTl.to(prevParts, { yPercent: -60, opacity: 0, duration: 0.35, stagger: 0.04, ease: 'power2.in' }, t);
            if (nextParts) pinTl.to(nextParts, { yPercent: 0, opacity: 1, duration: 0.5, stagger: 0.06, ease: 'power3.out' }, t + 0.5);
        }
        pinTl.to({}, { duration: HOLD }, (N - 1) * STEP);

        const total = pinTl.duration();
        progressFills.forEach((fill, i) => {
            const start = i === 0 ? 0 : (i - 1) * STEP + HOLD + 0.5;
            const end = i === N - 1 ? total : i * STEP + HOLD;
            pinTl.fromTo(fill, { scaleX: 0 }, { scaleX: 1, duration: Math.max(end - start, 0.1) }, start);
        });

        // WebGL-фон: только плавный зум, палитра остаётся золотой
        const u = window.webglBackgroundUniforms;
        if (u) pinTl.to(u.uZoom, { value: 1.25, duration: total }, 0);

        // Мягкий блик за курсором (только мышь)
        const wrapper = document.querySelector('.pin-layers-wrapper');
        if (wrapper && window.matchMedia('(hover: hover) and (pointer: fine)').matches) {
            const glow = document.createElement('div');
            glow.className = 'pin-glow';
            wrapper.appendChild(glow);
            gsap.set(glow, { xPercent: -50, yPercent: -50 });
            const glowX = gsap.quickTo(glow, 'x', { duration: 0.6, ease: 'power3.out' });
            const glowY = gsap.quickTo(glow, 'y', { duration: 0.6, ease: 'power3.out' });
            let rect = null;
            wrapper.addEventListener('pointerenter', () => {
                rect = wrapper.getBoundingClientRect();
                gsap.to(glow, { opacity: 1, duration: 0.6 });
            });
            wrapper.addEventListener('pointermove', (e) => {
                if (!rect) rect = wrapper.getBoundingClientRect();
                glowX(e.clientX - rect.left);
                glowY(e.clientY - rect.top);
            });
            wrapper.addEventListener('pointerleave', () => {
                rect = null;
                gsap.to(glow, { opacity: 0, duration: 0.6 });
            });
        }
    }

    // 4. Горизонтальный скролл отзывов (Автоматический бесконечный цикл)
    const testimonialScroll = document.querySelector('.testimonial-scroll');
    const testimonialsSection = document.querySelector('.testimonials-section');

    // Проверяем наличие блока отзывов перед запуском анимации
    if (testimonialScroll) {
        if (testimonialsSection && window.innerWidth > 768) {
            // Клонируем содержимое для создания бесшовного эффекта
            const originalCards = testimonialScroll.innerHTML;
            testimonialScroll.innerHTML += originalCards;

            const scrollWidth = testimonialScroll.scrollWidth;
            const amountToScroll = scrollWidth / 2; // Так как мы дублировали контент

            // Основная бесконечная анимация
            const autoScroll = gsap.to(testimonialScroll, {
                x: -amountToScroll,
                duration: 40, // Скорость прокрутки (чем больше число, тем медленнее)
                ease: "none",
                repeat: -1,
                paused: false
            });

            // Пауза при наведении, чтобы можно было прочитать
            testimonialScroll.addEventListener('mouseenter', () => {
                gsap.to(autoScroll, { timeScale: 0, duration: 0.5 });
            });
            testimonialScroll.addEventListener('mouseleave', () => {
                gsap.to(autoScroll, { timeScale: 1, duration: 0.5 });
            });

            // Оптимизация: запускаем анимацию только когда секция видна во вьюпорте
            ScrollTrigger.create({
                trigger: testimonialsSection,
                start: "top bottom",
                end: "bottom top",
                onToggle: self => self.isActive ? autoScroll.play() : autoScroll.pause()
            });

            // Логика ручного перелистывания (Quiet Luxury Feel)
            const stepWidth = 468;
            const nextBtn = document.getElementById('nextTestimonial');
            const prevBtn = document.getElementById('prevTestimonial');
            let resumeTimer;
            let isAnimating = false;

            const moveManual = (direction) => {
                if (isAnimating) return;
                isAnimating = true;
                autoScroll.pause();
                if (resumeTimer) resumeTimer.kill();

                const currentX = gsap.getProperty(testimonialScroll, "x");
                let targetX = currentX + (stepWidth * direction);

                // Бесшовное зацикливание
                if (targetX <= -amountToScroll) targetX += amountToScroll;
                if (targetX > 0) targetX -= amountToScroll;

                gsap.to(testimonialScroll, {
                    x: targetX,
                    duration: 0.35,
                    ease: "power2.out",
                    onComplete: () => {
                        isAnimating = false;
                        const newX = gsap.getProperty(testimonialScroll, "x");
                        autoScroll.progress(Math.abs(newX) / amountToScroll);
                        resumeTimer = gsap.delayedCall(3, () => autoScroll.play());
                    }
                });
            };

            if (nextBtn) nextBtn.addEventListener('click', () => moveManual(-1));
            if (prevBtn) prevBtn.addEventListener('click', () => moveManual(1));
        }
    }

    const discoverBtn = document.getElementById('discoverBtn');
    if (discoverBtn) {
        discoverBtn.addEventListener('click', () => {
            const target = document.querySelector('.bento-grid');
            if (window.lenis) window.lenis.scrollTo(target, { offset: -80 });
            else target?.scrollIntoView({ behavior: 'smooth' });
        });
    }
}

/**
 * Скролл-сцена BNC.
 * Desktop: hero закрепляется, надпись выезжает в центр и растёт, остальной контент
 * уходит; буквы расходятся в 3D, по ним проходит блик, затем буквы пролетают
 * «сквозь камеру», разлетаются золотые искры, hero растворяется.
 * На mobile hero выше экрана — центрируем по его видимой части.
 */
function initKineticScroll({ element, chars, glow, rail, flare, sparks, mid }) {
    const hero = element.closest('.hero-split');
    const side = hero ? hero.querySelectorAll('.hero-badge, .hero-desc, .cta-luxury') : [];
    const media = hero ? hero.querySelector('.hero-media') : null;
    const burst = sparks.map((_, i) => ({
        a: (i / sparks.length) * Math.PI * 2 + Math.sin(i * 12.9898) * 0.45,
        d: 0.85 + ((i * 7) % 5) * 0.2
    }));

    const build = (full) => {
        const S = full ? 2.2 : 0;
        const tl = gsap.timeline({
            defaults: { ease: 'none' },
            scrollTrigger: full ? {
                trigger: hero,
                pin: hero,
                pinSpacing: false,
                start: () => 'top ' + Math.max(70, (window.innerHeight - hero.offsetHeight) / 2 + 30) + 'px',
                end: () => '+=' + sceneLength(),
                scrub: 1.2,
                anticipatePin: 1,
                invalidateOnRefresh: true,
                onUpdate: onProgress
            } : {
                trigger: element,
                start: 'clamp(top 45%)',
                end: 'clamp(bottom -30%)',
                scrub: 1,
                invalidateOnRefresh: true,
                onUpdate: onProgress
            }
        });

        if (full) {
            // Сдвиг, при котором центр самих букв (а не всего h1 с отступами) окажется
            // в центре hero после масштабирования до SCALE. scale идёт от центра h1.
            const word = element.querySelector('.kt-word');
            // на узких экранах буквы не должны вылезать за hero
            const targetScale = () => {
                const s = gsap.getProperty(element, 'scale') || 1;
                const ww = (word || element).getBoundingClientRect().width / s;
                return Math.max(1, Math.min(1.5, (hero.clientWidth * 0.62) / ww));
            };
            const center = (axis) => {
                const h = hero.getBoundingClientRect();
                const e = element.getBoundingClientRect();
                const w = (word || element).getBoundingClientRect();
                const k = axis === 'x' ? ['left', 'width', 'x'] : ['top', 'height', 'y'];
                const s = gsap.getProperty(element, 'scale') || 1;
                // по вертикали — центр видимой части hero (на mobile hero выше экрана)
                const heroC = axis === 'x'
                    ? h.left + h.width / 2
                    : (Math.max(h.top, 70) + Math.min(h.bottom, window.innerHeight)) / 2;
                const elC = e[k[0]] + e[k[1]] / 2;
                const local = (w[k[0]] + w[k[1]] / 2 - elC) / s;
                return heroC - (elC - gsap.getProperty(element, k[2])) - local * targetScale();
            };
            tl.to(element, { x: () => center('x'), y: () => center('y'), scale: targetScale, duration: 3.6, ease: 'power2.inOut' }, 0)
                .to(side, { opacity: 0, y: -40, filter: 'blur(8px)', duration: 1.8, stagger: 0.25, ease: 'power1.in' }, 0);
            if (media) {
                tl.to(media, {
                    opacity: 0, x: 140, rotationY: -28, scale: 0.86,
                    transformPerspective: 1200, duration: 2.6, ease: 'power2.in'
                }, 0);
            }
        }

        tl.fromTo(element, { '--kt-lines': 1 }, { '--kt-lines': 0, duration: 1.5 }, 0)
            .to(rail, { opacity: 0, duration: 1.5 }, 0)
            // буквы расходятся веером с глубиной
            .to(chars, {
                xPercent: (i) => (i - mid) * 42,
                rotationY: (i) => (i - mid) * -22,
                z: (i) => -Math.abs(i - mid) * 60,
                transformPerspective: 900,
                duration: 3.2,
                ease: 'power2.inOut',
                force3D: true
            }, S)
            .to(glow, { scale: 1.9, duration: 3, ease: 'power1.inOut' }, S)
            .fromTo(flare,
                { xPercent: -130, opacity: 0 },
                { xPercent: 130, opacity: 1, duration: 2.6, ease: 'power1.inOut' }, S + 0.6)
            .to(flare, { opacity: 0, duration: 0.6 }, S + 2.6)
            // пролёт «сквозь камеру»
            .to(chars, {
                z: 620,
                xPercent: (i) => (i - mid) * 130,
                rotationY: (i) => (i - mid) * 34,
                rotationX: (i) => (i % 2 ? 14 : -14),
                opacity: 0,
                filter: 'blur(6px)',
                duration: 3.4,
                ease: 'power3.in',
                stagger: { each: 0.18, from: 'center' },
                force3D: true
            }, S + 3)
            .to(glow, { scale: 3.2, opacity: 0, duration: 3, ease: 'power2.in' }, S + 3.2)
            .fromTo(sparks,
                { x: 0, y: 0, scale: 0.2, opacity: 0 },
                {
                    x: (i) => Math.cos(burst[i].a) * burst[i].d * element.offsetWidth * 0.6,
                    y: (i) => Math.sin(burst[i].a) * burst[i].d * element.offsetWidth * 0.4,
                    scale: 1.2,
                    opacity: 1,
                    duration: 1.8,
                    ease: 'power2.out',
                    stagger: 0.03
                }, S + 3.1)
            .to(sparks, { opacity: 0, scale: 0.4, duration: 1.4, stagger: 0.03 }, S + 4.7);

        if (full) tl.to(hero, { opacity: 0, scale: 0.96, duration: 1.4, ease: 'power1.in' }, '>-1');
        return tl;
    };

    function onProgress(self) {
        if (self.progress <= 0.005) return;
        // вход ещё не доиграл — снимаем маску, чтобы буквы не обрезались
        element.classList.add('kt-done');
        // у .reveal есть CSS-transition на opacity/transform — он бы «тянул» scrub
        if (hero && hero.style.transition !== 'none') hero.style.transition = 'none';
    }

    const sceneLength = () => Math.round(window.innerHeight * 1.4);
    const mm = gsap.matchMedia();
    if (hero) mm.add('all', () => {
        // pinSpacing: false + спейсер (длина сцены − высота hero): Bento поднимается
        // из-под закреплённого hero во второй половине сцены, без пустого экрана после неё
        const spacer = document.createElement('div');
        spacer.className = 'kt-scene-spacer';
        spacer.setAttribute('aria-hidden', 'true');
        hero.after(spacer);
        const size = () => { spacer.style.height = Math.max(0, sceneLength() - hero.offsetHeight) + 'px'; };
        size();
        ScrollTrigger.addEventListener('refreshInit', size);
        hero.classList.add('kt-scene');
        build(true);
        return () => {
            ScrollTrigger.removeEventListener('refreshInit', size);
            spacer.remove();
            hero.classList.remove('kt-scene');
            hero.style.transition = '';
        };
    });
    else mm.add('all', () => { build(false); });
}

function animateKineticTitle(element) {
    if (!element || element.dataset.kinetic === '1') return;
    element.dataset.kinetic = '1';

    const text = element.textContent.trim();
    element.setAttribute('aria-label', text);
    element.innerHTML = '';

    const rail = document.createElement('span');
    rail.className = 'kt-rail';
    const glow = document.createElement('span');
    glow.className = 'kt-glow';
    const word = document.createElement('span');
    word.className = 'kt-word';
    word.setAttribute('aria-hidden', 'true');
    rail.setAttribute('aria-hidden', 'true');
    glow.setAttribute('aria-hidden', 'true');

    const chars = [];
    const inners = [];
    text.split('').forEach((ch, i) => {
        const c = document.createElement('span');
        c.className = 'kt-char';
        c.style.setProperty('--i', i);
        const inner = document.createElement('span');
        inner.className = 'kt-inner';
        inner.textContent = ch === ' ' ? '\u00A0' : ch;
        c.appendChild(inner);
        word.appendChild(c);
        chars.push(c);
        inners.push(inner);
    });
    const flare = document.createElement('span');
    flare.className = 'kt-flare';
    flare.setAttribute('aria-hidden', 'true');
    const sparks = Array.from({ length: 18 }, () => {
        const s = document.createElement('span');
        s.className = 'kt-spark';
        s.setAttribute('aria-hidden', 'true');
        return s;
    });
    element.append(rail, glow, word, flare, ...sparks);
    element.classList.add('kt-ready');

    if (typeof gsap === 'undefined') {
        element.classList.add('kt-in', 'kt-done');
        return;
    }

    // --- 1. Вход: буквы поднимаются из-под линии с 3D-разворотом и расфокусом ---
    const mid = (inners.length - 1) / 2;
    gsap.timeline({ delay: 0.25 })
        .fromTo(inners,
            {
                yPercent: 118,
                rotationX: -85,
                rotationZ: (i) => (i - mid) * 7,
                scale: 0.86,
                opacity: 0,
                filter: 'blur(14px)',
                transformPerspective: 900
            },
            {
                yPercent: 0,
                rotationX: 0,
                rotationZ: 0,
                scale: 1,
                opacity: 1,
                filter: 'blur(0px)',
                duration: 1.5,
                ease: 'expo.out',
                stagger: 0.12,
                force3D: true,
                clearProps: 'filter'
            })
        .add(() => element.classList.add('kt-in'), 0.45)
        .add(() => element.classList.add('kt-done'));

    // --- 2. Скролл: кинематографичная сцена (scrub — полностью обратимо) ---
    if (typeof ScrollTrigger !== 'undefined') {
        initKineticScroll({ element, chars, glow, rail, flare, sparks, mid });
    }

    // --- 3. Лёгкий 3D-наклон надписи за курсором ---
    if (window.matchMedia('(hover: hover) and (pointer: fine)').matches) {
        gsap.set(word, { transformPerspective: 1000 });
        const rx = gsap.quickTo(word, 'rotationX', { duration: 0.9, ease: 'power3.out' });
        const ry = gsap.quickTo(word, 'rotationY', { duration: 0.9, ease: 'power3.out' });
        const tx = gsap.quickTo(word, 'x', { duration: 0.9, ease: 'power3.out' });
        element.addEventListener('pointermove', (e) => {
            const r = element.getBoundingClientRect();
            const px = (e.clientX - r.left) / r.width - 0.5;
            const py = (e.clientY - r.top) / r.height - 0.5;
            ry(px * 16);
            rx(-py * 12);
            tx(px * 10);
        });
        element.addEventListener('pointerleave', () => { rx(0); ry(0); tx(0); });
    }
}

function initBouncingText() {
    const textEl = document.getElementById('endBncText');
    if (!textEl) return;

    const text = textEl.textContent.trim();
    textEl.innerHTML = '';
    const fragment = document.createDocumentFragment();

    const spans = text.split('').map(char => {
        const span = document.createElement('span');
        span.textContent = char === ' ' ? '\u00A0' : char;
        span.style.willChange = 'transform, opacity';
        fragment.appendChild(span);

        span.addEventListener('mouseenter', () => {
            gsap.to(span, { y: -10, scale: 1.1, color: '#fff', duration: 0.4, ease: "back.out(2)" });
        });
        span.addEventListener('mouseleave', () => {
            gsap.to(span, { y: 0, scale: 1, color: '#fff', duration: 0.6, ease: "elastic.out(1, 0.3)" });
        });
        return span;
    });
    textEl.appendChild(fragment);

    // Кинетическая анимация появления: разлет из центра с 3D эффектом
    gsap.fromTo(spans,
        {
            y: 150,
            opacity: 0,
            scale: 0,
            rotateX: -100,
            rotateY: 30,
            filter: "blur(20px)"
        },
        {
            scrollTrigger: {
                trigger: textEl,
                start: "top 90%",
                toggleActions: "restart none none restart"
            },
            y: 0, opacity: 1, scale: 1, rotateX: 0, rotateY: 0,
            filter: "blur(0px)",
            stagger: {
                each: 0.07,
                from: "center"
            },
            duration: 2,
            ease: "expo.out",
            force3D: true
        }
    );
}

// Инициализация при загрузке страницы
// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    // Безопасная инициализация GSAP и Lenis
    if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
        gsap.registerPlugin(ScrollTrigger);

        if (typeof Lenis !== 'undefined') {
            window.lenis = new Lenis({
                duration: 1.5,
                lerp: 0.07,
                smoothWheel: true
            });

            window.lenis.on('scroll', ScrollTrigger.update);
            gsap.ticker.add((time) => {
                window.lenis.raf(time * 1000);
            });
            gsap.ticker.lagSmoothing(0);
            window.lenis.start();
        }
    }

    // Hero-надпись и Bento запускаем сразу, не дожидаясь загрузки данных —
    // иначе «BNC» сначала мигал статичным текстом, а карточки ждали Supabase.
    if (typeof gsap !== 'undefined') animateKineticTitle(document.getElementById('siteTitleLarge'));
    initBentoCounters();

    // --- Эффекты параллакса (Глубина сайта) ---

    // Параллакс для Hero Section (текст уходит медленнее)
    if (document.querySelector('.hero-section')) {
        gsap.to(".hero-section", {
            yPercent: 20,
            ease: "none",
            scrollTrigger: {
                trigger: ".hero-section",
                start: "top top",
                end: "bottom top",
                scrub: true
            }
        });
    }


    // Magnetic Effect для премиальных иконок футера
    document.querySelectorAll('.magnetic').forEach(el => {
        el.addEventListener('mousemove', function (e) {
            const pos = el.getBoundingClientRect();
            const mx = e.clientX - pos.left - pos.width / 2;
            const my = e.clientY - pos.top - pos.height / 2;

            gsap.to(el, {
                x: mx * 0.45,
                y: my * 0.45,
                duration: 0.3,
                ease: "power2.out"
            });

            gsap.to(el.querySelector('svg'), {
                x: mx * 0.15,
                y: my * 0.15,
                duration: 0.3,
                ease: "power2.out"
            });
        });

        el.addEventListener('mouseleave', function () {
            gsap.to([el, el.querySelector('svg')], {
                x: 0,
                y: 0,
                duration: 0.7,
                ease: "elastic.out(1, 0.3)"
            });
        });
    });

    // Reveal анимация для футера
    gsap.fromTo("footer .footer-container", {
        y: 60,
        opacity: 0
    }, {
        scrollTrigger: {
            trigger: "footer",
            start: "top 95%",
            toggleActions: "play none none none"
        },
        y: 0,
        opacity: 1,
        duration: 0.8,
        ease: "power2.out"
    });

    // Запускаем асинхронные операции после инициализации Lenis
    (async () => {
        try {
            // Инициализация видео-скролла
            const video = document.getElementById('scrollVideo');
            if (video) {
                const initVideoScroll = () => {
                    if (video.dataset.initialized) return;
                    video.dataset.initialized = "true";

                    const loader = document.getElementById('videoLoader');
                    if (loader) gsap.to(loader, { opacity: 0, duration: 0.5, onComplete: () => loader.style.display = 'none' });

                    // Прокси-объект для оптимизации: анимируем число, а не напрямую currentTime
                    const videoProxy = { time: 0 };
                    const videoDuration = video.duration || 5;

                    const tl = gsap.timeline({
                        scrollTrigger: {
                            trigger: ".video-pin-section",
                            start: "top top",
                            end: "+=3000",
                            pin: true,
                            scrub: 2, // Увеличиваем плавность для видео, чтобы скрыть рывки декодера
                            invalidateOnRefresh: true,
                            onToggle: self => {
                                // Ставим видео на паузу, когда оно не в зоне видимости
                                if (!self.isActive) video.pause();
                            }
                        }
                    });

                    tl.fromTo(video, { opacity: 0 }, { opacity: 1, duration: 1 }, 0);

                    tl.to(videoProxy, {
                        time: videoDuration,
                        duration: 4,
                        ease: "none",
                        onUpdate: () => {
                            // Округляем до 3 знаков, чтобы не дергать декодер на наносекунды
                            // и проверяем, не слишком ли быстро идет обновление
                            if (video.readyState >= 2) {
                                video.currentTime = Math.round(videoProxy.time * 1000) / 1000;
                            }
                        }
                    }, 0);

                    // Плавное исчезновение (конец скролла)
                    tl.to(video, { opacity: 0, duration: 1 }, 3);

                    ScrollTrigger.refresh();
                };

                video.addEventListener('loadedmetadata', initVideoScroll);
                video.src = "assets/images/frames/Lucia Caminos Video Clip.mp4";
                if (video.readyState >= 1) initVideoScroll();
                video.addEventListener('error', () => {
                    const loader = document.getElementById('videoLoader');
                    if (loader) loader.innerHTML = '<p style="color:#ef4444; font-size: 0.8rem;">Видео не найдено</p>';
                });
            }

            // Данные и брендинг грузим ПАРАЛЛЕЛЬНО (а не по очереди) — иначе
            // страница визуально «прогружалась» дважды: сначала контент,
            // потом фон брендинга. Плюс защита от «зависшего» запроса.
            await Promise.race([
                Promise.all([
                    fetchContent(),
                    window.location.pathname.includes('minecraft.html') ? initBranding() : Promise.resolve()
                ]),
                new Promise(resolve => setTimeout(resolve, 5000))
            ]);
        } catch (e) {
            console.error("Content loading failed", e);
        } finally {
            siteInitializationFinished = true;
            const path = window.location.pathname;
            if (path.includes('minecraft.html')) currentCategory = 'minecraft';
            else if (path.includes('utils.html')) currentCategory = 'utils';

            if (bookGrid) renderBooks();
            if (utilsGrid) renderUtils(); // Выполняем рендер, только если есть utilsGrid
            animateCardsIn(); // Сразу анимируем появление карточек (без отдельной фазы подгрузки)
            initLuxuryLogic();

            // Показываем body. ВАЖНО: не запускаем повторный fade-in, если
            // страница уже видима — иначе получалось «двойное появление».
            const alreadyVisible = document.documentElement.classList.contains('site-ready')
                || parseFloat(getComputedStyle(document.body).opacity) > 0.9;

            document.body.style.opacity = '1';
            document.body.style.overflow = '';
            document.body.classList.remove('modal-open');
            document.documentElement.classList.remove('js-loading');
            if (typeof window.markSiteReady === 'function') window.markSiteReady();
            if (window.lenis) window.lenis.start();

            if (typeof gsap !== 'undefined' && !alreadyVisible) {
                gsap.fromTo('body', { opacity: 0 }, {
                    opacity: 1,
                    duration: 0.6,
                    onComplete: () => {
                        document.body.style.overflow = '';
                        document.body.classList.remove('modal-open');
                        if (window.lenis) window.lenis.start();
                        ScrollTrigger.refresh();
                    }
                });
            } else {
                document.body.style.overflow = '';
                if (window.lenis) window.lenis.start();
                if (typeof ScrollTrigger !== 'undefined') ScrollTrigger.refresh();
            }

            const mainTitle = document.getElementById('siteTitleLarge');
            if (typeof gsap !== 'undefined') {
                // Логика плавного исчезновения при переходе
                document.addEventListener('click', (e) => {
                    const link = e.target.closest('a');
                    if (!link) return;

                    const href = link.getAttribute('href');
                    const isInternal = href && !href.startsWith('#') && !href.startsWith('mailto:') && link.hostname === window.location.hostname;
                    const isStandard = !link.getAttribute('target') || link.getAttribute('target') === '_self';

                    if (isInternal && isStandard) {
                        e.preventDefault();
                        gsap.to('body', {
                            opacity: 0,
                            y: -20,
                            duration: 0.5,
                            ease: "power2.inOut",
                            onComplete: () => { window.location.href = href; }
                        });
                    }
                });

                // 1. Анимируем главный заголовок (по буквам)
                if (mainTitle) animateKineticTitle(mainTitle);

                // Инициализируем прыгающий текст здесь, когда всё содержимое уже на странице
                // initBouncingText(); // Отключено по запросу

                ScrollTrigger.refresh(); // Принудительно обновляем расчеты после рендеринга

                setupSupportModal(); // Инициализируем логику модального окна поддержки
                setupDonateModal(); // Инициализируем логику модального окна донатов

                const closeSupport = document.getElementById('closeSupport');
                if (closeSupport) closeSupport.onclick = closeSupportModal;

                // 2. Каскадное появление остального контента (только если элементы есть на странице)
                const targets = document.querySelectorAll(".view-switcher, #backBtn, .category-filters .category-btn, .category-block");

                if (targets.length > 0) {
                    gsap.fromTo(targets,
                        { y: 100, opacity: 0, scale: 0.92, rotateX: -20 },
                        {
                            y: 0,
                            opacity: 1,
                            scale: 1,
                            rotateX: 0,
                            duration: 1.8,
                            stagger: {
                                amount: 0.5,
                                from: "start"
                            },
                            ease: "expo.out",
                            delay: 0.6,
                            force3D: true,
                            onComplete: function () {
                                this.targets().forEach(el => {
                                    if (el.classList.contains('reveal')) el.classList.add('reveal-visible');
                                });
                                gsap.set(this.targets(), { clearProps: "transform,opacity" });
                            }
                        }
                    );
                }
            }
        }
    })();
});
