﻿const SUPABASE_URL = "https://anojurewqrimvgufbpcp.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFub2p1cmV3cXJpbXZndWZicGNwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg1NjcyMTAsImV4cCI6MjA5NDE0MzIxMH0.GA7llpmGPLXECazIAWeVUVXui79Lqwi5vq75pmWfF1k";

const CONFIG = {
    ADMIN_UID: "e1e2b293-fb97-47a5-95d1-84aef4ddcbd0",
    IS_PRODUCTION: window.location.hostname !== 'localhost' && window.location.hostname !== '127.0.0.1'
};

/**
 * Единый клиент Supabase для всех страниц сайта.
 *
 * Опции auth важны для стабильной работы сессии и счетчиков:
 *  - persistSession   — сессия сохраняется в localStorage и переживает перезагрузку;
 *  - autoRefreshToken — токен продлевается в фоне, запросы к БД не падают с 401;
 *  - detectSessionInUrl — корректный вход через OAuth (Google/Discord) по редиректу;
 *  - storageKey       — фиксированный ключ, чтобы все вкладки видели одну сессию.
 */
window.supabaseClient = null;

if (typeof supabase !== 'undefined' && supabase && typeof supabase.createClient === 'function') {
    window.supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
        auth: {
            persistSession: true,
            autoRefreshToken: true,
            detectSessionInUrl: true,
            storageKey: 'bnc-auth-token',
            flowType: 'pkce'
        }
    });
} else {
    // Если CDN-библиотека не загрузилась (блокировка/сбой сети), сайт всё
    // равно продолжает работать: контент покажется из кэша, а не упадёт с ошибкой.
    console.error('Библиотека Supabase не загружена. Данные и счётчики будут недоступны, пока CDN не восстановится.');
}