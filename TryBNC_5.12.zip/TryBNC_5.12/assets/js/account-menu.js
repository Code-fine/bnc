﻿/* ============================================================
   Выпадающее меню аккаунта в шапке (Аккаунт / Профиль / Выйти)
   ============================================================ */
(function () {
    'use strict';

    function initAccountMenu() {
        var wrap = document.getElementById('headerAccount');
        var btn = document.getElementById('headerAvatarBtn');
        var dropdown = document.getElementById('accountDropdown');
        if (!wrap || !btn || !dropdown) return;

        function openMenu() {
            dropdown.classList.add('open');
            dropdown.setAttribute('aria-hidden', 'false');
            btn.setAttribute('aria-expanded', 'true');
        }

        function closeMenu() {
            dropdown.classList.remove('open');
            dropdown.setAttribute('aria-hidden', 'true');
            btn.setAttribute('aria-expanded', 'false');
        }

        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            // На всех страницах аватарка открывает выпадающее меню
            // (Профиль → личный кабинет, Выйти). Без автоматического перехода.
            if (dropdown.classList.contains('open')) closeMenu();
            else openMenu();
        });

        document.addEventListener('click', function (e) {
            if (!wrap.contains(e.target)) closeMenu();
        });

        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') closeMenu();
        });

        var profile = document.getElementById('adProfile');
        if (profile) {
            profile.addEventListener('click', function () {
                closeMenu();
                // Если это ссылка (<a href="account.html">) — пусть браузер сам перейдёт.
                // Оверлей-дашборд открываем только для кнопок (обратная совместимость).
                if (profile.tagName === 'A') return;
                if (typeof window.openProfileDashboard === 'function') window.openProfileDashboard();
            });
        }

        var logout = document.getElementById('adLogout');
        if (logout) {
            logout.addEventListener('click', function () {
                closeMenu();
                var realLogout = document.getElementById('logout-btn');
                if (realLogout) realLogout.click();
                else if (window.supabaseClient) {
                    try {
                        localStorage.removeItem('bnc_tracked_user');
                        localStorage.removeItem('bnc_last_seconds');
                        localStorage.removeItem('bnc_last_downloads');
                    } catch (e) { }
                    window.supabaseClient.auth.signOut().then(function () { window.location.reload(); });
                }
            });
        }

        /* Обновление данных в шапке меню */
        window.syncAccountMenu = function (user) {
            user = user || window.currentUser;
            var nameEl = document.getElementById('adName');
            var initialsEl = document.getElementById('headerAvatarInitials');

            var customName = user && user.profile && user.profile.display_name;
            var raw = customName || (user && user.user_metadata && (user.user_metadata.full_name || user.user_metadata.name)) || '';
            var display = raw || 'Пользователь';
            if (!customName) display = display.charAt(0).toUpperCase() + display.slice(1);

            if (nameEl) nameEl.textContent = display;
            if (initialsEl) {
                initialsEl.textContent = (String(display).replace(/[^\p{L}\p{N}]/gu, '').slice(0, 2) || '?').toUpperCase();
            }
        };
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAccountMenu);
    } else {
        initAccountMenu();
    }
})();
