﻿/**
 * router.js - Простой клиентский SPA-роутер для админ-панели
 */
document.addEventListener('DOMContentLoaded', () => {
    // Проверка, что Supabase клиент инициализирован
    if (typeof supabaseClient === 'undefined') {
        console.error("Supabase client is not initialized. Make sure config.js is loaded correctly.");
        document.body.innerHTML = '<div class="h-screen flex items-center justify-center bg-red-100 text-red-800">Ошибка: Клиент Supabase не найден. Проверьте config.js.</div>';
        return;
    }

    const mainContent = document.getElementById('main-content');
    const mainNav = document.getElementById('main-nav');
    const breadcrumb = document.getElementById('breadcrumb');
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebar-overlay');

    // --- Определение маршрутов и их связи с функциями рендеринга ---
    const routes = {
        'content': {
            title: 'Управление контентом',
            icon: 'fas fa-database',
            render: () => window.admin.renderContentManager(),
        },
        'support': {
            title: 'Сообщения поддержки',
            icon: 'fas fa-headset',
            render: () => window.admin.renderSupportView(),
        },
        'branding': {
            title: 'Брендирование',
            icon: 'fas fa-ad',
            render: () => window.admin.renderBrandingManager(),
        },
        'settings': {
            title: 'Настройки',
            icon: 'fas fa-cog',
            render: () => mainContent.innerHTML = `<h1 class="text-2xl font-bold">Настройки</h1><p>Этот раздел в разработке.</p>`,
        }
    };

    // --- Основная функция роутера ---
    const navigate = async (path) => {
        // Проверка авторизации и прав администратора
        const { data: { session } } = await supabaseClient.auth.getSession();
        if (!session || session.user.id !== CONFIG.ADMIN_UID) {
            window.location.href = 'login.html'; // Редирект на страницу входа
            return;
        }

        // Скрываем мобильный сайдбар при навигации
        if (sidebar.classList.contains('translate-x-0')) {
            toggleSidebar();
        }

        // Устанавливаем путь по умолчанию
        if (!routes[path]) {
            path = 'content';
        }

        // Обновляем URL
        window.history.pushState({}, '', `#${path}`);

        // Обновляем UI
        updateActiveLink(path);
        updateBreadcrumb(path);

        // Очищаем и рендерим новый контент
        mainContent.innerHTML = '<div class="text-center p-8"><i class="fas fa-spinner fa-spin text-2xl text-primary"></i></div>';
        try {
            await routes[path].render();
        } catch (error) {
            console.error(`Error rendering path #${path}:`, error);
            mainContent.innerHTML = `<div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                <strong class="font-bold">Ошибка!</strong>
                <span class="block sm:inline">Не удалось загрузить раздел. Подробности в консоли.</span>
            </div>`;
        }
    };

    // --- Вспомогательные функции ---
    const generateNav = () => {
        mainNav.innerHTML = Object.keys(routes).map(path => `
            <a href="#${path}" data-path="${path}" class="nav-link group flex items-center gap-3 px-4 py-3 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all duration-300 relative overflow-hidden">
                <div class="absolute inset-0 bg-indigo-50 dark:bg-indigo-500/10 opacity-0 group-[.active]:opacity-100 transition-opacity duration-300"></div>
                <div class="relative flex items-center gap-3 w-full">
                    <div class="w-9 h-9 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center group-hover:bg-slate-200 dark:group-hover:bg-slate-700 transition-all">
                        <i class="${routes[path].icon} text-gray-500"></i>
                    </div>
                    <span class="font-medium relative">${routes[path].title}</span>
                </div>
            </a>
        `).join('');
    };

    const updateActiveLink = (path) => {
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.toggle('active', link.dataset.path === path);
            link.classList.toggle('text-indigo-600', link.dataset.path === path);
            link.classList.toggle('dark:text-indigo-400', link.dataset.path === path);
        });
    };

    const updateBreadcrumb = (path) => {
        breadcrumb.innerHTML = `
            <a href="#" class="hover:text-primary">Панель</a>
            <span class="mx-2">/</span>
            <span>${routes[path].title}</span>
        `;
    };

    const toggleSidebar = () => {
        sidebar.classList.toggle('-translate-x-full');
        sidebarOverlay.classList.toggle('hidden');
    };

    const updateThemeIconAdmin = (isDark) => {
        const sunPaths = document.querySelectorAll('#theme-icon-admin .sun-path');
        const moonPath = document.querySelector('#theme-icon-admin .moon-path');
        if (sunPaths.length > 0 && moonPath) {
            sunPaths.forEach(p => p.style.display = isDark ? 'none' : 'block');
            moonPath.style.display = isDark ? 'block' : 'none';
        }
    };

    const toggleTheme = () => {
        document.documentElement.classList.toggle('dark');
        const isDark = document.documentElement.classList.contains('dark');
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
        updateThemeIconAdmin(isDark);
    };

    const logout = async () => {
        // При выходе очищаем кэш, чтобы на главной странице не было старых данных
        sessionStorage.removeItem('bnc_content_cache');
        await supabaseClient.auth.signOut();
        window.location.href = 'index.html';
    };

    // --- Инициализация ---
    // Применяем сохраненную тему
    if (localStorage.getItem('theme') === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        document.documentElement.classList.add('dark');
        updateThemeIconAdmin(true);
    } else {
        document.documentElement.classList.remove('dark');
    }

    // Генерируем навигацию
    generateNav();

    // Привязываем глобальную кнопку добавления
    const addContentBtn = document.getElementById('add-content-header-btn');
    if (addContentBtn) {
        addContentBtn.addEventListener('click', () => window.admin.renderContentForm());
    }
    // Навешиваем обработчики
    window.addEventListener('hashchange', () => navigate(window.location.hash.substring(1)));
    mainNav.addEventListener('click', (e) => {
        const link = e.target.closest('.nav-link');
        if (link) {
            e.preventDefault();
            navigate(link.dataset.path);
        }
    });

    // Экспортируем функции в глобальный объект для доступа из HTML
    window.router = {
        navigate,
        toggleSidebar,
        toggleTheme,
        logout
    };

    // Первоначальная загрузка
    navigate(window.location.hash.substring(1) || 'content');
});