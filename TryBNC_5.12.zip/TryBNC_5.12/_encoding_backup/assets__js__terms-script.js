﻿/**
 * terms-script.js
 * Облегченная версия основного скрипта для простых страниц, таких как terms.html.
 * Содержит только базовую логику для шапки, подвала и переключения темы.
 */

document.addEventListener('DOMContentLoaded', () => {
    // Безопасная инициализация GSAP и Lenis
    if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
        gsap.registerPlugin(ScrollTrigger);

        if (typeof Lenis !== 'undefined') {
            window.lenis = new Lenis({
                duration: 1.5,
                lerp: 0.07,
                smoothWheel: true
            });

            window.lenis.on('scroll', ScrollTrigger.update);
            gsap.ticker.add((time) => {
                window.lenis.raf(time * 1000);
            });
            gsap.ticker.lagSmoothing(0);
        }
    }

    // --- Базовая логика ---

    // 1. Переключатель темы
    const updateThemeIcon = (isDark) => {
        const sunPaths = document.querySelectorAll('#theme-icon .sun-path');
        const moonPath = document.querySelector('#theme-icon .moon-path');
        if (sunPaths.length > 0 && moonPath) {
            sunPaths.forEach(p => p.style.display = isDark ? 'none' : 'block');
            moonPath.style.display = isDark ? 'block' : 'none';
        }
    };

    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            document.body.classList.toggle('dark-theme');
            const isDark = document.body.classList.contains('dark-theme');
            localStorage.setItem('theme', isDark ? 'dark' : 'light');
            updateThemeIcon(isDark);
        });

        // Проверка сохраненной темы. По умолчанию тема темная.
        if (localStorage.getItem('theme') === 'light') {
            document.body.classList.remove('dark-theme');
        }
        // Обновляем иконку при загрузке.
        updateThemeIcon(document.body.classList.contains('dark-theme'));
    }

    // 2. Прогресс-бар
    const progressBar = document.querySelector('.progress-bar');
    if (progressBar) {
        window.addEventListener('scroll', () => {
            const winScroll = window.scrollY;
            const height = document.documentElement.scrollHeight - window.innerHeight;
            const scrolled = (winScroll / height) * 100;
            progressBar.style.width = scrolled + '%';
        });
    }

    // 3. Эффект "прилипания" шапки при скролле
    const header = document.querySelector('header');
    if (header && typeof ScrollTrigger !== 'undefined') {
        ScrollTrigger.create({
            start: "top -20",
            onUpdate: (self) => {
                header.classList.toggle('header-scrolled', self.direction > 0 || self.scroll() > 20);
            }
        });
    }

    // 4. Логика для кнопки "наверх" (если она будет добавлена)
    // ...

    // 5. Плавное появление страницы
    if (typeof gsap !== 'undefined') {
        gsap.to('body', {
            opacity: 1,
            duration: 0.6,
            delay: 0.1, // Меньше задержка, т.к. нет тяжелого контента
            onComplete: () => {
                document.body.style.overflow = '';
                if (typeof ScrollTrigger !== 'undefined') {
                    ScrollTrigger.refresh();
                }
            }
        });

        // Плавное исчезновение при переходе по ссылкам
        document.addEventListener('click', (e) => {
            const link = e.target.closest('a');
            const href = link?.getAttribute('href');
            if (link && href && !href.startsWith('#') && !href.startsWith('mailto:') && link.hostname === window.location.hostname && !link.target) {
                e.preventDefault();
                gsap.to('body', { opacity: 0, duration: 0.4, ease: "power1.in", onComplete: () => window.location.href = href });
            }
        });
    }
});