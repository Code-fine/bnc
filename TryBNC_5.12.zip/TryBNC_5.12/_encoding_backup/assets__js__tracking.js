﻿let timeTrackerInterval = null;
let localTotalSeconds = 0;
let uiUpdateInterval = null;

window.renderProfileStats = function(totalSeconds, totalDownloads) {
    if (totalSeconds !== undefined) {
        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const timeElement = document.getElementById('user-time');
        if (timeElement) timeElement.textContent = `${hours} ч. ${minutes} мин.`;
    }

    if (totalDownloads !== undefined) {
        const downloadElement = document.getElementById('user-downloads');
        if (downloadElement) downloadElement.textContent = String(totalDownloads);
    }
};

async function updateDbTime(userId) {
    const { data, error } = await supabaseClient
        .from('profiles')
        .select('total_seconds')
        .eq('id', userId)
        .single();

    if (!error && data) {
        const newSeconds = (data.total_seconds || 0) + 60;
        await supabaseClient
            .from('profiles')
            .update({ total_seconds: newSeconds })
            .eq('id', userId);
        renderProfileStats(newSeconds);
    }
}

function startTrackingTime(userId) {
    if (timeTrackerInterval) clearInterval(timeTrackerInterval);
    // Унифицированный интервал для всех страниц (раз в минуту в БД)
    timeTrackerInterval = setInterval(() => updateDbTime(userId), 60000);
    
    // Локальный счетчик для страниц без детального профиля (как было в minecraft.html)
    if (uiUpdateInterval) clearInterval(uiUpdateInterval);
    uiUpdateInterval = setInterval(() => {
        localTotalSeconds++;
    }, 1000);
}

function stopTrackingTime() {
    if (timeTrackerInterval) {
        clearInterval(timeTrackerInterval);
        timeTrackerInterval = null;
    }
    if (uiUpdateInterval) {
        clearInterval(uiUpdateInterval);
        uiUpdateInterval = null;
    }
    localTotalSeconds = 0;
}

async function initUserTimeTracking(user) {
    if (!user) {
        stopTrackingTime();
        return;
    }
    const { data: profile, error } = await supabaseClient
        .from('profiles')
        .select('total_seconds, total_downloads, email')
        .eq('id', user.id)
        .single();

    if (!error && profile) {
        localTotalSeconds = profile.total_seconds || 0;
        renderProfileStats(profile.total_seconds || 0, profile.total_downloads || 0);
        startTrackingTime(user.id);
    } else {
        console.error("Профиль не найден или ошибка доступа:", error);
    }
}

window.initUserTimeTracking = initUserTimeTracking;
window.stopTrackingTime = stopTrackingTime;