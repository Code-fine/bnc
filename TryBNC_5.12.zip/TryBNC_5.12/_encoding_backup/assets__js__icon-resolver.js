﻿// ============================================================
//  РЕЗОЛВЕР ИКОНОК ПРОГРАММ (BNC)
//  Автоматически подбирает иконку для программы в разделе «Утилиты».
//
//  Порядок поиска иконки:
//    1. Ручная иконка из БД (file.icon / link.icon) — если задана.
//    2. Известный реестр программ по названию (Windows, Steam, Discord, ...).
//    3. Favicon сайта из ссылки на скачивание.
//    4. Нейтральная заглушка «приложение».
// ============================================================
(function () {
    'use strict';

    // --- Заглушка: нейтральная иконка приложения (SVG в base64) ---
    const GENERIC_APP_ICON =
        'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9IiM5NGEzYjgiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj48cmVjdCB4PSIyIiB5PSIyIiB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHJ4PSI1Ii8+PHBhdGggZD0iTTEyIDh2OG0tNC00aDgiLz48L3N2Zz4=';

    // CDN с логотипами программ: https://cdn.simpleicons.org/<slug>/<hexColor>
    // Для брендов, которых нет в Simple Icons (Microsoft/Adobe),
    // используются локальные SVG из assets/images/iconutill/.

    /**
     * Реестр известных программ.
     * key    — В«slugВ» программы (для статистики/отладки)
     * match  — список подстрок (в нижнем регистре), по которым узнаём программу в названии
     * icon   — URL иконки: локальный файл из assets/images/iconutill/ или CDN
     */
    const KNOWN_APPS = [
        // ОС и системные
        { key: 'windows', match: ['windows', 'виндовс', 'win 10', 'win 11', 'win10', 'win11'], icon: 'assets/images/iconutill/brand-windows.svg' },
        { key: 'linux', match: ['linux', 'линукс', 'ubuntu', 'mint'], icon: 'https://cdn.simpleicons.org/linux/FCC624' },
        { key: 'macos', match: ['macos', 'mac os', 'macintosh'], icon: 'https://cdn.simpleicons.org/apple/000000' },
        { key: 'android', match: ['android', 'андроид'], icon: 'https://cdn.simpleicons.org/android/3DDC84' },

        // Браузеры
        { key: 'chrome', match: ['chrome', 'хром', 'гугл хром'], icon: 'https://cdn.simpleicons.org/googlechrome/4285F4' },
        { key: 'firefox', match: ['firefox', 'фаерфокс', 'файрфокс', 'мозила', 'mozilla'], icon: 'https://cdn.simpleicons.org/firefox/FF7139' },
        { key: 'edge', match: ['edge', 'эдж', 'microsoft edge'], icon: 'assets/images/iconutill/brand-edge.svg' },
        { key: 'opera', match: ['opera', 'опера'], icon: 'https://cdn.simpleicons.org/opera/FF1B2D' },
        { key: 'brave', match: ['brave', 'брейв'], icon: 'https://cdn.simpleicons.org/brave/FB542B' },
        { key: 'vivaldi', match: ['vivaldi'], icon: 'https://cdn.simpleicons.org/vivaldi/EF3939' },
        { key: 'yandex', match: ['yandex', 'яндекс'], icon: 'assets/images/iconutill/brand-yandex.svg' },

        // Мессенджеры и связь
        { key: 'discord', match: ['discord', 'дискорд'], icon: 'https://cdn.simpleicons.org/discord/5865F2' },
        { key: 'telegram', match: ['telegram', 'телеграм', 'телеграмм', 'tg'], icon: 'https://cdn.simpleicons.org/telegram/26A5E4' },
        { key: 'whatsapp', match: ['whatsapp', 'ватсап', 'вотсап'], icon: 'https://cdn.simpleicons.org/whatsapp/25D366' },
        { key: 'skype', match: ['skype', 'скайп'], icon: 'assets/images/iconutill/brand-skype.svg' },
        { key: 'zoom', match: ['zoom', 'зум'], icon: 'https://cdn.simpleicons.org/zoom/0B5CFF' },
        { key: 'slack', match: ['slack'], icon: 'assets/images/iconutill/brand-slack.svg' },

        // Игры и платформы
        { key: 'steam', match: ['steam', 'стим'], icon: 'assets/images/iconutill/Steam-366e162ab72bf4750858a9a62e4de040.png' },
        { key: 'epicgames', match: ['epic games', 'epic', 'эпик'], icon: 'https://cdn.simpleicons.org/epicgames/313131' },
        { key: 'battlenet', match: ['battle.net', 'battlenet', 'батл'], icon: 'https://cdn.simpleicons.org/battledotnet/148EFF' },
        { key: 'gog', match: ['gog galaxy', 'gog'], icon: 'https://cdn.simpleicons.org/gogdotcom/86328A' },
        { key: 'playstation', match: ['playstation', 'плейстейшн'], icon: 'https://cdn.simpleicons.org/playstation/0070D1' },
        { key: 'roblox', match: ['roblox', 'роблокс'], icon: 'https://cdn.simpleicons.org/roblox/000000' },

        // Софт и утилиты
        { key: 'winrar', match: ['winrar', 'винрар', 'win rar'], icon: 'assets/images/iconutill/brand-winrar.svg' },
        { key: '7zip', match: ['7-zip', '7zip', '7 zip', '7z'], icon: 'https://cdn.simpleicons.org/7zip/000000' },
        { key: 'vlc', match: ['vlc', 'влс'], icon: 'https://cdn.simpleicons.org/vlcmediaplayer/FF8800' },
        { key: 'obs', match: ['obs studio', 'obs', 'обс'], icon: 'https://cdn.simpleicons.org/obsstudio/302E31' },
        { key: 'notepad', match: ['notepad++', 'notepad', 'нотепад', 'блокнот'], icon: 'https://cdn.simpleicons.org/notepadplusplus/90E59A' },
        { key: 'sublime', match: ['sublime text', 'sublime', 'саблайм'], icon: 'https://cdn.simpleicons.org/sublimetext/FF9800' },
        { key: 'vscode', match: ['visual studio code', 'vs code', 'vscode', 'вс код'], icon: 'assets/images/iconutill/brand-vscode.svg' },
        { key: 'photoshop', match: ['photoshop', 'фотошоп', 'adobe photoshop'], icon: 'assets/images/iconutill/brand-photoshop.svg' },
        { key: 'illustrator', match: ['illustrator', 'иллюстратор'], icon: 'assets/images/iconutill/brand-illustrator.svg' },
        { key: 'premiere', match: ['premiere', 'премьер'], icon: 'assets/images/iconutill/brand-premiere.svg' },
        { key: 'blender', match: ['blender', 'блендер'], icon: 'https://cdn.simpleicons.org/blender/E87D0D' },
        { key: 'figma', match: ['figma', 'фигма'], icon: 'https://cdn.simpleicons.org/figma/F24E1E' },
        { key: 'gimp', match: ['gimp', 'гимп'], icon: 'https://cdn.simpleicons.org/gimp/5C5543' },
        { key: 'krita', match: ['krita', 'крита'], icon: 'https://cdn.simpleicons.org/krita/3DAB3D' },
        { key: 'notion', match: ['notion', 'ношн'], icon: 'https://cdn.simpleicons.org/notion/000000' },
        { key: 'office', match: ['microsoft office', 'ms office', 'офис', 'ms office'], icon: 'assets/images/iconutill/brand-office.svg' },
        { key: 'word', match: ['microsoft word', 'word', 'ворд'], icon: 'assets/images/iconutill/brand-word.svg' },
        { key: 'excel', match: ['microsoft excel', 'excel', 'эксель'], icon: 'assets/images/iconutill/brand-excel.svg' },
        { key: 'powerpoint', match: ['powerpoint', 'повер поинт', 'паверпоинт'], icon: 'assets/images/iconutill/brand-powerpoint.svg' },
        { key: 'onedrive', match: ['onedrive', 'ван драйв'], icon: 'assets/images/iconutill/brand-onedrive.svg' },
        { key: 'googledrive', match: ['google drive', 'гугл диск', 'gdrive'], icon: 'https://cdn.simpleicons.org/googledrive/4285F4' },
        { key: 'dropbox', match: ['dropbox', 'дропбокс'], icon: 'https://cdn.simpleicons.org/dropbox/0061FF' },
        { key: 'torrent', match: ['utorrent', 'torrent', 'торрент', 'битторрент', 'bittorrent', 'qbit', 'qbittorrent'], icon: 'https://cdn.simpleicons.org/qbittorrent/2F67BA' },

        // Облака/Google-сервисы (для таблиц и документов)
        { key: 'google', match: ['google', 'гугл'], icon: 'https://cdn.simpleicons.org/google/4285F4' },

        // Железо и драйверы
        { key: 'nvidia', match: ['nvidia', 'нвидиа', 'geforce'], icon: 'https://cdn.simpleicons.org/nvidia/76B900' },
        { key: 'amd', match: ['amd', 'амуде', 'radeon'], icon: 'https://cdn.simpleicons.org/amd/ED1C24' },
        { key: 'intel', match: ['intel', 'интел'], icon: 'https://cdn.simpleicons.org/intel/0071C5' },
        { key: 'rustdesk', match: ['rustdesk', 'растдеск'], icon: 'https://cdn.simpleicons.org/rustdesk/0058A9' },
        { key: 'anydesk', match: ['anydesk', 'анидеск'], icon: 'https://cdn.simpleicons.org/anydesk/EF443B' },
        { key: 'teamviewer', match: ['teamviewer', 'тимвьюер'], icon: 'https://cdn.simpleicons.org/teamviewer/0E8EE9' },

        // Антивирусы
        { key: 'kaspersky', match: ['kaspersky', 'касперский', 'каспер'], icon: 'https://cdn.simpleicons.org/kaspersky/006D5C' },
        { key: 'avast', match: ['avast', 'аваст'], icon: 'https://cdn.simpleicons.org/avast/FF7800' },
        { key: 'malwarebytes', match: ['malwarebytes', 'малваребайтс'], icon: 'https://cdn.simpleicons.org/malwarebytes/0D3ECC' }
    ];

    /**
     * Пробует определить иконку по названию программы.
     * @param {string} name — название программы (любой язык)
     * @returns {string|null} — URL иконки или null
     */
    function findByKnownApp(name) {
        if (!name) return null;
        const n = String(name).toLowerCase();
        for (const app of KNOWN_APPS) {
            for (const needle of app.match) {
                if (n.includes(needle)) return app.icon;
            }
        }
        return null;
    }

    /**
     * Достаёт favicon из ссылки, если это сайт.
     * @param {string} url
     * @returns {string|null}
     */
    function faviconFromUrl(url) {
        if (!url || typeof url !== 'string' || url.startsWith('#')) return null;
        try {
            const domain = new URL(url).hostname;
            if (!domain) return null;
            // favicon самого download-домена часто бесполезен (облака/файлообменники),
            // поэтому в резолвере он идёт ПОСЛЕ реестра программ.
            return `https://www.google.com/s2/favicons?domain=${domain}&sz=64`;
        } catch (e) {
            return null;
        }
    }

    /**
     * Главная функция: вернуть лучшую иконку для файла-программы.
     * @param {object} file — элемент массива files (может содержать name, url, icon)
     * @returns {string} — URL иконки (никогда не пустой)
     */
    function resolveProgramIcon(file) {
        if (!file) return GENERIC_APP_ICON;

        // 1. Ручная иконка из БД
        let icon = typeof file.icon === 'string' ? file.icon.trim() : '';
        if (icon && icon !== 'excel') return icon;
        // Легаси-значение "excel" из старых записей
        if (icon === 'excel') return 'assets/images/iconutill/brand-excel.svg';

        // 2. Определяем программу по названию (name может быть строкой или {ru,en})
        const rawName = typeof file.name === 'object' && file.name !== null
            ? (file.name.ru || file.name.en || '')
            : (file.name || '');
        const known = findByKnownApp(rawName);
        if (known) return known;

        // 3. Favicon из ссылки
        const fav = faviconFromUrl(file.url);
        if (fav) return fav;

        // 4. Заглушка
        return GENERIC_APP_ICON;
    }

    // Экспорт в глобальную область (простой вариант без сборщика)
    window.BNCIcons = {
        resolveProgramIcon,
        findByKnownApp,
        GENERIC_APP_ICON,
        KNOWN_APPS
    };
})();
