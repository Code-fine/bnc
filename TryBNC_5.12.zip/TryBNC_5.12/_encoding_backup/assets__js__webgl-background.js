﻿/**
 * webgl-background.js - Liquid Gradient Background
 * Улучшенная версия: эффект искажения пространства и хроматическая аберрация при скролле.
 */

document.addEventListener('DOMContentLoaded', () => {
    if (typeof THREE === 'undefined') return;

    const canvas = document.getElementById('webgl-background-canvas');
    if (!canvas) return;

    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    const scene = new THREE.Scene();
    const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);

    const geometry = new THREE.PlaneGeometry(2, 2);

    const vertexShader = `
        varying vec2 vUv;
        void main() {
            vUv = uv;
            gl_Position = vec4(position, 1.0);
        }
    `;

    const fragmentShader = `
        uniform float uTime;
        uniform float uScrollVelocity;
        uniform vec2 uMouse;
        uniform vec3 uColorBg;
        uniform vec3 uColorSilk;
        uniform vec3 uColorAccent;
        uniform float uZoom;
        varying vec2 vUv;

        vec3 mod289(vec3 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
        vec2 mod289(vec2 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
        vec3 permute(vec3 x) { return mod289(((x*34.0)+1.0)*x); }

        vec3 saturate(vec3 rgb, float adjustment) {
            vec3 W = vec3(0.2125, 0.7154, 0.0721);
            vec3 intensity = vec3(dot(rgb, W));
            return mix(intensity, rgb, adjustment);
        }

        float snoise(vec2 v) {
            const vec4 C = vec4(0.211324865405187, 0.366025403784439, -0.577350269189626, 0.024390243902439);
            vec2 i  = floor(v + dot(v, C.yy) );
            vec2 x0 = v -   i + dot(i, C.xx);
            vec2 i1;
            i1 = (x0.x > x0.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
            vec4 x12 = x0.xyxy + C.xxzz;
            x12.xy -= i1;
            i = mod289(i);
            vec3 p = permute( permute( i.y + vec3(0.0, i1.y, 1.0 )) + i.x + vec3(0.0, i1.x, 1.0 ));
            vec3 m = max(0.5 - vec3(dot(x0,x0), dot(x12.xy,x12.xy), dot(x12.zw,x12.zw)), 0.0);
            m = m*m ;
            m = m*m ;
            vec3 x = 2.0 * fract(p * C.www) - 1.0;
            vec3 h = abs(x) - 0.5;
            vec3 a0 = x - floor(x + 0.5);
            vec3 g = a0 * vec3(m.x, m.y, m.z) + h * vec3(m.x, m.y, m.z);
            float n = 130.0 * dot(m, g);
            return n;
        }

        void main() {
            float vel = uScrollVelocity * 0.005;
            float warp = vel * 0.2;
            
            // Центрированный зум фона (масштабируем координаты относительно центра 0.5, 0.5)
            vec2 uv = (vUv - 0.5) * (1.0 / uZoom) + 0.5;
            
            // Креативное искажение пространства
            vec2 distortedUv = uv + snoise(uv * 1.5 + uTime * 0.05) * warp;
            
            // Честная хроматическая аберрация (смещение каналов)
            float shift = vel * 0.03;
            
            float r = snoise(distortedUv + vec2(shift, 0.0) + uTime * 0.05);
            float g = snoise(distortedUv + uTime * 0.05);
            float b = snoise(distortedUv - vec2(shift, 0.0) + uTime * 0.05);

            float n2 = snoise(distortedUv * 2.0 - uTime * 0.08);
            
            // Динамическая палитра "Шелковый зеленый"
            vec3 color = mix(uColorBg, uColorSilk, r * 0.5 + 0.5);
            color = mix(color, uColorAccent, b * 0.15); // Тонкие золотые вкрапления
            color += uColorSilk * (g * 0.1); // Мягкое свечение структуры шелка
            
            // Эффект инерции: повышение насыщенности при быстром скролле
            float saturationBoost = 1.0 + vel * 1.8;
            color = saturate(color, saturationBoost);
            
            // Добавляем свечение в центре мыши
            float mouseDist = distance(uv, uMouse);
            float mouseGlow = smoothstep(0.4, 0.0, mouseDist) * 0.15;
            color += uColorSilk * mouseGlow;

            gl_FragColor = vec4(color, 1.0);
        }
    `;

    const uniforms = {
        uTime: { value: 0 },
        uScrollVelocity: { value: 0 },
        uMouse: { value: new THREE.Vector2(0.5, 0.5) },
        uColorBg: { value: new THREE.Color('#0b0f09') },
        uColorSilk: { value: new THREE.Color('#141b11') },
        uColorAccent: { value: new THREE.Color('#e2be79') },
        uZoom: { value: 1.0 }
    };

    const material = new THREE.ShaderMaterial({
        vertexShader,
        fragmentShader,
        uniforms,
        transparent: true
    });

    const mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);

    // Делаем униформы доступными глобально для синхронизации со ScrollTrigger
    window.webglBackgroundUniforms = uniforms;

    // Синхронизация цветов WebGL с CSS-токенами
    function updateThemeColors(immediate = false) {
        const style = getComputedStyle(document.body);
        const getHex = (name) => style.getPropertyValue(name).trim();
        
        const bgHex = getHex('--bg-page');
        const silkHex = getHex('--bg-card');
        const accentHex = getHex('--accent-gold');

        if (!bgHex || !silkHex || !accentHex) return;

        const targetBg = new THREE.Color(bgHex);
        const targetSilk = new THREE.Color(silkHex);
        const targetAccent = new THREE.Color(accentHex);

        if (immediate || typeof gsap === 'undefined') {
            uniforms.uColorBg.value.copy(targetBg);
            uniforms.uColorSilk.value.copy(targetSilk);
            uniforms.uColorAccent.value.copy(targetAccent);
        } else {
            // Плавная GSAP анимация цветов униформов
            gsap.to(uniforms.uColorBg.value, { r: targetBg.r, g: targetBg.g, b: targetBg.b, duration: 1.2, ease: "power2.inOut" });
            gsap.to(uniforms.uColorSilk.value, { r: targetSilk.r, g: targetSilk.g, b: targetSilk.b, duration: 1.2, ease: "power2.inOut" });
            gsap.to(uniforms.uColorAccent.value, { r: targetAccent.r, g: targetAccent.g, b: targetAccent.b, duration: 1.2, ease: "power2.inOut" });
        }
    }

    // Обновляем при клике на переключатель темы
    document.addEventListener('click', (e) => {
        if (e.target.closest('#themeToggle')) {
            setTimeout(updateThemeColors, 50); // Небольшая задержка для смены класса
        }
    });

    updateThemeColors(true); // Инициализация при старте (без анимации)

    // Отслеживание мыши
    window.addEventListener('mousemove', (e) => {
        uniforms.uMouse.value.x = e.clientX / window.innerWidth;
        uniforms.uMouse.value.y = 1.0 - (e.clientY / window.innerHeight);
    });

    function animate(time) {
        requestAnimationFrame(animate);
        uniforms.uTime.value = time * 0.001;
        
        // Получаем скорость напрямую из Lenis (плавно)
        if (window.lenis) {
            const targetVel = Math.abs(window.lenis.velocity);
            uniforms.uScrollVelocity.value += (targetVel - uniforms.uScrollVelocity.value) * 0.1;
        }
        
        renderer.render(scene, camera);
    }

    window.addEventListener('resize', () => {
        renderer.setSize(window.innerWidth, window.innerHeight);
    });

    animate(0);
});