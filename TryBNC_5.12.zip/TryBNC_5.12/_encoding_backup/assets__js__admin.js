﻿/**
 * admin.js - Основная логика админ-панели BNC
 */

// --- Инициализация и проверка подключения к Supabase ---

// Конфигурация подключения к вашей базе данных
if (typeof supabase === 'undefined' && typeof window.supabase === 'undefined') {
    console.error("Критическая ошибка: библиотека Supabase JS не подключена в HTML!");
}

if (!window.supabaseClient) {
    window.supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
}
const supabaseClient = window.supabaseClient;

// --- Глобальное состояние и конфигурация ---
const adminState = {
    currentItem: null, // Хранит данные редактируемого элемента
    contentData: {},   // Кэш загруженного контента
    config: {
        allowedFileTypes: ['application/zip', 'application/x-rar-compressed', 'application/x-7z-compressed'],
        maxFileSize: 100 * 1024 * 1024, // 100 MB
        contentTypes: {
            'mods': 'Мод',
            'textures': 'Текстура',
            'shaders': 'Шейдер',
            'utils': 'Утилита',
            'maps': 'Карта',
            'minecraft_launchers': 'Лаунчер',
        },
        gameVersions: [ // Примерный список, можно расширить
            'Minecraft 1.21', 'Minecraft 1.20.4', 'Minecraft 1.19.2', 'Minecraft 1.18.1', 'Minecraft 1.16.5', 'Minecraft 1.12.2',
            'Stalker Anomaly', 'Stalker OGSR', 'Stalker OP-2.2'
        ],
        statuses: { 'draft': 'Черновик', 'published': 'Опубликован', 'review': 'На проверке' }
    }
};

// Helper function to safely get value from JSONB or string
function getSafeValue(field, lang = 'ru') {
    if (!field) return '';
    if (typeof field === 'object' && field !== null) {
        return field[lang] || '';
    }
    return field;
}

// Helper to render a single file entry HTML
const _renderSingleFileField = (file = {}, index) => {
    const uniqueId = `file_${index}_${Date.now()}`; // Ensure unique IDs for dynamic elements
    return `
        <div class="file-entry grid grid-cols-[1fr_auto] sm:grid-cols-[2fr_1fr_2fr_auto] items-center gap-3 p-3 bg-slate-800/50 rounded-lg border border-slate-700" data-id="${uniqueId}">
            <input type="text" name="file_name_${index}" placeholder="Название файла (RU)" class="form-input" value="${getSafeValue(file.name, 'ru')}" required>
            <input type="text" name="file_version_${index}" placeholder="Версия" class="form-input hidden sm:block" value="${file.version || ''}">
            <input type="text" name="file_url_${index}" placeholder="Ссылка или путь" class="form-input" value="${file.file_url || ''}" required>
            <button type="button" onclick="this.closest('.file-entry').remove()" class="p-2 rounded-lg text-slate-500 hover:bg-red-500/20 hover:text-red-400 transition-colors" title="Удалить файл" tabindex="-1">
                <i class="fas fa-trash-alt"></i>
            </button>
        </div>
    `;
};


// --- Управление контентом ---
async function renderContentManager() {
    const mainContent = document.getElementById('main-content');
    if (!mainContent) return;

    mainContent.innerHTML = `
        <div class="flex justify-between items-center mb-4 sm:mb-6">
            <h1 class="text-3xl font-bold">Управление контентом</h1>
        </div>
        <div id="content-list-container" class="space-y-4">
            <!-- Сюда будет рендериться список -->
            <div class="p-8 text-center text-gray-500">Загрузка контента...</div>
        </div>
    `;

    // Привязываем кнопку из шапки
    const addBtnHeader = document.getElementById('add-content-header-btn');
    if (addBtnHeader) addBtnHeader.onclick = () => renderContentForm(); // For new content

    await window.loadContent();
}

// Загрузка всего списка модов и утилит из Supabase на главную страницу админки
window.loadContent = async () => {
    const listContainer = document.getElementById('content-list-container');
    if (!listContainer) return;

    listContainer.innerHTML = '<div class="text-center p-4">Загрузка данных из Supabase...</div>';

    try {
        const { data, error } = await supabaseClient
            .from('content')
            .select('*')
            .order('created_at', { ascending: false });

        if (error) throw error;

        if (!data || data.length === 0) {
            listContainer.innerHTML = '<div class="text-center p-4 text-slate-400">Контент не найден. Создайте первую карточку!</div>';
            return;
        }

        let html = '';
        data.forEach(item => {
            const titleText = getSafeValue(item.title, 'ru') || 'Без названия';
            
            // --- ИСПРАВЛЕНИЕ: Безопасно извлекаем описание из объекта author ---
            const descriptionText = (typeof item.author === 'object' && item.author !== null) 
                ? (item.author.ru || item.author.en || '') 
                : (item.author || 'Нет описания');

            const isPublished = item.status === 'published';

            html += `
                <div class="flex flex-col md:flex-row items-start md:items-center justify-between bg-white dark:bg-[#1e293b] p-4 rounded-xl border border-slate-100 dark:border-slate-800/60 shadow-sm dark:shadow-md mb-3 gap-4">
                    <div class="flex items-center gap-3">
                        <img src="${item.image || 'assets/images/icon/icon1.png'}" alt="Обложка" class="w-12 h-12 rounded-lg object-cover flex-shrink-0">
                        <div>
                            <div class="flex items-center gap-2 mb-1">
                                <span id="badge-${item.id}" class="${isPublished ? 'bg-green-100 text-green-800 dark:bg-green-600 dark:text-white' : 'bg-orange-100 text-orange-800 dark:bg-orange-600 dark:text-white'} text-[10px] uppercase font-bold px-2 py-0.5 rounded">
                                    ${isPublished ? 'Опубликован' : 'Черновик'}
                                </span>
                                <span class="bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300 text-[10px] uppercase font-bold px-2 py-0.5 rounded">
                                    ${item.type || 'mod'}
                                </span>
                            </div>
                            <h3 class="text-slate-900 dark:text-white font-bold text-base leading-tight">${titleText}</h3>
                            <p class="text-slate-500 dark:text-slate-400 text-xs mt-1 max-w-md line-clamp-1">${descriptionText}</p>
                        </div>
                    </div>
                    
                    <div class="flex items-center gap-4 w-full md:w-auto justify-end">
                        <button onclick="window.openViewModal('${item.id}')" class="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-sky-400 w-9 h-9 flex items-center justify-center transition-colors" title="Просмотр"><i class="fa-solid fa-eye"></i></button>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" class="sr-only peer" ${isPublished ? 'checked' : ''} onchange="window.toggleContentStatus('${item.id}', this.checked)">
                            <div class="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                        </label>
                        
                        <button onclick="window.openEditModal('${item.id}')" class="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-indigo-400 w-9 h-9 flex items-center justify-center transition-colors" title="Редактировать"><i class="fa-solid fa-pen-to-square"></i></button>
                        <button onclick="window.duplicateContent('${item.id}')" class="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-purple-400 w-9 h-9 flex items-center justify-center transition-colors" title="Копировать"><i class="fa-solid fa-copy"></i></button>
                        <button onclick="window.deleteContent('${item.id}')" class="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-red-900/50 border border-slate-200 dark:border-slate-700 text-red-500 w-9 h-9 flex items-center justify-center transition-colors" title="Удалить"><i class="fa-solid fa-trash-can"></i></button>
                    </div>
                </div>
            `;
        });

        listContainer.innerHTML = html;

    } catch (err) {
        listContainer.innerHTML = `<div class="text-center p-4 text-red-500">Ошибка: ${err.message}</div>`;
    }
};

// Живое переключение статуса публикации тумблером прямо из списка
window.toggleContentStatus = async (contentId, isChecked) => {
    const targetStatus = isChecked ? 'published' : 'draft';
    const badge = document.getElementById(`badge-${contentId}`);

    try {
        const { error } = await supabaseClient
            .from('content')
            .update({ status: targetStatus })
            .eq('id', contentId);

    if (error) {
        throw error;
    }

        if (badge) {
            badge.innerText = isChecked ? 'Опубликован' : 'Черновик';
            badge.className = (isChecked ? 'bg-green-100 text-green-800 dark:bg-green-600 dark:text-white' : 'bg-orange-100 text-orange-800 dark:bg-orange-600 dark:text-white') + ' text-[10px] uppercase font-bold px-2 py-0.5 rounded';
        }
        console.log("Статус успешно обновлен!");
        if (window.showToast) window.showToast("Статус успешно обновлен!", "success");
    } catch (err) {
        if (window.showToast) window.showToast("Ошибка изменения статуса: " + err.message, "error");
        else alert("Ошибка изменения статуса: " + err.message);
        window.loadContent();
    }
};


// --- Форма и CRUD операции (renderContentForm now primarily builds the structure) ---
// Отрисовка модального окна и автоматическое наполнение инпутов данными
function renderContentForm(item = null) {
    const isEditing = item !== null;
    const modalContainer = document.getElementById('content-modal-container') || document.getElementById('modal-container');
    
    if (!modalContainer) {
        return console.error("Ошибка: На странице отсутствует контейнер для вывода модального окна!");
    }
    console.log("Реальные данные из базы:", item);
    
    // --- Извлечение данных (с проверкой на null для новых записей) ---
    const titleRU = isEditing ? (item.title?.ru || item.title || '') : '';
    const descRU = isEditing ? ((typeof item.author === 'object' && item.author !== null) ? (item.author.ru || item.author.en || '') : (item.author || '')) : '';

    const currentStatus = isEditing ? (item.status || 'draft') : 'draft';
    const currentType = isEditing ? (item.type || 'mods') : 'mods';
    
    // Чтение списка файлов (Колонка `files`)
    let linksArray = [];
    if (item && item.files) {
        // Если это уже массив/объект, берем как есть, если строка — парсим
        linksArray = typeof item.files === 'string' ? JSON.parse(item.files) : item.files;
    }
    // Если в базе пусто или это не массив, создаем одну пустую строчку
    if (!Array.isArray(linksArray) || linksArray.length === 0) {
        linksArray = [{ name: '', url: '' }];
    }

    // Генерируем HTML для полей ввода файлов
    let filesHTML = '';
    linksArray.forEach((link, idx) => {
        // --- ИСПРАВЛЕНИЕ 2: Подстановка старых данных в HTML ---
        // Исправлено: Безопасное извлечение имени файла из объекта link.name
        const linkName = (typeof link === 'object' && link !== null) ? (link.name?.ru || link.name || '') : '';
        
        const linkIcon = (typeof link === 'object' && link !== null) ? (link.icon || '') : '';

        filesHTML += `
            <div class="file-row grid grid-cols-1 md:grid-cols-[1fr_1fr_1fr_auto] gap-2 items-center bg-slate-900 p-2 rounded-lg border border-slate-700 mb-2" data-id="${idx}">
                <input type="text" class="file-name-input form-input" placeholder="Название файла" value="${linkName}" required>
                <input type="text" class="file-url-input form-input" placeholder="Ссылка на скачивание" value="${link.url || ''}" required>
                <input type="text" class="file-icon-input form-input" placeholder="Иконка (URL, необязательно)" value="${linkIcon}">
                <button type="button" onclick="this.closest('.file-row').remove()" class="p-2 rounded-lg text-slate-500 hover:bg-red-500/20 hover:text-red-400 transition-colors" title="Удалить файл">
                    <i class="fas fa-trash-alt"></i>
                </button>
            </div>
        `;
    });

    modalContainer.innerHTML = `
        <div id="modal-overlay" class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-70 p-4 overflow-y-auto">
            <div id="content-modal" class="relative w-full max-w-2xl bg-[#0f172a] rounded-xl border border-slate-800 shadow-2xl p-6 text-slate-100 max-h-[90vh] flex flex-col">

                <div class="flex justify-between items-center mb-6 border-b border-slate-800 pb-3">
                    <h2 class="text-xl font-bold text-white">${isEditing ? 'Редактирование' : 'Новый контент'}</h2>
                    <button onclick="closeContentForm()" class="text-slate-400 hover:text-white text-2xl">&times;</button>
                </div>

                <div class="flex-1 overflow-y-auto pr-2">
                    <form id="edit-content-form" onsubmit="window.saveEditedContent(event, '${isEditing ? item.id : ''}')" class="space-y-4">
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-xs font-semibold text-slate-400 mb-1">Категория</label>
                                <select id="edit-type" class="form-select">
                                    ${Object.entries(adminState.config.contentTypes).map(([key, value]) => `<option value="${key}" ${currentType === key ? 'selected' : ''}>${value}</option>`).join('')}
                                </select>
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-slate-400 mb-1">Статус публикации</label>
                                <select id="edit-status" class="form-select">
                                    <option value="draft" ${currentStatus === 'draft' ? 'selected' : ''}>Черновик</option>
                                    <option value="published" ${currentStatus === 'published' ? 'selected' : ''}>Опубликован</option>
                                </select>
                            </div>
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-slate-400 mb-1">Название</label>
                            <input type="text" id="edit-title-ru" value="${titleRU}" class="form-input" required>
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-slate-400 mb-1">Описание</label>
                            <textarea id="edit-description-ru" class="form-input" rows="3" placeholder="Краткое описание карточки...">${descRU}</textarea>
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-slate-400 mb-1">Ссылка на обложку</label>
                            <input type="text" id="edit-image-url" value="${isEditing ? (item.image || '') : ''}" class="form-input" placeholder="https://example.com/image.png">
                        </div>

                        <div class="pt-2">
                            <label class="block text-sm font-bold text-white mb-2">Файлы для скачивания</label>
                            <div id="files-downloads-container">${filesHTML}</div>
                            <button type="button" onclick="window.addNewFileRow()" class="mt-2 text-xs text-indigo-400 hover:text-indigo-300 font-semibold">+ Добавить еще один файл</button>
                        </div>

                        <div id="form-error" class="text-red-500 text-sm hidden"></div>

                        <div class="flex justify-end gap-3 pt-4 border-t border-slate-800 mt-6">
                            <button type="button" onclick="window.closeContentForm()" class="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg text-sm transition">Отмена</button>
                            <button type="submit" id="save-btn" class="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm transition">Сохранить изменения</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    `;
}

// Добавление новой строки для утилиты / файла «на лету»
window.addNewFileRow = () => {
    const container = document.getElementById('files-downloads-container');
    if (!container) return;
    const div = document.createElement('div');
    div.className = 'file-row grid grid-cols-1 md:grid-cols-[1fr_1fr_1fr_auto] gap-2 items-center bg-slate-900 p-2 rounded-lg border border-slate-700 mb-2';
    div.innerHTML = `
        <input type="text" class="file-name-input form-input" placeholder="Название файла" required>
        <input type="text" class="file-url-input form-input" placeholder="Ссылка на скачивание" required>
        <input type="text" class="file-icon-input form-input" placeholder="Иконка (URL, необязательно)">
        <button type="button" onclick="this.closest('.file-row').remove()" class="p-2 rounded-lg text-slate-500 hover:bg-red-500/20 hover:text-red-400 transition-colors" title="Удалить файл">
            <i class="fas fa-trash-alt"></i>
        </button>
    `;
    container.appendChild(div);
};

window.saveEditedContent = async (event, itemId) => {
    event.preventDefault();
    const saveBtn = document.getElementById('save-btn');
    const errorDiv = document.getElementById('form-error');
    if (!saveBtn || !errorDiv) return;

    saveBtn.disabled = true;
    saveBtn.textContent = 'Сохранение...';
    errorDiv.classList.add('hidden', 'opacity-0');

    try {
        // Сбор данных из полей
        // Сбор массива файлов
        const filesContainer = document.getElementById('files-downloads-container');
        if (!filesContainer) throw new Error("Не найден контейнер с файлами.");
        
        const fileRows = filesContainer.querySelectorAll('.file-row');
        const linksList = Array.from(fileRows).map(row => {
            const nameInput = row.querySelector('.file-name-input');
            const urlInput = row.querySelector('.file-url-input');
            const iconInput = row.querySelector('.file-icon-input');
            const fileObj = { name: nameInput.value, url: urlInput.value };
            // Иконку сохраняем только если она задана вручную
            if (iconInput && iconInput.value.trim()) fileObj.icon = iconInput.value.trim();
            return fileObj;
        }).filter(link => link.name && link.url); // Убираем пустые строки

        if (linksList.length === 0) {
            throw new Error("Добавьте хотя бы один файл для скачивания.");
        }

        // --- ИСПРАВЛЕНИЕ 3: Логика сохранения изменений ---
        const updatedPayload = {
            type: document.getElementById('edit-type').value,
            status: document.getElementById('edit-status').value,
            title: { ru: document.getElementById('edit-title-ru').value, en: "" },
            author: { ru: document.getElementById('edit-description-ru').value, en: "" },
            image: document.getElementById('edit-image-url').value.trim(),
            files: linksList // Отправляем чистый массив объектов прямо в jsonb колонку files
        };

        let result;
        if (itemId) {
            // Обновление существующей записи
            result = await supabaseClient.from('content').update(updatedPayload).eq('id', itemId);
        } else {
            // Создание новой записи
            result = await supabaseClient.from('content').insert([updatedPayload]);
        }

        if (result.error) {
            throw result.error;
        }

        closeContentForm();
        await window.loadContent(); // Перезагружаем список

    } catch (error) {
        console.error("Ошибка сохранения:", error);
        errorDiv.textContent = error.message;
        errorDiv.classList.remove('hidden');
        setTimeout(() => errorDiv.classList.add('opacity-100'), 10);
    } finally {
        saveBtn.disabled = false;
        saveBtn.textContent = 'Сохранить изменения';
    }
};

// --- Новая функция просмотра карточки с дизайном 2026 ---
window.openViewModal = async (contentId) => {
    // 1. Сохраняем рабочую логику запроса к базе
    const { data: item, error } = await supabaseClient
        .from('content')
        .select('*')
        .eq('id', contentId)
        .single();

    if (error || !item) {
        if (window.showToast) window.showToast("Ошибка загрузки", "error");
        else alert("Ошибка загрузки");
        return;
    }

    const titleRU = item.title?.ru || item.title || 'Без названия';
    
    // 2. Сохраняем логику парсинга массива файлов из колонки files
    let linksArray = [];
    if (item.files) {
        linksArray = typeof item.files === 'string' ? JSON.parse(item.files) : item.files;
    }
    if (!Array.isArray(linksArray)) linksArray = [];

    // 3. Сохраняем цикл генерации кнопок для скачивания (в новом дизайне 2026)
    let linksHTML = '';
    linksArray.forEach((link) => {
        const linkName = (typeof link === 'object' && link !== null) ? (link.name?.ru || link.name || 'Скачать файл') : 'Скачать файл';
        linksHTML += `
            <a href="${link.url || '#'}" target="_blank" rel="noopener noreferrer" class="flex items-center justify-between w-full p-4 rounded-xl border border-white/5 bg-white/[0.02] hover:bg-indigo-600/10 hover:border-indigo-500/30 transition-all duration-300 group cursor-pointer">
                <div class="flex items-center gap-3.5">
                    <div class="flex items-center justify-center w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 group-hover:bg-amber-500 group-hover:text-white transition-all duration-300 shadow-sm">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-5 h-5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M16.5 12 12 16.5m0 0L7.5 12m4.5 4.5V3" />
                        </svg>
                    </div>
                    <div class="text-left">
                        <p class="text-sm font-bold text-slate-200 group-hover:text-white transition-colors">${linkName}</p>
                        <p class="text-[11px] text-slate-400 tracking-wide">Безопасное скачивание файла</p>
                    </div>
                </div>
                <div class="text-slate-500 group-hover:text-amber-400 group-hover:translate-x-1 transition-all duration-300">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2.5" stroke="currentColor" class="w-4 h-4">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3" />
                    </svg>
                </div>
            </a>
        `;
    });

    // 4. Находим контейнер окон на сайте
    const modalContainer = document.getElementById('content-modal-container') || document.getElementById('modal-container');
    if (!modalContainer) return;
    
    // 5. Вставляем новый премиальный Glassmorphic HTML
    modalContainer.innerHTML = `
        <div id="modal-overlay" class="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 animate-fade-in" onclick="if (event.target === this) window.closeContentForm()">
            <div class="relative w-full max-w-lg bg-[#0b0f19]/90 backdrop-blur-2xl rounded-3xl border border-white/10 shadow-[0_0_50px_-12px_rgba(99,102,241,0.4)] pt-16 px-6 pb-6 text-slate-100 flex flex-col items-center overflow-hidden">
                
                <button onclick="window.closeContentForm()" class="absolute top-4 right-4 z-10 flex items-center justify-center w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white border border-white/5 transition-all duration-300">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2.5" stroke="currentColor" class="w-4 h-4">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" />
                    </svg>
                </button>

                <div class="w-full aspect-[16/10] rounded-2xl overflow-hidden border border-white/5 shadow-md relative">
                    <img src="${item.image || 'assets/images/icon/icon1.png'}" alt="${titleRU}" class="w-full h-full object-cover">
                    <div class="absolute inset-0 bg-gradient-to-t from-slate-950/40 to-transparent"></div>
                </div>

                <div class="w-full text-center">
                    <h2 class="text-2xl font-black tracking-tight text-white mt-5">${titleRU}</h2>
                </div>
                <div class="w-full space-y-2.5">${linksHTML}</div>
            </div>
        </div>
    `;
};
// --- Глобальная функция для открытия модального окна, принимает весь объект ---
// Открытие окна редактирования карточки контента (теперь по ID)
window.openEditModal = async (contentId) => {
    try {
        console.log("Загрузка карточки из Supabase, ID:", contentId);

        const { data, error } = await supabaseClient
            .from('content')
            .select('*')
            .eq('id', contentId)
            .single();

        if (error || !data) {
            if (window.showToast) window.showToast("Не удалось загрузить данные из базы: " + error?.message, "error");
            else alert("Не удалось загрузить данные из базы: " + error?.message);
            return;
        }

        renderContentForm(data);
    } catch (e) {
        console.error("Ошибка при открытии модального окна:", e);
        if (window.showToast) window.showToast("Произошла критическая ошибка при обработке данных.", "error");
        else alert("Произошла критическая ошибка при обработке данных.");
    }
};

// Открытие чистого окна создания нового контента
window.openCreateModal = () => {
    renderContentForm(null);
};

// Функция закрытия формы
window.closeContentForm = () => {
    const modalOverlay = document.getElementById('modal-overlay');
    if (modalOverlay) {
        // Добавляем класс для анимации исчезновения
        modalOverlay.classList.add('animate-fade-out');
        // Удаляем элемент из DOM после завершения анимации
        setTimeout(() => {
            modalOverlay.remove();
        }, 300);
    }
};

window.deleteContent = async (contentId) => {
    if (!confirm('Вы уверены, что хотите удалить этот элемент? Это действие необратимо.')) {
        return;
    }

    try {
        // 1. Получаем информацию о файлах и изображении перед удалением
        const { data: itemToDelete, error: fetchError } = await supabaseClient
            .from('content')
            .select('image, files_list')
            .eq('id', contentId)
            .single();

        if (fetchError) throw new Error(`Не удалось получить данные для удаления: ${fetchError.message}`);

        // 2. Удаляем связанные файлы из Storage
        if (itemToDelete && Array.isArray(itemToDelete.files_list)) {
            const filesToRemove = itemToDelete.files_list
                .map(f => f.file_url)
                .filter(url => url && url.includes(SUPABASE_URL)) // Только файлы из нашего хранилища
                .map(url => new URL(url).pathname.split('/content-files/')[1]); // Извлекаем путь

            if (filesToRemove.length > 0) {
                const { error: storageError } = await supabaseClient.storage.from('content-files').remove(filesToRemove);
                if (storageError) console.warn("Не удалось удалить связанные файлы:", storageError.message);
            }
        }

        // 3. Удаляем саму запись из таблицы
        const { error } = await supabaseClient.from('content').delete().eq('id', contentId);
        if (error) throw error;
        
        // Перезагружаем список, чтобы отразить удаление
        await window.loadContent();
        if (window.showToast) window.showToast("Карточка успешно удалена!", "success");

    } catch (err) {
        console.error("Delete error:", err);
        if (window.showToast) window.showToast(`Ошибка удаления: ${err.message}`, "error");
        else alert(`Ошибка удаления: ${err.message}`);
    }
}

// --- Функция дублирования контента ---
window.duplicateContent = async (contentId) => {
    if (!confirm('Вы уверены, что хотите создать копию этой карточки?')) {
        return;
    }

    try {
        // 1. Получаем оригинальную карточку
        const { data: originalItem, error: fetchError } = await supabaseClient
            .from('content')
            .select('*')
            .eq('id', contentId)
            .single();

        if (fetchError) throw new Error(`Не удалось получить данные для копирования: ${fetchError.message}`);

        // 2. Создаем новый объект на основе оригинала
        const newItem = { ...originalItem };
        delete newItem.id; // Удаляем ID, чтобы Supabase сгенерировал новый
        newItem.created_at = new Date().toISOString(); // Обновляем дату создания
        newItem.status = 'draft'; // Устанавливаем статус "Черновик"
        newItem.title.ru = `${getSafeValue(newItem.title, 'ru')} (Копия)`; // Добавляем "(Копия)" к названию
        // Если есть английское название, тоже добавляем
        if (newItem.title.en) newItem.title.en = `${getSafeValue(newItem.title, 'en')} (Copy)`;

        // 3. Вставляем новую запись в базу данных
        const { error: insertError } = await supabaseClient.from('content').insert([newItem]);
        if (insertError) throw insertError;

        await window.loadContent(); // Перезагружаем список, чтобы показать новую карточку
        window.showToast('Карточка успешно скопирована!', 'success');
    } catch (err) {
        console.error("Ошибка дублирования:", err);
        window.showToast(`Ошибка дублирования: ${err.message}`, 'error');
    }
};

// --- Управление брендированием ---
async function renderBrandingManager() {
    const mainContent = document.getElementById('main-content');
    mainContent.innerHTML = `<h1 class="text-2xl font-bold">Брендирование</h1><p>Этот раздел в разработке.</p>`;
}

// --- Просмотр сообщений поддержки ---
async function renderSupportView() {
    const mainContent = document.getElementById('main-content');
    if (!mainContent) return;

    mainContent.innerHTML = `
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-3xl font-bold">Сообщения поддержки</h1>
        </div>
        <div id="support-list" class="space-y-4">
            <div class="p-8 text-center text-gray-500">Загрузка сообщений...</div>
        </div>
    `;

    await fetchAndRenderSupportMessages();
}

async function fetchAndRenderSupportMessages() {
    const supportList = document.getElementById('support-list');
    if (!supportList) return;

    try {
        const { data, error } = await supabaseClient
            .from('support_messages')
            .select('*')
            .order('created_at', { ascending: false });

        if (error) throw error;

        if (data.length === 0) {
            supportList.innerHTML = '<div class="p-8 text-center text-gray-500 bg-white dark:bg-dark-secondary rounded-xl shadow-lg">Новых сообщений нет.</div>';
            return;
        }

        supportList.innerHTML = data.map(msg => createSupportMessageCard(msg)).join('');

        // Добавляем обработчики событий после рендеринга
        supportList.querySelectorAll('.delete-support-btn').forEach(btn => {
            btn.addEventListener('click', () => window.handleDeleteSupportMessage(btn.dataset.id));
        });

    } catch (err) {
        console.error("Error fetching support messages:", err);
        supportList.innerHTML = `<div class="p-8 text-center text-red-500 bg-red-100 rounded-xl">Ошибка загрузки: ${err.message}</div>`;
    }
}

function createSupportMessageCard(msg) {
    const formattedDate = new Date(msg.created_at).toLocaleString('ru-RU');
    const emailDisplay = msg.email ? `<a href="mailto:${msg.email}" class="text-primary hover:underline min-w-0 truncate block">${msg.email}</a>` : `<span class="text-gray-500">Анонимно</span>`;

    return `
        <div id="support-msg-${msg.id}" class="bg-white dark:bg-[#1e293b] shadow-md rounded-xl p-6 transition-all duration-300">
            <div class="flex justify-between items-start">
                <div class="flex-1">
                    <div class="flex items-center gap-4 mb-2 flex-wrap">
                        <span class="font-bold text-slate-800 dark:text-slate-200 min-w-0">${emailDisplay}</span>
                        <span class="text-xs text-slate-500">${formattedDate}</span>
                    </div>
                    <p class="text-slate-700 dark:text-slate-300 whitespace-pre-wrap">${msg.text || 'Текст отсутствует'}</p>
                </div>
                <button data-id="${msg.id}" class="delete-support-btn ml-4 text-gray-400 hover:text-red-500 transition-colors" title="Удалить сообщение">
                    <i class="fas fa-trash-alt"></i>
                </button>
            </div>
        </div>
    `;
}

window.handleDeleteSupportMessage = async function(messageId) {
    // Выводим стандартное подтверждение, чтобы не удалить случайно
    if (!confirm("Вы уверены, что хотите безвозвратно удалить это сообщение из базы данных?")) return;

    try {
        console.log("Удаление сообщения поддержки с ID:", messageId);

        // Отправляем реальный запрос на удаление строки в Supabase
        const { error } = await supabaseClient.from('support_messages').delete().eq('id', messageId);

        if (error) throw error;

        console.log("Сообщение успешно удалено из базы данных!");
        // Удаляем элемент со страницы для мгновенного отклика
        const elementToRemove = document.getElementById(`support-msg-${messageId}`);
        if (elementToRemove) elementToRemove.remove();
        if (window.showToast) window.showToast("Сообщение успешно удалено!", "success");

    } catch (err) {
        if (window.showToast) window.showToast("Ошибка удаления: " + err.message, "error");
        else alert("Ошибка удаления: " + err.message);
    }
}

// --- Экспорт функций в глобальный объект для роутера ---
window.admin = {
    renderContentManager,
    renderBrandingManager,
    renderSupportView,
    renderContentForm, // For new content button
};

// Добавляем стили для новых элементов формы
const styleSheet = document.createElement("style");
styleSheet.type = "text/css";
styleSheet.innerText = `
    .form-input, .form-select { background-color: #1e293b; color: #f8fafc; border: 1px solid #334155; border-radius: 0.375rem; padding: 0.5rem 0.75rem; width: 100%; outline: none; font-size: 0.875rem; transition: border-color 0.2s; }
    .form-input:focus, .form-select:focus { border-color: #6366f1; }
    .animate-fade-out { animation: fadeOut 0.3s ease-out forwards; } @keyframes fadeOut { from { opacity: 1; } to { opacity: 0; } }
    .form-radio { color: #6366f1; background-color: #334155; border-color: #475569; }
`;
document.head.appendChild(styleSheet);

// Запуск при загрузке страницы
// Этот слушатель не нужен, так как router.js уже вызывает navigate() на DOMContentLoaded,
// а navigate() вызывает renderContentManager(), который в свою очередь вызывает loadContent().
// document.addEventListener('DOMContentLoaded', () => { window.loadContent(); });