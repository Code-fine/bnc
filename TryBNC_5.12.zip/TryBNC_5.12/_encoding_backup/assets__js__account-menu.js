﻿/* ============================================================
   Выпадающее меню аккаунта в шапке (Аккаунт / Профиль / Выйти)
   ============================================================ */
(function () {
    'use strict';

    function initAccountMenu() {
        var wrap = document.getElementById('headerAccount');
        var btn = document.getElementById('headerAvatarBtn');
        var dropdown = document.getElementById('accountDropdown');
        if (!wrap || !btn || !dropdown) return;

        function openMenu() {
            dropdown.classList.add('open');
            dropdown.setAttribute('aria-hidden', 'false');
            btn.setAttribute('aria-expanded', 'true');
        }

        function closeMenu() {
            dropdown.classList.remove('open');
            dropdown.setAttribute('aria-hidden', 'true');
            btn.setAttribute('aria-expanded', 'false');
        }

        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            if (dropdown.classList.contains('open')) closeMenu();
            else openMenu();
        });

        document.addEventListener('click', function (e) {
            if (!wrap.contains(e.target)) closeMenu();
        });

        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') closeMenu();
        });

        var logout = document.getElementById('adLogout');
        if (logout) {
            logout.addEventListener('click', function () {
                closeMenu();
                var realLogout = document.getElementById('logout-btn');
                if (realLogout) realLogout.click();
                else if (window.supabaseClient) {
                    window.supabaseClient.auth.signOut().then(function () { window.location.reload(); });
                }
            });
        }

        /* Обновление данных в шапке меню */
        window.syncAccountMenu = function (user) {
            user = user || window.currentUser;
            var nameEl = document.getElementById('adName');
            var emailEl = document.getElementById('adEmail');
            var initialsEl = document.getElementById('headerAvatarInitials');

            var raw = (user && user.user_metadata && (user.user_metadata.full_name || user.user_metadata.name)) || '';
            var emailName = (user && user.email ? user.email.split('@')[0] : '');
            var display = raw || emailName || 'Пользователь';
            display = display.charAt(0).toUpperCase() + display.slice(1);

            if (nameEl) nameEl.textContent = display;
            if (emailEl) emailEl.textContent = (user && user.email) || '';
            if (initialsEl) {
                initialsEl.textContent = (String(display).replace(/[^\p{L}\p{N}]/gu, '').slice(0, 2) || '?').toUpperCase();
            }
        };
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAccountMenu);
    } else {
        initAccountMenu();
    }
})();
