﻿/* ============================================================
   Полноэкранный личный кабинет (Spotify-style dashboard)
   Управляет открытием/закрытием окна и наполнением данными.
   ============================================================ */
(function () {
    'use strict';

    var dashboard = document.getElementById('profileDashboard');
    if (!dashboard) return;

    var scrollArea = document.getElementById('pdScroll');
    var greeting = document.getElementById('pdGreeting');
    var chipName = document.getElementById('pdChipName');
    var chipInitials = document.getElementById('pdChipInitials');
    var chipAvatar = document.getElementById('pdChipAvatar');

    function prettyNameFromUser(user) {
        if (!user) return 'Гость';
        var raw = (user.user_metadata && (user.user_metadata.full_name || user.user_metadata.name)) || '';
        var emailName = (user.email || '').split('@')[0];
        var display = raw || emailName || 'Пользователь';
        return display.charAt(0).toUpperCase() + display.slice(1);
    }

    function initialsFromName(name) {
        return (String(name).replace(/[^\p{L}\p{N}]/gu, '').slice(0, 2) || '?').toUpperCase();
    }

    /* Наполнение данными пользователя */
    function syncProfileDashboard(user) {
        user = user || window.currentUser;
        var name = prettyNameFromUser(user);

        if (greeting) greeting.textContent = 'Добро пожаловать, ' + name;
        if (chipName) chipName.textContent = name;
        if (chipInitials) chipInitials.textContent = initialsFromName(name);

        var avatarUrl = user && user.user_metadata &&
            (user.user_metadata.manual_avatar || user.user_metadata.avatar_url || user.user_metadata.picture);

        if (chipAvatar && chipInitials) {
            if (avatarUrl) {
                chipAvatar.src = avatarUrl;
                chipAvatar.style.display = 'block';
                chipInitials.style.display = 'none';
            } else {
                chipAvatar.style.display = 'none';
                chipInitials.style.display = 'inline-flex';
            }
        }
    }

    /* Открытие / закрытие */
    function openProfileDashboard() {
        syncProfileDashboard();
        dashboard.classList.add('open');
        dashboard.setAttribute('aria-hidden', 'false');
        document.body.classList.add('pd-open');
        if (window.lenis && window.lenis.stop) window.lenis.stop();
        if (scrollArea) scrollArea.scrollTop = 0;
    }

    function closeProfileDashboard() {
        dashboard.classList.remove('open');
        dashboard.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('pd-open');
        if (window.lenis && window.lenis.start) window.lenis.start();
    }

    /* Обработчики */
    dashboard.querySelectorAll('[data-pd-close]').forEach(function (el) {
        el.addEventListener('click', closeProfileDashboard);
    });

    dashboard.querySelectorAll('.pd-nav-link[data-pd-view]').forEach(function (link) {
        link.addEventListener('click', function () {
            dashboard.querySelectorAll('.pd-nav-link').forEach(function (l) {
                l.classList.remove('active');
            });
            link.classList.add('active');
        });
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && dashboard.classList.contains('open')) {
            closeProfileDashboard();
        }
    });

    /* Публичный API */
    window.openProfileDashboard = openProfileDashboard;
    window.closeProfileDashboard = closeProfileDashboard;
    window.syncProfileDashboard = syncProfileDashboard;

    /* Если пользователь уже загружен к моменту старта */
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () { syncProfileDashboard(); });
    } else {
        syncProfileDashboard();
    }
})();
