﻿// Переводы и логика языка
// Функция локализации (выбор языка из объекта)
window.l = function(data) {
    const lang = window.currentLang || 'ru';
    if (data && typeof data === 'object' && !Array.isArray(data)) {
        return data[lang] || data['ru'] || '';
    }
    return data || '';
};

window.translations = {
    ru: {
        categories: "Главная",
        home: "Главная",
        socials: "Соцсети",
        search_placeholder: "Поиск по названию",
        nothing_found: "Ничего не найдено",
        open: "Открыть",
        watch: "Смотреть",
        files_unavailable: "Файлы пока недоступны",
        instruction_title: "Инструкция по установке",
        download_file: "Скачать файл",
        footer_telegram: "Telegram",
        footer_discord: "Discord",
        instruction_not_found: "Инструкция не найдена. Нажмите кнопку ниже, чтобы скачать.",
        index_title: "BNC",
        book_title: "Скачать файл",
        header_index: "BNC",
        header_utils: "BNC",
        header_minecraft: "BNC",
        header_book: "Zabuza Библиотека",
        view_grid: "Сетка",
        view_list: "Список",
        cat_utils: "Утилиты",
        utils_title: "BNC",
        back_button: "Назад",
        back_to_list: "в†ђ Вернуться к списку",
        return: "Вернуться",
        file_not_selected: "Файл не выбран", 
        terms_of_service: "Условия предоставления услуг",
        privacy_policy: "Политика конфиденциальности",
        support: "Поддержка",
        snow: "Снег",
        snow_desc: "Включите, чтобы добавить на сайт эффект падающего снега. Это создаст зимнюю атмосферу на всех страницах.",
        hub_minecraft_title: "Моды",
        hub_minecraft_desc: "Сборки, моды и шейдеры",
        hub_utils_title: "Утилиты",
        hub_utils_desc: "Лучший софт для ПК",
        hub_community_title: "Сообщество",
        hub_community_desc: "Присоединяйтесь к нам",
        all: "Все",
        mods: "Моды",
        textures: "Текстуры",
        shaders: "Шейдеры",
        launchers: "Лаунчеры",
        maps: "Карты",
        change_account: "Сменить аккаунт",
        footer_nav: "Навигация",
        footer_resources: "Оставайтесь на связи",
        footer_lang: "Язык",
        footer_welcome: "Ваш универсальный хаб контента и полезных инструментов для Minecraft и ПК.",
        footer_home: "Главная",
        footer_interesting: "Интересное",
        footer_donate: "Финансовая поддержка",
        seconds_short: "сек.",
        time_in_system: "Время в системе",
        err_unknown: "Произошла неизвестная ошибка",
        err_network: " Ошибка сети. Проверьте подключение",
        err_invalid_credentials: "Неверный email или пароль",
        err_user_exists: "Пользователь с таким email уже зарегистрирован",
        err_weak_password: "Пароль слишком слабый (минимум 6 символов)",
        err_email_not_confirmed: "Пожалуйста, подтвердите ваш email",
        err_auth_required: "Пожалуйста, войдите в аккаунт, чтобы скачать файл",
        auth_success_reg: "Регистрация успешна! Пожалуйста, войдите.",
        auth_success_login: "С возвращением!",
        total_downloads: "Всего загрузок",
        err_file_too_large: "Файл слишком большой (макс. 2МБ)",
        copy_success: "Путь скопирован!",
        err_limit: "Слишком много попыток. Попробуйте позже.",
        pin_label_0: "МОДЫ",
        pin_label_1: " КОЛЛЕКЦИИ",
        pin_label_2: "РУСИФИКАТОРЫ",
        pin_label_3: "ПОДДЕРЖКА",
        support_button_text: "Отправить сообщение",
        sending_message: "Отправка...",
        support_message_required: "Пожалуйста, введите ваше сообщение.",
        support_send_error: "Ошибка отправки. Попробуйте позже.",
        support_send_success: "Сообщение отправлено!",
    },
    en: {
        categories: "Home",
        home: "Home",
        socials: "Socials",
        search_placeholder: "Search by title",
        nothing_found: "Nothing found",
        open: "Open",
        watch: "Watch",
        files_unavailable: "Files not available yet",
        instruction_title: "Installation Instructions",
        download_file: "Download file",
        footer_telegram: "Telegram",
        footer_discord: "Discord",
        instruction_not_found: "Instruction not found. Click the button below to download.",
        index_title: "BNC",
        book_title: "Download File",
        header_index: "BNC",
        header_utils: "BNC",
        header_minecraft: "BNC",
        header_book: "Zabuza Library",
        view_grid: "Grid",
        view_list: "List",
        cat_utils: "Utilities",
        utils_title: "BNC",
        back_button: "Back",
        back_to_list: "в†ђ Back to list",
        return: "Return",
        file_not_selected: "File not selected", 
        terms_of_service: "Terms of Service",
        privacy_policy: "Privacy Policy",
        support: "Support",
        snow: "Snow",
        snow_desc: "Enable to add a falling snow effect to the site. This will create a winter atmosphere on all pages.",
        hub_minecraft_title: "Mods",
        hub_minecraft_desc: "Builds, mods and shaders",
        hub_utils_title: "Utilities",
        hub_utils_desc: "Best software for PC",
        hub_community_title: "Community",
        hub_community_desc: "Join our community",
        all: "All",
        mods: "Mods",
        textures: "Textures",
        shaders: "Shaders",
        launchers: "Launchers",
        maps: "Maps",
        change_account: "Change Account",
        footer_nav: "Navigation",
        footer_resources: "Stay in touch",
        footer_lang: "Language",
        footer_welcome: "Your ultimate hub for content and useful tools for Minecraft and PC.",
        footer_home: "Home",
        footer_interesting: "Interesting",
        footer_donate: "Financial support",
        seconds_short: "sec.",
        time_in_system: "Time in system",
        err_unknown: "An unknown error occurred",
        err_network: "Network error. Please check your connection",
        err_invalid_credentials: "Invalid email or password",
        err_user_exists: "User with this email already exists",
        err_weak_password: "Password is too weak (min 6 characters)",
        err_email_not_confirmed: "Please confirm your email address",
        err_auth_required: "Please log in to download the file",
        auth_success_reg: "Registration successful! Please log in.",
        auth_success_login: "Welcome back!",
        total_downloads: "Total downloads",
        err_file_too_large: "File too large (max 2MB)",
        copy_success: "Path copied!",
        err_limit: "Too many attempts. Please try again later.",
        pin_label_0: "MODS",
        pin_label_1: "SHADERS WITH RTX",
        pin_label_2: "TEXTURES",
        pin_label_3: "SUPPORT",
        support_button_text: "Send Message",
        sending_message: "Sending...",
        support_message_required: "Please enter your message.",
        support_send_error: "Send error. Please try again later.",
        support_send_success: "Message sent!",
    }
};

// Определение языка: сохраненный или из браузера
const savedLang = localStorage.getItem('lang');
if (savedLang) {
    window.currentLang = savedLang;
} else {
    const userLang = navigator.language || navigator.userLanguage; 
    window.currentLang = userLang && userLang.toLowerCase().startsWith('ru') ? 'ru' : 'en';
}

window.setLanguage = function(lang) {
    const prevLang = window.currentLang;
    window.currentLang = lang;
    localStorage.setItem('lang', lang);
    
    // Обновляем текст кнопки языка
    const langDisplay = document.getElementById('currentLangDisplay');
    if (langDisplay) langDisplay.textContent = lang.toUpperCase();

    // Обновляем активный статус в меню
    document.querySelectorAll('.footer-lang .dropdown-content a').forEach(link => {
        if (link.getAttribute('data-lang') === lang) {
            link.classList.add('selected');
        } else {
            link.classList.remove('selected');
        }
    });

    // Обновляем текст
    const t = window.translations[lang];

    const elMap = {
        'nav-categories': t.categories,
        'nav-minecraft': t.hub_minecraft_title,
        'nav-utils': t.hub_utils_title,
        'nav-socials': t.socials,
        'searchInput': t.search_placeholder,
        'instructionTitle': t.instruction_title,
        'instructionDownloadBtn': t.download_file,
        'gridViewBtn': t.view_grid,
        'listViewBtn': t.view_list,
        'snow-label': t.snow,
        'snow-desc': t.snow_desc,
        'snow-desc-modal': t.snow_desc,
        'backBtn': t.back_button,
        'footer-support-text': t.support,
        'hub-minecraft-title': t.hub_minecraft_title,
        'hub-minecraft-desc': t.hub_minecraft_desc,
        'hub-utils-title': t.hub_utils_title,
        'hub-utils-desc': t.hub_utils_desc,
        'hub-community-title': t.hub_community_title,
        'hub-community-desc': t.hub_community_desc,
        'btn-all-mc': t.all,
        'btn-mods': t.mods,
        'btn-textures': t.textures,
        'btn-shaders': t.shaders,
        'btn-launchers': t.launchers,
        'btn-maps': t.maps,
        'changeAccountBtn': t.change_account,
        'footer-nav-title': t.footer_nav,
        'footer-resources-title': t.footer_resources,
        'footer-lang-title': t.footer_lang,
        'footer-welcome-text': t.footer_welcome,
        'footer-home-link': t.footer_home,
        'footer-utils-link': t.footer_interesting,
        'pin-label-0': t.pin_label_0,
        'pin-label-1': t.pin_label_1,
        'pin-label-2': t.pin_label_2,
        'pin-label-3': t.pin_label_3
    };

    Object.entries(elMap).forEach(([id, text]) => {
        const el = document.getElementById(id);
        if (el) {
            if (el.tagName === 'INPUT') el.placeholder = text;
            else if (el.tagName === 'BUTTON' && el.title !== undefined) el.title = text;
            else el.innerHTML = text;
        }
    });

    // Отдельно обрабатываем ссылку доната, чтобы вставить иконку
    Object.entries({ 'footer-donate-link': t.footer_donate }).forEach(([id, text]) => {
        const el = document.getElementById(id);
        if (el) {
            el.innerHTML = `<span class="flex items-center gap-2"><i class="fas fa-heart"></i> ${text}</span>`;
        }
    });

    // Обновляем заголовок страницы
    if (document.getElementById('bookDetail')) {
        document.title = t.book_title;
    } else if (document.getElementById('utilsGrid')) {
        document.title = t.utils_title;
    } else {
        document.title = t.index_title;
    }

    // Обновляем название сайта в шапке
    const siteTitle = document.getElementById('siteTitle');
    if (siteTitle) {
        if (document.getElementById('bookDetail')) {
            siteTitle.textContent = t.header_book;
        } else if (window.location.pathname.includes('minecraft.html')) {
            siteTitle.textContent = t.header_minecraft;
        } else if (document.getElementById('utilsGrid')) {
            siteTitle.textContent = t.header_utils;
        } else {
            siteTitle.textContent = t.header_index;
        }
    }
    
    const privacyPolicySpan = document.getElementById('footer-privacy-policy-text');
    if (privacyPolicySpan) { // Используем новый ключ
        privacyPolicySpan.textContent = t.terms_of_service;
    }

    const privacyLinkSpan = document.getElementById('footer-privacy-link-text');
    if (privacyLinkSpan) {
        privacyLinkSpan.textContent = t.privacy_policy;
    }

    // Обновление контента на страницах
    if (typeof renderBooks === 'function') {
        const searchInput = document.getElementById('searchInput');
        renderBooks(searchInput ? searchInput.value : '');
    }
    if (typeof renderBookDetail === 'function') {
        renderBookDetail();
    }
    if (typeof renderUtils === 'function') {
        renderUtils();
    }
}

// Инициализация языка при загрузке
document.addEventListener('DOMContentLoaded', () => {
    setLanguage(window.currentLang);
});