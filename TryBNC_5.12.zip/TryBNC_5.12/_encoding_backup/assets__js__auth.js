﻿function getFriendlyErrorMessage(error) {
    if (!error) return null;
    const t = window.translations ? window.translations[window.currentLang] : {};
    const message = error.message || error.code || "";
    if (message.includes('Failed to fetch')) return t.err_network;
    switch (message) {
        case 'invalid_credentials':
        case 'Invalid login credentials': return t.err_invalid_credentials;
        case 'User already registered': return t.err_user_exists;
        case 'Over_query_limit': return t.err_limit || "Слишком много попыток. Попробуйте позже.";
        case 'Password should be at least 6 characters': return t.err_weak_password;
        default: return message || t.err_unknown;
    }
}

async function checkUser(user = null) {
    // Если пользователь не передан, пробуем получить его быстро из текущей сессии
    if (!user) {
        const { data } = await supabaseClient.auth.getUser();
        user = data?.user;
    }
    window.currentUser = user;
    
    const elements = {
        headerBtn: document.getElementById('headerLoginBtn'),
        headerAvatar: document.getElementById('headerAvatar'),
        headerAvatarBtn: document.getElementById('headerAvatarBtn'),
        headerAvatarInitials: document.getElementById('headerAvatarInitials'),
        authContainers: document.getElementById('auth-containers'),
        profileBox: document.getElementById('profile-box'),
        userEmail: document.getElementById('user-email'),
        userEmailText: document.getElementById('user-email-text'),
        userEmailMirror: document.getElementById('user-email-mirror'),
        userName: document.getElementById('user-name'),
        userInitials: document.getElementById('user-avatar-initials'),
        userAvatar: document.getElementById('user-avatar'),
        changeBtn: document.getElementById('changeAccountBtn')
    };

    if (user) {
        if (elements.authContainers) elements.authContainers.style.display = 'none';
        if (elements.profileBox) elements.profileBox.style.display = 'block';

        // Красивое имя из email / метаданных + инициалы для аватара
        const rawName = user.user_metadata?.full_name || user.user_metadata?.name || '';
        const emailName = (user.email || '').split('@')[0];
        const displayName = rawName || emailName || 'Пользователь';
        const prettyName = displayName.charAt(0).toUpperCase() + displayName.slice(1);

        if (elements.userEmailText) elements.userEmailText.textContent = user.email || '';
        if (elements.userEmailMirror) elements.userEmailMirror.textContent = user.email || '';
        if (elements.userName) elements.userName.textContent = prettyName;
        if (elements.userInitials) {
            const initials = (prettyName.replace(/[^\p{L}\p{N}]/gu, '').slice(0, 2) || '?').toUpperCase();
            elements.userInitials.textContent = initials;
        }
        if (elements.headerAvatarInitials) {
            const initials = (prettyName.replace(/[^\p{L}\p{N}]/gu, '').slice(0, 2) || '?').toUpperCase();
            elements.headerAvatarInitials.textContent = initials;
        }

        if (elements.userEmail && !elements.userEmail.dataset.copyBound) {
            elements.userEmail.dataset.copyBound = 'true';
            elements.userEmail.addEventListener('click', () => {
                const mail = (window.currentUser && window.currentUser.email) || '';
                if (!mail) return;
                navigator.clipboard.writeText(mail).then(() => {
                    elements.userEmail.classList.add('copied');
                    if (window.showToast) window.showToast('Email скопирован', 'success');
                    setTimeout(() => elements.userEmail.classList.remove('copied'), 1500);
                }).catch(() => {});
            });
        }

        // Скрываем кнопку логина и показываем аватарку
        if (elements.headerBtn) elements.headerBtn.style.display = 'none';

        const avatarUrl = user.user_metadata?.manual_avatar || user.user_metadata?.avatar_url || user.user_metadata?.picture;
        const finalAvatar = avatarUrl || 'assets/images/icon/icon1.png'; // Заглушка, если нет фото

        if (elements.userAvatar) {
            elements.userAvatar.src = finalAvatar;
            elements.userAvatar.style.display = 'block';
            // Скрываем инициалы, если есть настоящая аватарка (не заглушка)
            const hasRealAvatar = !!avatarUrl;
            if (elements.userInitials) elements.userInitials.style.display = hasRealAvatar ? 'none' : 'flex';
        }
        if (elements.headerAvatar) elements.headerAvatar.src = finalAvatar;
        if (elements.headerAvatarBtn) {
            elements.headerAvatarBtn.style.display = 'inline-flex';
            if (elements.headerAvatarInitials) {
                const hasRealAvatar = !!avatarUrl;
                elements.headerAvatarInitials.style.display = hasRealAvatar ? 'none' : 'inline-flex';
            }
        }
        if (window.syncAccountMenu) window.syncAccountMenu(user);
        if (window.initUserTimeTracking) window.initUserTimeTracking(user);
        if (window.syncProfileDashboard) window.syncProfileDashboard(user);
    } else {
        if (elements.authContainers) elements.authContainers.style.display = 'block';
        if (elements.profileBox) elements.profileBox.style.display = 'none';
        if (elements.userAvatar) elements.userAvatar.style.display = 'none';
        if (elements.userInitials) elements.userInitials.style.display = 'flex';
        if (elements.headerAvatarBtn) elements.headerAvatarBtn.style.display = 'none';
        if (elements.headerBtn) {
            elements.headerBtn.style.display = 'block';
            elements.headerBtn.textContent = 'Войти';
            elements.headerBtn.onclick = () => {
                const modal = document.getElementById('authModal');
                if (modal) {
                    modal.classList.add('show');
                    document.body.style.overflow = 'hidden';
                    document.body.classList.add('modal-open');
                    if (window.lenis) window.lenis.stop();
                } else {
                    localStorage.setItem('openAuthModal', 'true');
                    window.location.href = 'index.html';
                }
            };
        }
        if (window.stopTrackingTime) window.stopTrackingTime();
    }
}

async function signInWithSocial(provider) {
    const queryParams = provider === 'google' ? { prompt: 'select_account consent' } : { force_verify: 'true' };
    const { error } = await supabaseClient.auth.signInWithOAuth({
        provider: provider,
        options: { redirectTo: window.location.origin, queryParams }
    });
    if (error) window.showToast(`Error: ${error.message}`, 'error');
}

document.addEventListener('DOMContentLoaded', () => {
    const regForm = document.getElementById('register-form');
    if (regForm) {
        regForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const t = window.translations ? window.translations[window.currentLang] : {};
            const email = document.getElementById('reg-email')?.value.trim();
            const password = document.getElementById('reg-password')?.value.trim();
            
            if (!email || !password) return;

            const { error } = await supabaseClient.auth.signUp({ email, password });
            if (error) window.showToast(getFriendlyErrorMessage(error), 'error');
            else {
                window.showToast(t.auth_success_reg || "Success! Please log in.", 'success');
                const regBox = document.getElementById('register-box');
                const logBox = document.getElementById('login-box');
                if (regBox) regBox.style.display = 'none';
                if (logBox) logBox.style.display = 'block';
            }
        });
    }

    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const t = window.translations ? window.translations[window.currentLang] : {};
            const email = document.getElementById('login-email')?.value.trim();
            const password = document.getElementById('login-password')?.value.trim();

            if (!email || !password) return;

            const { error } = await supabaseClient.auth.signInWithPassword({ email, password });
            if (error) window.showToast(getFriendlyErrorMessage(error), 'error');
            else {
                window.showToast(t.auth_success_login || "Welcome back!", 'success');
                const modal = document.getElementById('authModal');
                if (modal) {
                    modal.classList.remove('show');
                    document.body.style.overflow = '';
                    document.body.classList.remove('modal-open');
                    if (window.lenis) window.lenis.start();
                }
                checkUser();
            }
        });
    }

    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.onclick = async () => {
            await supabaseClient.auth.signOut();
            window.location.reload(); // Перезагружаем для сброса всех состояний
        };
    }

    const googleBtn = document.getElementById('googleAuthBtn');
    if (googleBtn) googleBtn.onclick = () => signInWithSocial('google');

    const changeBtn = document.getElementById('changeAccountBtn');
    if (changeBtn) changeBtn.onclick = () => signInWithSocial('google');

    // Логика переключения форм (Вход / Регистрация)
    const toReg = document.getElementById('to-register');
    const toLog = document.getElementById('to-login');
    const loginBox = document.getElementById('login-box');
    const regBox = document.getElementById('register-box');

    if (toReg && loginBox && regBox) {
        toReg.onclick = () => { loginBox.style.display = 'none'; regBox.style.display = 'block'; };
    }
    if (toLog && loginBox && regBox) {
        toLog.onclick = () => { regBox.style.display = 'none'; loginBox.style.display = 'block'; };
    }

    // Логика загрузки аватарки
    const avatarInput = document.getElementById('avatar-upload');
    if (avatarInput) {
        avatarInput.addEventListener('change', async (e) => {
            const file = e.target.files[0];
            if (!file) return;

            // Валидация размера файла (например, до 2 МБ)
            if (file.size > 2 * 1024 * 1024) {
                const t = window.translations ? window.translations[window.currentLang] : {};
                window.showToast(t.err_file_too_large || "Файл слишком большой (макс. 2МБ)", 'error');
                return;
            }

            const { data: { user } } = await supabaseClient.auth.getUser();
            if (!user) {
                const t = window.translations ? window.translations[window.currentLang] : {};
                window.showToast(t.err_auth_required || "Please log in to upload an avatar.", 'error');
                return;
            }

            // Показываем индикатор загрузки (опционально)
            const avatarContainer = e.target.closest('div');
            if (avatarContainer) {
                avatarContainer.style.opacity = '0.5';
                avatarContainer.style.pointerEvents = 'none';
            }

            // Удаляем старый файл из хранилища, если он там есть
            const oldAvatarUrl = user.user_metadata?.manual_avatar;
            if (oldAvatarUrl && oldAvatarUrl.includes('/storage/v1/object/public/avatars/')) {
                // Извлекаем путь файла из URL (все, что после названия бакета 'avatars/')
                const oldPath = oldAvatarUrl.split('avatars/').pop();
                if (oldPath) {
                    await supabaseClient.storage.from('avatars').remove([oldPath]);
                }
            }

            const fileExt = file.name.split('.').pop();
            const fileName = `${user.id}-${Math.random()}.${fileExt}`;
            const filePath = `user_avatars/${fileName}`;

            // 1. Загружаем файл в Storage
            const { error: uploadError } = await supabaseClient.storage
                .from('avatars')
                .upload(filePath, file);

            if (uploadError) {
                window.showToast("Ошибка загрузки: " + uploadError.message, 'error');
                if (avatarContainer) avatarContainer.style.opacity = '1';
                return;
            }

            // 2. Получаем публичную ссылку
            const { data: { publicUrl } } = supabaseClient.storage.from('avatars').getPublicUrl(filePath);

            // 3. Обновляем метаданные пользователя под уникальным ключом
            const { error: updateError } = await supabaseClient.auth.updateUser({ data: { manual_avatar: publicUrl } });

            if (updateError) window.showToast("Ошибка обновления профиля: " + updateError.message, 'error');
            else checkUser(); // Обновляем картинку на странице
            if (avatarContainer) {
                avatarContainer.style.opacity = '1';
                avatarContainer.style.pointerEvents = 'auto';
            }
        });
    }

    // Логика закрытия модального окна авторизации
    const closeAuth = document.getElementById('closeAuth');
    const authModal = document.getElementById('authModal');

    const closeAuthHandler = () => {
        if (authModal) {
            authModal.classList.remove('show');
            document.body.style.overflow = '';
            document.body.classList.remove('modal-open');
            if (window.lenis) window.lenis.start();
        }
    };

    if (closeAuth && authModal) {
        closeAuth.addEventListener('click', closeAuthHandler);
        window.addEventListener('click', (e) => {
            if (e.target === authModal) closeAuthHandler();
        });
    }

    // Проверка автоматического открытия модалки (после редиректа)
    if (localStorage.getItem('openAuthModal') === 'true') {
        localStorage.removeItem('openAuthModal');
        const modal = document.getElementById('authModal');
        if (modal) { 
            modal.classList.add('show'); 
            document.body.style.overflow = 'hidden'; 
            document.body.classList.add('modal-open');
            if (window.lenis) window.lenis.stop();
        }
    }
});

supabaseClient.auth.onAuthStateChange((event, session) => {
    // Используем данные пользователя прямо из сессии (это мгновенно)
    checkUser(session?.user || null);
});